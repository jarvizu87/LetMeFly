const CACHE_NAME = 'letmefly-shell-v5-rebuild-1'
const PRECACHE = ['/', '/manifest.webmanifest', '/icon-192.png', '/icon-512.png']

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE_NAME).then((cache) => cache.addAll(PRECACHE)).then(() => self.skipWaiting()))
})

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))))
      .then(() => self.clients.claim()),
  )
})

function isPrivateOrAuth(request) {
  const url = new URL(request.url)
  if (url.hostname.endsWith('.supabase.co')) return true
  if (/\/auth\/v1\//.test(url.pathname)) return true
  if (/\/rest\/v1\//.test(url.pathname)) return true
  if (/\/functions\/v1\//.test(url.pathname)) return true
  if (/\.letmefly-backup\.json$/i.test(url.pathname)) return true
  return false
}

self.addEventListener('fetch', (event) => {
  const request = event.request
  if (request.method !== 'GET' || isPrivateOrAuth(request)) return

  const url = new URL(request.url)
  if (url.origin !== self.location.origin) return

  if (request.mode === 'navigate') {
    event.respondWith(
      fetch(request)
        .then((response) => {
          const copy = response.clone()
          caches.open(CACHE_NAME).then((cache) => cache.put('/', copy))
          return response
        })
        .catch(() => caches.match('/').then((response) => response || new Response('LetMeFly shell unavailable', { status: 503 }))),
    )
    return
  }

  if (['script', 'style', 'image', 'font', 'manifest'].includes(request.destination)) {
    event.respondWith(
      caches.match(request).then((cached) => {
        const network = fetch(request)
          .then((response) => {
            if (response.ok) caches.open(CACHE_NAME).then((cache) => cache.put(request, response.clone()))
            return response
          })
          .catch(() => cached)
        return cached || network
      }),
    )
  }
})
