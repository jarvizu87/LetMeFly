import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { pathToFileURL } from 'node:url'

const root = path.resolve(new URL('..', import.meta.url).pathname)
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'lmf-cf-audit-'))

const compile = spawnSync('tsc', [
  '--outDir', temp,
  '--target', 'ES2022',
  '--module', 'ESNext',
  '--moduleResolution', 'Bundler',
  '--lib', 'ES2022,DOM',
  '--strict',
  '--skipLibCheck',
  path.join(root, 'src/data/programs.ts'),
  path.join(root, 'src/data/crownforge-weeks-3-6.ts'),
], { encoding: 'utf8' })

if (compile.status !== 0) {
  console.error(compile.stdout)
  console.error(compile.stderr)
  process.exit(compile.status || 1)
}

const modulePath = path.join(temp, 'crownforge-weeks-3-6.js')
const mod = await import(pathToFileURL(modulePath).href)

const weeks = new Map([
  [3, mod.CROWNFORGE_WEEK_3],
  [4, mod.CROWNFORGE_WEEK_4],
  [5, mod.CROWNFORGE_WEEK_5],
  [6, mod.CROWNFORGE_WEEK_6],
])

const expectedDates = {
  3: ['2026-09-21','2026-09-22','2026-09-23','2026-09-24','2026-09-25','2026-09-26','2026-09-27'],
  4: ['2026-09-28','2026-09-29','2026-09-30','2026-10-01','2026-10-02','2026-10-03','2026-10-04'],
  5: ['2026-10-05','2026-10-06','2026-10-07','2026-10-08','2026-10-09','2026-10-10','2026-10-11'],
  6: ['2026-10-12','2026-10-13','2026-10-14','2026-10-15','2026-10-16','2026-10-17','2026-10-18'],
}

const failures = []
const passes = []
const fail = (week, label, detail) => failures.push({ week, label, detail })
const pass = (week, label) => passes.push({ week, label })
const assert = (week, label, condition, detail = '') => condition ? pass(week, label) : fail(week, label, detail)

function day(week, dayNumber) {
  return weeks.get(week)?.days.find((item) => item.day === dayNumber)
}
function exercise(week, dayNumber, name) {
  const d = day(week, dayNumber)
  for (const section of d?.sections ?? []) {
    const found = section.exercises.find((item) => item.name === name)
    if (found) return found
  }
  return null
}
function exerciseInSection(week, dayNumber, sectionId, name) {
  return day(week, dayNumber)?.sections.find((section) => section.id === sectionId)?.exercises.find((item) => item.name === name) ?? null
}
function sig(ex) {
  return (ex?.sets ?? []).map((set) => `${set.reps ?? ''}@${set.loadText ?? ''}`).join('|')
}
function includesSig(week, dayNumber, name, tokens) {
  const actual = sig(exercise(week, dayNumber, name))
  const missing = tokens.filter((token) => !actual.includes(token))
  assert(week, `D${dayNumber} ${name}`, missing.length === 0, `missing ${missing.join(', ')} from ${actual}`)
}

for (const weekNumber of [3,4,5,6]) {
  const week = weeks.get(weekNumber)
  assert(weekNumber, 'week exists', Boolean(week))
  assert(weekNumber, '7 days', week?.days.length === 7, `actual ${week?.days.length}`)
  assert(weekNumber, 'date sequence', JSON.stringify(week?.days.map((d) => d.date)) === JSON.stringify(expectedDates[weekNumber]))
  assert(weekNumber, 'range endpoints', week?.start === expectedDates[weekNumber][0] && week?.end === expectedDates[weekNumber][6])
  assert(weekNumber, 'Day 7 governed rest', day(weekNumber, 7)?.restDay === true && day(weekNumber, 7)?.readinessRule.includes('Rest.'))
  assert(weekNumber, 'Day 5 FLEX governance', day(weekNumber, 5)?.readinessRule.includes('Yellow') || day(weekNumber, 5)?.readinessRule.includes('YELLOW'))
  assert(weekNumber, 'Day 6 anti-duplication', Boolean(day(weekNumber, 6)?.readinessRule.includes('omit the separate') && day(weekNumber, 6)?.readinessRule.includes('sled finisher')))
}

// Week 3 exact-source spot checks.
includesSig(3,1,'Front Squat',['5@105 lb','4@120 lb','3@135 lb','3@145 lb','4@130 lb'])
includesSig(3,1,'Bench Press',['4@130 lb','4@140 lb','3@150 lb','2@160 lb'])
includesSig(3,2,'Hang Power Clean',['3@100 lb','3@105 lb','3@110 lb'])
includesSig(3,2,'Clean Pull',['3@145 lb','2@155 lb','2@160 lb'])
includesSig(3,2,'Push Press',['5@75 lb','4@80 lb','3@85 lb'])
includesSig(3,4,'Deadlift',['4@170 lb','3@180 lb','2@190 lb','1–2@200 lb'])
includesSig(3,5,'Sled Push',['20–30m@sled + 45 lb'])
includesSig(3,6,'Bench Press',['5@100 lb','4@125 lb','3@140 lb','3@150 lb','4@140 lb'])
includesSig(3,6,'RDL',['10@115 lb'])
includesSig(3,6,'Sled Push',['20–30m@sled + 55 lb'])

// Week 4 exact-source spot checks, including corrected D1 values.
includesSig(4,1,'Front Squat',['5@110 lb','4@125 lb','3@140 lb','2–3@150 lb','4@135 lb'])
includesSig(4,1,'Bench Press',['3@135 lb','3@145 lb','2@155 lb','2@165 lb'])
includesSig(4,2,'Hang Power Clean',['3@105 lb','3@110 lb','2@115 lb'])
includesSig(4,2,'Clean Pull',['2@150 lb','2@160 lb','2@165 lb'])
includesSig(4,4,'Deadlift',['3@175 lb','3@185 lb','2@195 lb','1@205 lb'])
includesSig(4,5,'Suitcase March',['20 steps/side@24 kg (55 lb) KB'])
includesSig(4,5,'Sled Push',['20–30m@sled + 55 lb'])
includesSig(4,6,'Bench Press',['5@100 lb','4@130 lb','3@145 lb','3@155 lb','4@145 lb'])
includesSig(4,6,'Cable Pull-Through',['12@50 lb'])
includesSig(4,6,'JM Press',['6–10@60 lb'])

// Week 5 exact-source / crisp top-set checks.
includesSig(5,1,'Front Squat',['4@115 lb','3@130 lb','2@145 lb','1–2@155 lb','3@135 lb'])
includesSig(5,1,'Bench Press',['3@135 lb','2@150 lb','1@160 lb','1@170 lb','1@175 lb'])
assert(5, 'D1 175 bench is conditional on crisp quality', exercise(5,1,'Bench Press')?.sets.at(-1)?.notes === 'Only if crisp.')
includesSig(5,2,'Hang Power Clean',['2@110 lb','2@115 lb','2@120 lb','1@125 lb'])
assert(5, 'D2 125 clean is conditional on crisp quality', exercise(5,2,'Hang Power Clean')?.sets.at(-1)?.notes === 'Only if crisp.')
includesSig(5,2,'Clean Pull',['2@155 lb','2@165 lb','2@170 lb','1@175 lb'])
assert(5, 'D2 175 clean pull is conditional on crisp quality', exercise(5,2,'Clean Pull')?.sets.at(-1)?.notes === 'Only if crisp.')
includesSig(5,4,'Deadlift',['3@170 lb','2@185 lb','1@195 lb','1@205 lb','1@210 lb'])
assert(5, 'D4 210 deadlift is conditional on crisp quality', exercise(5,4,'Deadlift')?.sets.at(-1)?.notes === 'Only if crisp.')
includesSig(5,5,'Goblet Squat',['10@24 kg (55 lb) KB'])
includesSig(5,5,'Sled Push',['20–30m@sled + 65 lb'])
includesSig(5,6,'Bench Press',['5@105 lb','4@135 lb','3@150 lb','2–3@160 lb','4@145 lb'])
includesSig(5,6,'Cable Pull-Through',['12@55 lb'])
includesSig(5,6,'Sled Push',['20–30m@sled + 75 lb'])

// Week 6 deload checks.
assert(6, 'Week intent is deload', weeks.get(6)?.intent.toLowerCase().includes('deload'))
includesSig(6,1,'Front Squat',['5@90 lb','3@100 lb','2@110 lb'])
includesSig(6,1,'Bench Press',['5@105 lb','3@115 lb','2@125 lb'])
includesSig(6,1,'Belt Squat',['10@70 lb','8@90 lb'])
includesSig(6,2,'Hang Power Clean',['3@80 lb','3@85 lb','2@90 lb'])
includesSig(6,2,'Clean Pull',['3@115 lb','2@125 lb','2@135 lb'])
includesSig(6,2,'Push Press',['5@60 lb','3@65 lb'])
includesSig(6,3,'Backward Sled Drag',['20m@sled + 25 lb'])
assert(6, 'D3 step-up source range retained', exercise(6,3,'Step-Up')?.sets.length === 3 && exercise(6,3,'Step-Up')?.sets.at(-1)?.notes?.includes('2–3 sets'))
includesSig(6,4,'Deadlift',['5@135 lb','3@155 lb','2@170 lb'])
includesSig(6,5,'KB Swing',['10@12 kg (25 lb) KB'])
includesSig(6,5,'Plank Shoulder Tap',['12–16 total easy@'])
includesSig(6,6,'Bench Press',['5@95 lb','4@115 lb','3@125 lb'])
includesSig(6,6,'Hamstring Curl',['10@40 lb'])
includesSig(6,6,'Step-Up',['8/leg@bodyweight'])
includesSig(6,6,'Sled Push',['20m easy@sled + 25 lb'])
{
  const actual = sig(exerciseInSection(6,6,'sled-finish-d6','Backward Sled Drag'))
  assert(6, 'D6 Backward Sled Drag finisher', actual.includes('20m easy@sled + 25 lb'), actual)
}
const week6Text = JSON.stringify(weeks.get(6))
assert(6, 'No near-failure deload work', !week6Text.toLowerCase().includes('near failure'), 'Week 6 contains near-failure text')
assert(6, 'Deload language present on all training days', [1,2,4,5,6].every((d) => day(6,d)?.readinessRule.includes('DELOAD')))

// Cross-week calendar regression.
const allDates = [3,4,5,6].flatMap((weekNumber) => weeks.get(weekNumber).days.map((d) => d.date))
assert(0, 'Weeks 3–6 dates unique', new Set(allDates).size === 28)
for (let i = 1; i < allDates.length; i += 1) {
  const prev = new Date(`${allDates[i - 1]}T00:00:00Z`)
  const cur = new Date(`${allDates[i]}T00:00:00Z`)
  assert(0, `Calendar contiguous ${allDates[i - 1]}→${allDates[i]}`, cur - prev === 86400000)
}

for (const weekNumber of [3,4,5,6]) {
  const weekFailures = failures.filter((f) => f.week === weekNumber)
  console.log(JSON.stringify({
    result: weekFailures.length ? 'FAIL' : 'PASS',
    week: weekNumber,
    checks: passes.filter((p) => p.week === weekNumber).map((p) => p.label),
    failures: weekFailures,
  }, null, 2))
}

const regressionFailures = failures.filter((f) => f.week === 0)
console.log(JSON.stringify({
  result: regressionFailures.length ? 'FAIL' : 'PASS',
  scope: 'Weeks 3–6 calendar regression',
  failures: regressionFailures,
}, null, 2))

fs.rmSync(temp, { recursive: true, force: true })
if (failures.length) process.exit(1)
