import fs from 'node:fs'

const main = fs.readFileSync(new URL('../src/main.ts', import.meta.url), 'utf8')
const css = fs.readFileSync(new URL('../src/styles.css', import.meta.url), 'utf8')
const checks = [
  ['all major routes', /type Route = 'home' \| 'train' \| 'program' \| 'progress' \| 'exercises' \| 'coach' \| 'profile' \| 'more'/],
  ['mobile primary navigation', /\['home'.*'primary'\].*\['train'.*'primary'\].*\['program'.*'primary'\].*\['progress'.*'primary'\]/s],
  ['Home command hero', /class="command-hero"/],
  ['Home private readiness hydration', /latestReadiness\(state\.athlete\.id\)/],
  ['Train swipe viewport', /id="swipe-viewport"/],
  ['Train readiness first', /readinessPage\(day,/],
  ['Train section tap navigation', /data-session-index/],
  ['Train previous next controls', /data-session-step/],
  ['Train live section sync', /bindSwipeNavigation\(\)/],
  ['Program generic embedded weeks', /CROWNFORGE\.weekData\.map/],
  ['Program week jump navigator', /data-jump-week/],
  ['Exercise intelligence source counts', /EXERCISE_LIBRARY_SOURCE_TOTAL/],
  ['Exercise text search', /id="exercise-search"/],
  ['Exercise functional filters', /data-exercise-filter/],
  ['Exercise watch action', /data-watch/],
  ['Exercise info action', /data-exercise-info/],
  ['Exercise substitute action', /data-substitute/],
  ['Coach quick prompts', /data-coach-prompt/],
  ['Coach previous history', /What did I do last time\?/],
  ['Profile private vault', /Private Vault/],
  ['More utility route', /function morePage/],
  ['responsive mobile breakpoint', /@media\s*\(max-width:\s*(?:760|780)px\)/],
  ['Command UI session track styling', /\.session-track button/],
  ['Command UI filter styling', /\.filter-chips button/],
]

const failures = checks.filter(([, pattern]) => !(pattern.test(main) || pattern.test(css))).map(([label]) => label)
if (failures.length) {
  console.error(JSON.stringify({ result: 'FAIL', failures }, null, 2))
  process.exit(1)
}

console.log(JSON.stringify({
  result: 'PASS',
  checks: checks.map(([label]) => label),
  protectedBoundaries: [
    'UI audit does not modify Crownforge/Black Crown prescriptions',
    'Readiness hydration reads private local data only',
    'Exercise filters do not alter source-approved substitutions',
  ],
}, null, 2))
