import { spawnSync } from 'node:child_process'
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import { createRequire } from 'node:module'

const root = path.resolve(new URL('..', import.meta.url).pathname)
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'lmf-cf-regression-'))
const compile = spawnSync('tsc', [
  '--outDir', temp,
  '--target', 'ES2022',
  '--module', 'CommonJS',
  '--moduleResolution', 'Node',
  '--lib', 'ES2022,DOM',
  '--strict',
  '--skipLibCheck',
  path.join(root, 'src/data/programs.ts'),
  path.join(root, 'src/data/crownforge-weeks-3-6.ts'),
], { encoding: 'utf8' })
if (compile.status !== 0) {
  console.error(compile.stdout)
  console.error(compile.stderr)
  process.exit(compile.status || 1)
}

const require = createRequire(import.meta.url)
const programs = require(path.join(temp, 'programs.js'))
const weeks = programs.CROWNFORGE.weekData
const failures = []
const check = (label, condition, detail = '') => {
  if (!condition) failures.push({ label, detail })
}

check('registry has Weeks 1–6', JSON.stringify(weeks.map((w) => w.week)) === JSON.stringify([1,2,3,4,5,6]), JSON.stringify(weeks.map((w) => w.week)))
check('all weeks contain seven days', weeks.every((w) => w.days.length === 7))
const dates = weeks.flatMap((w) => w.days.map((d) => d.date))
check('42 unique dates', dates.length === 42 && new Set(dates).size === 42, `count=${dates.length}, unique=${new Set(dates).size}`)
check('starts Sep 7', dates[0] === '2026-09-07', dates[0])
check('ends Oct 18', dates.at(-1) === '2026-10-18', dates.at(-1))
for (let i = 1; i < dates.length; i += 1) {
  const prev = new Date(`${dates[i-1]}T00:00:00Z`)
  const cur = new Date(`${dates[i]}T00:00:00Z`)
  check(`contiguous ${dates[i-1]}→${dates[i]}`, cur - prev === 86400000)
}
check('all Day 7 rows are rest', weeks.every((w) => w.days[6].day === 7 && w.days[6].restDay === true))
check('all Day 5 rows preserve GPP/FLEX identity', weeks.every((w) => w.days[4].title.includes('GPP CONTROL DAY')))
check('all Day 6 rows preserve bench/chest identity', weeks.every((w) => w.days[5].title.includes('BENCH/CHEST BIAS')))
check('Week 6 is deload', weeks[5].intent.toLowerCase().includes('deload'))

for (const w of weeks) {
  for (const d of w.days) {
    check(`W${w.week}D${d.day} has sections`, d.sections.length > 0)
    for (const section of d.sections) {
      for (const exercise of section.exercises) {
        check(`W${w.week}D${d.day} ${exercise.name} has sets`, exercise.sets.length > 0)
        check(`W${w.week}D${d.day} ${exercise.name} has video query`, Boolean(exercise.videoQuery))
      }
    }
  }
}

const calendarSamples = [
  ['2026-09-07', 1, 1],
  ['2026-09-20', 2, 7],
  ['2026-09-21', 3, 1],
  ['2026-10-04', 4, 7],
  ['2026-10-05', 5, 1],
  ['2026-10-18', 6, 7],
]
for (const [date, week, day] of calendarSamples) {
  const result = programs.getCalendarDay(new Date(`${date}T12:00:00Z`))
  check(`calendar lookup ${date}`, result?.week === week && result?.day === day, JSON.stringify(result))
}

console.log(JSON.stringify({
  result: failures.length ? 'FAIL' : 'PASS',
  scope: 'Crownforge Weeks 1–6 regression',
  weekCount: weeks.length,
  dayCount: dates.length,
  start: dates[0],
  end: dates.at(-1),
  failures,
}, null, 2))

fs.rmSync(temp, { recursive: true, force: true })
if (failures.length) process.exit(1)
