import fs from 'node:fs'

const path = new URL('../src/data/programs.ts', import.meta.url)
const source = fs.readFileSync(path, 'utf8')
const start = source.indexOf('export const CROWNFORGE_WEEK_2: ProgramWeek = {')
const end = source.indexOf('\nexport const CROWNFORGE: PublicProgramDefinition = {', start)
if (start < 0 || end < 0) {
  console.error(JSON.stringify({ result: 'FAIL', reason: 'Week 2 block not found' }, null, 2))
  process.exit(1)
}
const week = source.slice(start, end)

function daySlice(day) {
  const marker = `\n    {\n      day: ${day},`
  const a = week.indexOf(marker)
  const b = day < 7 ? week.indexOf(`\n    {\n      day: ${day + 1},`, a) : week.lastIndexOf('\n  ],\n}')
  if (a < 0 || b < 0) throw new Error(`Day ${day} not found`)
  return week.slice(a, b)
}

const expectedDates = [
  '2026-09-14','2026-09-15','2026-09-16','2026-09-17','2026-09-18','2026-09-19','2026-09-20',
]
const failures = []
const checks = []
function requireIn(label, text, tokens) {
  const missing = tokens.filter((t) => !text.includes(t))
  if (missing.length) failures.push({ label, missing })
  else checks.push(label)
}
function forbidIn(label, text, tokens) {
  const stale = tokens.filter((t) => text.includes(t))
  if (stale.length) failures.push({ label, stale })
  else checks.push(label)
}

requireIn('Week metadata', week, [
  'week: 2', "start: '2026-09-14'", "end: '2026-09-20'",
  "intent: 'Accumulate the highest clean volume of the opening wave.'",
])

const dayCount = (week.match(/\n\s+day: [1-7],/g) || []).length
if (dayCount !== 7) failures.push({ label: 'Day count', expected: 7, actual: dayCount })
for (let i = 1; i <= 7; i += 1) requireIn(`Day ${i} date`, daySlice(i), [`date: '${expectedDates[i - 1]}'`])

requireIn('Day 1 exact primary/support', daySlice(1), [
  "s('R1', 5, '100 lb', 100, 'lb')", "s('R2', 4, '115 lb', 115, 'lb')",
  "s('R5', 3, '140 lb', 140, 'lb')", "s('R7', 4, '125 lb', 125, 'lb')",
  "s('R1', 5, '125 lb', 125, 'lb')", "s('R2', 4, '135 lb', 135, 'lb')",
  "s('R4', 2, '155 lb', 155, 'lb')", "'45 lb DBs'", "'sled + 35 lb'",
  "s('R1', 12, '100 lb', 100, 'lb')", "'35 lb DBs'", "'40 lb DBs'",
  "s('R1', 12, '45 lb')", "s('R3', 10, '65 lb')",
  "s('R1', 10, '105 lb', 105, 'lb')", "s('R3', 10, '145 lb', 145, 'lb')",
])

requireIn('Day 2 exact Olympic/push', daySlice(2), [
  "s('R1', 3, '95 lb', 95, 'lb')", "s('R2', 3, '100 lb', 100, 'lb')",
  "s('R3', 3, '105 lb', 105, 'lb')", "s('R6', 3, '105 lb', 105, 'lb')",
  "s('R1', 3, '140 lb', 140, 'lb')", "s('R2', 2, '150 lb', 150, 'lb')",
  "s('R3', 2, '155 lb', 155, 'lb')", "s('R4', 2, '155 lb', 155, 'lb')",
  "s('R1', 5, '70 lb', 70, 'lb')", "s('R2', 5, '75 lb', 75, 'lb')", "s('R3', 3, '80 lb', 80, 'lb')",
  "'20 lb/side'", "'40 lb'", "'20 lb DBs'", "Box Breathing",
])

requireIn('Day 3 recovery minimum', daySlice(3), [
  "'8 kg (20 lb) KB'", "'20 lb cable'", "'sled + 25 lb'", "'20 lb DBs'",
  "'20–30 min easy'", 'minimum recovery core',
])

requireIn('Day 4 exact pull/yoke/trunk', daySlice(4), [
  "s('R1', 5, '160 lb', 160, 'lb')", "s('R2', 4, '175 lb', 175, 'lb')",
  "s('R3', 3, '185 lb', 185, 'lb')", "s('R4', 2, '195 lb', 195, 'lb')",
  "'bodyweight OR 95 lb lat pulldown'", "'45 lb DBs'", "'55 lb'", "'20 lb/side'",
  "'sled + 35 lb'", "'45 lb'", "'40 lb'", "'55 lb DBs'",
  "s('1', '10–12', '55 lb DBs')", "s('2', '10–12', '55 lb DBs')", "s('3', '10–12', '55 lb DBs')",
])
forbidIn('Day 4 removed Week 1 shrug cap', daySlice(4), ['caps this Week 1 support exposure at one set'])

requireIn('Day 5 exact GPP', daySlice(5), [
  "'16 kg (35 lb) KB'", "'20 kg (45 lb) KB'", "'8 kg (20 lb) KB'",
  "'sled + 35 lb'", "'60–90 sec'", "Plank Shoulder Tap", "90/90 Breathing",
  'GREEN = full source GPP', 'Never make skipped GPP up on Day 6',
])

requireIn('Day 6 exact bench/full-body', daySlice(6), [
  "s('R1', 5, '95 lb', 95, 'lb')", "s('R2', 4, '120 lb', 120, 'lb')",
  "s('R3', 3, '135 lb', 135, 'lb')", "s('R5', 3, '145 lb', 145, 'lb')",
  "s('R8', 3, '145 lb', 145, 'lb')", "s('R10', 4, '135 lb', 135, 'lb')",
  "s('R1', 12, '100 lb', 100, 'lb')", "'95 lb'", "'sled + 45 lb'",
  "s('R1', 10, '105 lb', 105, 'lb')", "'40 lb'", "'20 lb/side'", "'50 lb'",
  "'12 kg (25 lb) KB'", "'16 kg (35 lb) KB'", "'sled + 35 lb'",
  'Default Omit After Full Day 5',
])

requireIn('Day 7 governed rest', daySlice(7), [
  "title: 'REST'", 'restDay: true', 'No make-up punishment', '20–40 min',
])

requireIn('Program registry includes Week 2', source.slice(end), [
  'weekData: [CROWNFORGE_WEEK_1, CROWNFORGE_WEEK_2, CROWNFORGE_WEEK_3, CROWNFORGE_WEEK_4, CROWNFORGE_WEEK_5, CROWNFORGE_WEEK_6]',
  'Weeks 1–6 are embedded from Crownforge Revised v2.1',
])

if (failures.length) {
  console.error(JSON.stringify({ result: 'FAIL', dayCount, failures }, null, 2))
  process.exit(1)
}

console.log(JSON.stringify({
  result: 'PASS',
  week: 2,
  dayCount,
  dates: expectedDates,
  audited: checks,
}, null, 2))
