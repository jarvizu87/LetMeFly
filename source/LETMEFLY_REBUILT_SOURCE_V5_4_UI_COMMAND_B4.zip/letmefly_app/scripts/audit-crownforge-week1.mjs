import fs from 'node:fs'

const path = new URL('../src/data/programs.ts', import.meta.url)
const source = fs.readFileSync(path, 'utf8')

const required = [
  // Day 2 exact source
  "s('R1', 3, '90 lb', 90, 'lb')",
  "s('R2', 3, '95 lb', 95, 'lb')",
  "s('R6', 3, '100 lb', 100, 'lb')",
  "s('R1', 3, '135 lb', 135, 'lb')",
  "s('R2', 3, '145 lb', 145, 'lb')",
  "s('R3', 2, '150 lb', 150, 'lb')",
  "s('R1', 5, '65 lb', 65, 'lb')",
  "s('R2', 5, '70 lb', 70, 'lb')",
  "s('R3', 3, '75 lb', 75, 'lb')",
  "'15 lb/side'",
  "'10 lb DBs'",
  "'35 lb'",
  "'20 lb DBs'",
  // Day 4 exact source
  "'bodyweight OR 90 lb lat pulldown'",
  "'50 lb'",
  "'20 lb/side'",
  "'sled + 25 lb'",
  "'50 lb DBs'",
  // Day 6 exact source
  "ex('pulldown-d6', 'Wide or Neutral Pulldown'",
  "'90 lb'",
  "ex('rdl-d6', 'RDL'",
  "s('R1', 10, '95 lb', 95, 'lb')",
  "ex('jm-press', 'JM Press'",
  "'45 lb'",
  "ex('offset-rack-march', 'Offset Rack March'",
  "'16 kg (35 lb) KB'",
  "id: 'sled-finish-d6'",
  "'sled + 35 lb'",
]

const forbidden = [
  "ex('pulldown-d6', 'Wide or Neutral Pulldown', 'secondary', 'conditional', [s('R1', 10, '70 lb')",
  "ex('jm-press', 'JM Press', 'secondary', 'conditional', [s('R1', '6–10', '60 lb')",
  "ex('offset-rack-march', 'Offset Rack March', 'carry', 'conditional', [s('R1', '20 steps/side', '20 kg (45 lb) KB')",
  "ex('hamstring-curl-d6', 'Hamstring Curl'",
  "'Default omit if Day 5 was completed FULL.'",
]

const missing = required.filter((token) => !source.includes(token))
const stale = forbidden.filter((token) => source.includes(token))

if (missing.length || stale.length) {
  console.error(JSON.stringify({ result: 'FAIL', missing, stale }, null, 2))
  process.exit(1)
}

const week1Start = source.indexOf('export const CROWNFORGE_WEEK_1')
const week1End = source.indexOf('export const CROWNFORGE_WEEK_2', week1Start) >= 0
  ? source.indexOf('export const CROWNFORGE_WEEK_2', week1Start)
  : source.indexOf('export const CROWNFORGE: PublicProgramDefinition', week1Start)
const week1 = source.slice(week1Start, week1End)
const dayCount = (week1.match(/\n\s+day: [1-7],/g) || []).length
if (dayCount !== 7) {
  console.error(JSON.stringify({ result: 'FAIL', reason: 'expected 7 days', dayCount }, null, 2))
  process.exit(1)
}

console.log(JSON.stringify({
  result: 'PASS',
  dayCount,
  audited: [
    'Day 2 Olympic/push support exact loads',
    'Day 3 optional third step-up set',
    'Day 4 pull/yoke/trunk exact source',
    'Day 5 3-4 sled source range',
    'Day 6 full-body/chest/frontal/sled exact source',
  ],
}, null, 2))
