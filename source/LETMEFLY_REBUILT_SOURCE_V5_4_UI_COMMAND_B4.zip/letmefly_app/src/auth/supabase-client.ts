import { createClient } from '@supabase/supabase-js'
import { IndexedDbAuthStorage } from './auth-storage'

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL?.trim()
const supabasePublishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim()

export const cloudConfigured = Boolean(supabaseUrl && supabasePublishableKey)

// A local-only LetMeFly install must still boot when cloud configuration is absent.
// The fallback client is never treated as authenticated and its network calls are optional.
export const supabase = createClient(
  supabaseUrl || 'http://127.0.0.1:54321',
  supabasePublishableKey || 'local-only-placeholder-key',
  {
    auth: {
      persistSession: true,
      autoRefreshToken: true,
      detectSessionInUrl: false,
      flowType: 'pkce',
      storage: new IndexedDbAuthStorage(),
      storageKey: 'letmefly-auth-session',
    },
  },
)
