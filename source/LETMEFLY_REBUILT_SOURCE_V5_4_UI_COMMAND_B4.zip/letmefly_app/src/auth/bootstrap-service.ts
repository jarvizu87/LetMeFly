import type { User } from '@supabase/supabase-js'
import {
  ALL_STORES,
  DOMAIN_STORES,
  type DomainStoreName,
  type LocalDomainRecord,
  type SyncOutboxEntry,
  type SyncState,
  createInternalBackup,
  getAll,
  getOrCreateDeviceState,
  newId,
  openLetMeFlyDb,
  requestToPromise,
  transactionDone,
} from '../db/local-db'
import {
  makeOutboxEntry,
  putEntityWithOutbox,
  type LocalMutationContext,
} from '../db/local-mutations'
import { LetMeFlySyncEngine } from '../sync/sync-engine'
import type { SyncRemote } from '../sync/sync-types'
import type { CloudLinkDecision } from './auth-types'
import { supabase } from './supabase-client'

export interface LocalAthleteSummary {
  athleteId: string
  displayName: string
  meaningfulRecordCount: number
}

interface CloudAthleteRow {
  id: string
  owner_user_id: string
  display_name: string
}

export class CloudBootstrapService {
  constructor(private readonly remote: SyncRemote) {}

  async getLocalAthleteSummary(): Promise<LocalAthleteSummary | null> {
    const athletes = (await getAll<LocalDomainRecord>('athletes'))
      .filter((row) => !row.deleted_at)

    if (athletes.length === 0) return null
    if (athletes.length > 1) {
      throw new Error('Multiple active local athletes require manual resolution')
    }

    const athlete = athletes[0]
    const meaningfulRecordCount = await this.countMeaningfulRecords(athlete.id)

    return {
      athleteId: athlete.id,
      displayName: String(athlete.display_name ?? 'Athlete'),
      meaningfulRecordCount,
    }
  }

  async getCloudAthlete(): Promise<CloudAthleteRow | null> {
    const { data, error } = await supabase
      .from('athletes')
      .select('id,owner_user_id,display_name')
      .is('deleted_at', null)
      .maybeSingle()

    if (error) throw error
    return data
  }

  async decideLink(
    user: User,
  ): Promise<CloudLinkDecision> {
    const local = await this.getLocalAthleteSummary()
    const cloud = await this.getCloudAthlete()

    if (local && !cloud) {
      return {
        kind: 'bootstrap-local-to-cloud',
        athleteId: local.athleteId,
      }
    }

    if (local && cloud && local.athleteId === cloud.id) {
      return {
        kind: 'link-existing-same-athlete',
        athleteId: local.athleteId,
      }
    }

    if (!local && cloud) {
      return {
        kind: 'hydrate-cloud-to-empty-device',
        athleteId: cloud.id,
      }
    }

    if (local && cloud && local.athleteId !== cloud.id) {
      return {
        kind: 'manual-choice-required',
        localAthleteId: local.athleteId,
        cloudAthleteId: cloud.id,
      }
    }

    // A verified account with no cloud athlete and an empty local device does not
    // have enough athlete information to create a profile automatically.
    return { kind: 'no-local-no-cloud' }
  }

  async bootstrapLocalToCloud(
    user: User,
    athleteId: string,
    appVersion?: string,
  ): Promise<void> {
    await createInternalBackup('cloud-bootstrap')
    await this.ensureAllDirtyDomainRecordsQueued(athleteId)

    const device = await getOrCreateDeviceState(appVersion)
    await this.writeSyncState({
      athleteId,
      ownerUserId: user.id,
      deviceId: device.deviceId,
      linkedAt: new Date().toISOString(),
      lastSuccessfulAuthAt: new Date().toISOString(),
      lastSuccessfulSyncAt: null,
      lastChangeSeq: 0,
      cloudSchemaVersion: 1,
      bootstrapStatus: 'pending',
    })

    const engine = new LetMeFlySyncEngine(
      this.remote,
      athleteId,
      device.deviceId,
    )
    const result = await engine.syncNow()

    if (!result.authenticated) {
      throw new Error('Authentication ended during cloud bootstrap')
    }
    if (result.conflicts > 0 || result.rejected > 0 || result.pending > 0) {
      throw new Error(
        `Cloud bootstrap incomplete: ${result.pending} pending, ` +
          `${result.conflicts} conflicts, ${result.rejected} rejected`,
      )
    }

    const cloud = await this.getCloudAthlete()
    if (!cloud || cloud.id !== athleteId || cloud.owner_user_id !== user.id) {
      throw new Error('Cloud bootstrap verification failed')
    }

    await this.registerCurrentDevice(athleteId, appVersion)
    await engine.syncNow()
    await this.setBootstrapComplete(athleteId)
  }

  async linkExistingSameAthlete(
    user: User,
    athleteId: string,
    appVersion?: string,
  ): Promise<void> {
    const device = await getOrCreateDeviceState(appVersion)
    await this.writeSyncState({
      athleteId,
      ownerUserId: user.id,
      deviceId: device.deviceId,
      linkedAt: new Date().toISOString(),
      lastSuccessfulAuthAt: new Date().toISOString(),
      lastSuccessfulSyncAt: null,
      lastChangeSeq: 0,
      cloudSchemaVersion: 1,
      bootstrapStatus: 'complete',
    })

    const engine = new LetMeFlySyncEngine(
      this.remote,
      athleteId,
      device.deviceId,
    )
    await engine.syncNow()
    await this.registerCurrentDevice(athleteId, appVersion)
    await engine.syncNow()
  }

  async hydrateEmptyDevice(
    user: User,
    athleteId: string,
    appVersion?: string,
  ): Promise<void> {
    const local = await this.getLocalAthleteSummary()
    if (local) {
      throw new Error('Refusing cloud hydration over a populated local athlete')
    }

    const device = await getOrCreateDeviceState(appVersion)
    await this.writeSyncState({
      athleteId,
      ownerUserId: user.id,
      deviceId: device.deviceId,
      linkedAt: new Date().toISOString(),
      lastSuccessfulAuthAt: new Date().toISOString(),
      lastSuccessfulSyncAt: null,
      lastChangeSeq: 0,
      cloudSchemaVersion: 1,
      bootstrapStatus: 'pending',
    })

    const engine = new LetMeFlySyncEngine(
      this.remote,
      athleteId,
      device.deviceId,
      { pullBatchSize: 100, maxPullPages: 100 },
    )

    const result = await engine.syncNow()
    if (result.conflicts > 0 || result.rejected > 0) {
      throw new Error('Cloud hydration encountered a conflict/rejection')
    }

    const hydrated = await this.getLocalAthleteSummary()
    if (!hydrated || hydrated.athleteId !== athleteId) {
      throw new Error('Cloud hydration did not reconstruct the athlete locally')
    }

    await this.registerCurrentDevice(athleteId, appVersion)
    await engine.syncNow()
    await this.setBootstrapComplete(athleteId)
  }

  async ensureAllDirtyDomainRecordsQueued(
    athleteId: string,
  ): Promise<number> {
    const db = await openLetMeFlyDb()
    try {
      const tx = db.transaction(
        [...DOMAIN_STORES, 'syncOutbox'],
        'readwrite',
      )
      const outboxStore = tx.objectStore('syncOutbox')
      const existingOutbox = await requestToPromise<SyncOutboxEntry[]>(
        outboxStore.getAll(),
      )

      const latestQueuedVersion = new Map<string, number>()
      for (const op of existingOutbox) {
        const key = `${op.entityType}:${op.entityId}`
        latestQueuedVersion.set(
          key,
          Math.max(latestQueuedVersion.get(key) ?? 0, op.localVersion),
        )
      }

      const device = await getOrCreateDeviceState()
      const context: LocalMutationContext = {
        athleteId,
        deviceId: device.deviceId,
      }

      let queued = 0

      for (const storeName of DOMAIN_STORES) {
        const rows = await requestToPromise<LocalDomainRecord[]>(
          tx.objectStore(storeName).getAll(),
        )

        for (const row of rows) {
          const rowAthleteId =
            storeName === 'athletes'
              ? row.id
              : String(row.athlete_id ?? '')

          if (rowAthleteId !== athleteId || !row._local?.dirty) continue

          const key = `${storeName}:${row.id}`
          const queuedVersion = latestQueuedVersion.get(key) ?? 0
          if (queuedVersion >= row._local.localVersion) continue

          outboxStore.add(
            makeOutboxEntry(
              storeName,
              row,
              context,
              row.deleted_at ? 'delete' : 'upsert',
            ),
          )
          latestQueuedVersion.set(key, row._local.localVersion)
          queued += 1
        }
      }

      await transactionDone(tx)
      return queued
    } finally {
      db.close()
    }
  }

  private async registerCurrentDevice(
    athleteId: string,
    appVersion?: string,
  ): Promise<void> {
    const device = await getOrCreateDeviceState(appVersion)
    const context: LocalMutationContext = {
      athleteId,
      deviceId: device.deviceId,
    }

    await putEntityWithOutbox(
      'devices',
      {
        id: device.deviceId,
        athlete_id: athleteId,
        label: device.label ?? null,
        platform: device.platform ?? navigator.userAgent,
        app_version: appVersion ?? null,
        first_seen_at: device.createdAt,
        last_seen_at: new Date().toISOString(),
        last_sync_at: new Date().toISOString(),
        revoked_at: null,
      },
      context,
    )
  }

  private async writeSyncState(state: SyncState): Promise<void> {
    const db = await openLetMeFlyDb()
    try {
      const tx = db.transaction('syncState', 'readwrite')
      tx.objectStore('syncState').put(state)
      await transactionDone(tx)
    } finally {
      db.close()
    }
  }

  private async setBootstrapComplete(athleteId: string): Promise<void> {
    const db = await openLetMeFlyDb()
    try {
      const tx = db.transaction('syncState', 'readwrite')
      const store = tx.objectStore('syncState')
      const state = await requestToPromise<SyncState | undefined>(
        store.get(athleteId),
      )
      if (!state) throw new Error('Missing local sync state')

      store.put({
        ...state,
        bootstrapStatus: 'complete',
        lastSuccessfulSyncAt: new Date().toISOString(),
      } satisfies SyncState)
      await transactionDone(tx)
    } finally {
      db.close()
    }
  }

  private async countMeaningfulRecords(athleteId: string): Promise<number> {
    const db = await openLetMeFlyDb()
    try {
      const stores = DOMAIN_STORES.filter((name) => name !== 'athletes')
      const tx = db.transaction(stores, 'readonly')
      let count = 0

      for (const storeName of stores) {
        const rows = await requestToPromise<LocalDomainRecord[]>(
          tx.objectStore(storeName).getAll(),
        )
        count += rows.filter((row) => row.athlete_id === athleteId).length
      }

      await transactionDone(tx)
      return count
    } finally {
      db.close()
    }
  }
}
