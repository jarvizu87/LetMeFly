import type { Session, User } from '@supabase/supabase-js'

export type LetMeFlyAuthMode =
  | 'LOCAL_ONLY'
  | 'OTP_REQUESTED'
  | 'AUTHENTICATING'
  | 'AUTHENTICATED_UNLINKED'
  | 'CLOUD_BOOTSTRAP'
  | 'SYNC_ENABLED'
  | 'SYNC_PAUSED_OFFLINE'
  | 'REAUTH_REQUIRED'
  | 'SIGNED_OUT_LOCAL_DATA'
  | 'DEVICE_WIPED'

export interface AccountSnapshot {
  mode: LetMeFlyAuthMode
  session: Session | null
  user: User | null
  email: string | null
  localAthleteId: string | null
  cloudAthleteId: string | null
  pending: number
  conflicts: number
  lastSyncAt: string | null
  lastError: string | null
}

export type CloudLinkDecision =
  | { kind: 'bootstrap-local-to-cloud'; athleteId: string }
  | { kind: 'link-existing-same-athlete'; athleteId: string }
  | { kind: 'hydrate-cloud-to-empty-device'; athleteId: string }
  | {
      kind: 'manual-choice-required'
      localAthleteId: string
      cloudAthleteId: string
    }
  | { kind: 'no-local-no-cloud' }
