import type {
  AuthChangeEvent,
  Session,
  Subscription,
  User,
} from '@supabase/supabase-js'
import { supabase } from './supabase-client'

export type OtpPurpose = 'enable-sync' | 'sign-in' | 'reauthenticate'

export interface VerifiedAuth {
  user: User
  session: Session
}

export class LetMeFlyAuthService {
  async requestEmailOtp(
    email: string,
    purpose: OtpPurpose,
    captchaToken?: string,
  ): Promise<void> {
    const normalized = email.trim().toLowerCase()
    if (!normalized) throw new Error('Email is required')

    const { error } = await supabase.auth.signInWithOtp({
      email: normalized,
      options: {
        shouldCreateUser: purpose === 'enable-sync',
        captchaToken,
      },
    })

    if (error) throw error
  }

  async verifyEmailOtp(
    email: string,
    token: string,
  ): Promise<VerifiedAuth> {
    const normalized = email.trim().toLowerCase()
    const normalizedToken = token.replace(/\s+/g, '')

    if (!/^\d{6,10}$/.test(normalizedToken)) {
      throw new Error('Enter the complete sign-in code')
    }

    const { data, error } = await supabase.auth.verifyOtp({
      email: normalized,
      token: normalizedToken,
      type: 'email',
    })

    if (error) throw error
    if (!data.user || !data.session) {
      throw new Error('OTP verification did not create a valid session')
    }

    // Server-backed identity verification before any local/cloud linking.
    const verified = await supabase.auth.getUser()
    if (verified.error || !verified.data.user) {
      throw verified.error ?? new Error('Unable to verify authenticated user')
    }

    if (verified.data.user.id !== data.user.id) {
      throw new Error('Authenticated identity mismatch')
    }

    return {
      user: verified.data.user,
      session: data.session,
    }
  }

  async getTrustedCurrentUser(): Promise<User | null> {
    const { data, error } = await supabase.auth.getUser()
    if (error) return null
    return data.user
  }

  async getLocalSession(): Promise<Session | null> {
    const { data, error } = await supabase.auth.getSession()
    if (error) return null
    return data.session
  }

  onAuthStateChange(
    listener: (event: AuthChangeEvent, session: Session | null) => void,
  ): Subscription {
    const { data } = supabase.auth.onAuthStateChange((event, session) => {
      // Keep this callback synchronous/lightweight.
      // Consumers can schedule async follow-up outside the callback.
      listener(event, session)
    })
    return data.subscription
  }

  async signOutThisDevice(): Promise<void> {
    const { error } = await supabase.auth.signOut({ scope: 'local' })
    if (error) throw error
  }

  async signOutAllDevices(): Promise<void> {
    const { error } = await supabase.auth.signOut({ scope: 'global' })
    if (error) throw error
  }
}
