import type { AccountSnapshot } from './auth-types'

export interface PrivateVaultViewModel {
  vaultLabel: 'READY' | 'SAVED' | 'EMPTY'
  accountLabel: string
  cloudLabel:
    | 'OFF'
    | 'SYNCED'
    | 'OFFLINE'
    | 'SIGN-IN REQUIRED'
    | 'LINK REQUIRED'
    | 'CONNECTING'
    | 'DEVICE DATA REMOVED'
  pendingLabel: string | null
  conflictLabel: string | null
  lastSyncLabel: string | null
  workoutAvailable: boolean
}

export function toPrivateVaultViewModel(
  state: AccountSnapshot,
  athleteDisplayName?: string | null,
): PrivateVaultViewModel {
  const accountLabel =
    state.email ??
    athleteDisplayName ??
    (state.localAthleteId ? 'LOCAL ONLY' : 'NO ATHLETE')

  switch (state.mode) {
    case 'LOCAL_ONLY':
    case 'SIGNED_OUT_LOCAL_DATA':
      return {
        vaultLabel: state.localAthleteId ? 'READY' : 'EMPTY',
        accountLabel,
        cloudLabel: 'OFF',
        pendingLabel:
          state.pending > 0 ? `${state.pending} changes local only` : null,
        conflictLabel: null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'OTP_REQUESTED':
    case 'AUTHENTICATING':
    case 'CLOUD_BOOTSTRAP':
      return {
        vaultLabel: state.localAthleteId ? 'SAVED' : 'EMPTY',
        accountLabel,
        cloudLabel: 'CONNECTING',
        pendingLabel:
          state.pending > 0 ? `${state.pending} pending` : null,
        conflictLabel: null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'AUTHENTICATED_UNLINKED':
      return {
        vaultLabel: state.localAthleteId ? 'SAVED' : 'EMPTY',
        accountLabel,
        cloudLabel: 'LINK REQUIRED',
        pendingLabel:
          state.pending > 0 ? `${state.pending} pending` : null,
        conflictLabel:
          state.conflicts > 0
            ? `${state.conflicts} conflicts need review`
            : null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'SYNC_ENABLED':
      return {
        vaultLabel: 'READY',
        accountLabel,
        cloudLabel: 'SYNCED',
        pendingLabel:
          state.pending > 0 ? `${state.pending} pending` : null,
        conflictLabel:
          state.conflicts > 0
            ? `${state.conflicts} conflicts need review`
            : null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'SYNC_PAUSED_OFFLINE':
      return {
        vaultLabel: 'SAVED',
        accountLabel,
        cloudLabel: 'OFFLINE',
        pendingLabel: `${state.pending} pending`,
        conflictLabel:
          state.conflicts > 0
            ? `${state.conflicts} conflicts need review`
            : null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'REAUTH_REQUIRED':
      return {
        vaultLabel: state.localAthleteId ? 'SAVED' : 'EMPTY',
        accountLabel,
        cloudLabel: 'SIGN-IN REQUIRED',
        pendingLabel:
          state.pending > 0 ? `${state.pending} pending` : null,
        conflictLabel:
          state.conflicts > 0
            ? `${state.conflicts} conflicts need review`
            : null,
        lastSyncLabel: formatLastSync(state.lastSyncAt),
        workoutAvailable: Boolean(state.localAthleteId),
      }

    case 'DEVICE_WIPED':
      return {
        vaultLabel: 'EMPTY',
        accountLabel: 'NO LOCAL DATA',
        cloudLabel: 'DEVICE DATA REMOVED',
        pendingLabel: null,
        conflictLabel: null,
        lastSyncLabel: null,
        workoutAvailable: false,
      }
  }
}

function formatLastSync(iso: string | null): string | null {
  if (!iso) return null
  const time = Date.parse(iso)
  if (!Number.isFinite(time)) return null

  const seconds = Math.max(0, Math.round((Date.now() - time) / 1000))
  if (seconds < 60) return 'just now'

  const minutes = Math.floor(seconds / 60)
  if (minutes < 60) return `${minutes} min ago`

  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours} hr ago`

  const days = Math.floor(hours / 24)
  return `${days} d ago`
}
