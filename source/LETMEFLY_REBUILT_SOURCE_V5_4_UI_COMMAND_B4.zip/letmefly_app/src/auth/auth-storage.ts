// LetMeFly Stage 8 — IndexedDB storage adapter for Supabase Auth.
// This is lifecycle separation, not an XSS security boundary.

const AUTH_DB_NAME = 'letmefly-auth'
const AUTH_DB_VERSION = 1
const AUTH_STORE = 'keyval'

function requestToPromise<T>(request: IDBRequest<T>): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    request.onsuccess = () => resolve(request.result)
    request.onerror = () =>
      reject(request.error ?? new Error('Auth IndexedDB request failed'))
  })
}

function transactionDone(tx: IDBTransaction): Promise<void> {
  return new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve()
    tx.onabort = () =>
      reject(tx.error ?? new Error('Auth IndexedDB transaction aborted'))
    tx.onerror = () =>
      reject(tx.error ?? new Error('Auth IndexedDB transaction failed'))
  })
}

function openAuthDb(): Promise<IDBDatabase> {
  return new Promise<IDBDatabase>((resolve, reject) => {
    const request = indexedDB.open(AUTH_DB_NAME, AUTH_DB_VERSION)

    request.onupgradeneeded = () => {
      const db = request.result
      if (!db.objectStoreNames.contains(AUTH_STORE)) {
        db.createObjectStore(AUTH_STORE, { keyPath: 'key' })
      }
    }

    request.onsuccess = () => {
      const db = request.result
      db.onversionchange = () => db.close()
      resolve(db)
    }

    request.onerror = () =>
      reject(request.error ?? new Error('Failed to open auth IndexedDB'))
    request.onblocked = () =>
      reject(new Error('Auth IndexedDB upgrade blocked by another tab'))
  })
}

export interface SupabaseAuthStorage {
  getItem(key: string): Promise<string | null>
  setItem(key: string, value: string): Promise<void>
  removeItem(key: string): Promise<void>
}

export class IndexedDbAuthStorage implements SupabaseAuthStorage {
  async getItem(key: string): Promise<string | null> {
    const db = await openAuthDb()
    try {
      const tx = db.transaction(AUTH_STORE, 'readonly')
      const row = await requestToPromise<{ key: string; value: string } | undefined>(
        tx.objectStore(AUTH_STORE).get(key),
      )
      await transactionDone(tx)
      return row?.value ?? null
    } finally {
      db.close()
    }
  }

  async setItem(key: string, value: string): Promise<void> {
    const db = await openAuthDb()
    try {
      const tx = db.transaction(AUTH_STORE, 'readwrite')
      tx.objectStore(AUTH_STORE).put({ key, value })
      await transactionDone(tx)
    } finally {
      db.close()
    }
  }

  async removeItem(key: string): Promise<void> {
    const db = await openAuthDb()
    try {
      const tx = db.transaction(AUTH_STORE, 'readwrite')
      tx.objectStore(AUTH_STORE).delete(key)
      await transactionDone(tx)
    } finally {
      db.close()
    }
  }
}

export async function wipeAuthDatabase(): Promise<void> {
  try {
    const db = await openAuthDb()
    db.close()
  } catch {
    // If it cannot be opened, still attempt deletion.
  }

  await new Promise<void>((resolve, reject) => {
    const request = indexedDB.deleteDatabase(AUTH_DB_NAME)
    request.onsuccess = () => resolve()
    request.onerror = () =>
      reject(request.error ?? new Error('Failed to wipe auth database'))
    request.onblocked = () =>
      reject(new Error('Auth database wipe blocked by another open tab'))
  })
}
