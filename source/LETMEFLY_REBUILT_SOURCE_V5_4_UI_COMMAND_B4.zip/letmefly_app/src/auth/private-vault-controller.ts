import type { AuthChangeEvent, Session } from '@supabase/supabase-js'
import {
  type SyncState,
  getAll,
  getStorageEstimate,
  wipePrivateDatabase,
} from '../db/local-db'
import { pendingCount } from '../sync/local-sync'
import type { SyncRemote } from '../sync/sync-types'
import { LetMeFlySyncEngine } from '../sync/sync-engine'
import { wipeAuthDatabase } from './auth-storage'
import type {
  AccountSnapshot,
  CloudLinkDecision,
  LetMeFlyAuthMode,
} from './auth-types'
import { LetMeFlyAuthService, type OtpPurpose } from './auth-service'
import { CloudBootstrapService } from './bootstrap-service'

type Listener = (snapshot: AccountSnapshot) => void

export class PrivateVaultController {
  private listeners = new Set<Listener>()
  private authSubscription: { unsubscribe(): void } | null = null

  private state: AccountSnapshot = {
    mode: 'LOCAL_ONLY',
    session: null,
    user: null,
    email: null,
    localAthleteId: null,
    cloudAthleteId: null,
    pending: 0,
    conflicts: 0,
    lastSyncAt: null,
    lastError: null,
  }

  constructor(
    private readonly auth: LetMeFlyAuthService,
    private readonly bootstrap: CloudBootstrapService,
    private readonly remote: SyncRemote,
    private readonly appVersion?: string,
  ) {}

  get snapshot(): AccountSnapshot {
    return this.state
  }

  subscribe(listener: Listener): () => void {
    this.listeners.add(listener)
    listener(this.state)
    return () => this.listeners.delete(listener)
  }

  async initialize(): Promise<void> {
    const local = await this.bootstrap.getLocalAthleteSummary()

    this.patch({
      localAthleteId: local?.athleteId ?? null,
    })

    this.authSubscription = this.auth.onAuthStateChange(
      (event, session) => {
        queueMicrotask(() => {
          void this.handleAuthEvent(event, session)
        })
      },
    )

    const session = await this.auth.getLocalSession()
    if (!session) {
      this.patch({
        mode: local ? 'LOCAL_ONLY' : 'LOCAL_ONLY',
        session: null,
        user: null,
        email: null,
      })
      return
    }

    const user = await this.auth.getTrustedCurrentUser()
    if (!user) {
      this.patch({
        mode: local ? 'REAUTH_REQUIRED' : 'LOCAL_ONLY',
        session: null,
        user: null,
        email: null,
      })
      return
    }

    this.patch({
      mode: 'AUTHENTICATED_UNLINKED',
      session,
      user,
      email: user.email ?? null,
    })

    await this.reconcileAuthenticatedUser(user.id)
  }

  dispose(): void {
    this.authSubscription?.unsubscribe()
    this.authSubscription = null
    this.listeners.clear()
  }

  async requestCode(email: string, purpose: OtpPurpose): Promise<void> {
    this.patch({ mode: 'OTP_REQUESTED', lastError: null })
    try {
      await this.auth.requestEmailOtp(email, purpose)
    } catch (error) {
      this.patch({
        mode: this.state.localAthleteId ? 'LOCAL_ONLY' : 'LOCAL_ONLY',
        lastError: errorMessage(error),
      })
      throw error
    }
  }

  async verifyCode(
    email: string,
    token: string,
  ): Promise<CloudLinkDecision> {
    this.patch({ mode: 'AUTHENTICATING', lastError: null })

    try {
      const verified = await this.auth.verifyEmailOtp(email, token)
      this.patch({
        mode: 'AUTHENTICATED_UNLINKED',
        session: verified.session,
        user: verified.user,
        email: verified.user.email ?? email,
      })

      const decision = await this.bootstrap.decideLink(verified.user)
      await this.executeLinkDecision(verified.user.id, decision)
      return decision
    } catch (error) {
      this.patch({
        mode: this.state.localAthleteId
          ? 'REAUTH_REQUIRED'
          : 'LOCAL_ONLY',
        lastError: errorMessage(error),
      })
      throw error
    }
  }

  async syncNow(): Promise<void> {
    const athleteId =
      this.state.cloudAthleteId ?? this.state.localAthleteId

    if (!athleteId) return

    const states = await getAll<SyncState>('syncState')
    const syncState = states.find((row) => row.athleteId === athleteId)
    if (!syncState) return

    this.patch({ lastError: null })

    const engine = new LetMeFlySyncEngine(
      this.remote,
      athleteId,
      syncState.deviceId,
    )

    const result = await engine.syncNow()
    const conflicts = await this.countConflicts(athleteId)

    let mode: LetMeFlyAuthMode = 'SYNC_ENABLED'
    if (result.offline) mode = 'SYNC_PAUSED_OFFLINE'
    else if (!result.authenticated) mode = 'REAUTH_REQUIRED'

    this.patch({
      mode,
      pending: result.pending,
      conflicts,
      lastSyncAt:
        result.authenticated && !result.offline
          ? new Date().toISOString()
          : this.state.lastSyncAt,
    })
  }

  async signOutKeepOfflineData(): Promise<void> {
    const local = await this.bootstrap.getLocalAthleteSummary()

    await this.auth.signOutThisDevice()
    await wipeAuthDatabase()

    this.patch({
      mode: 'SIGNED_OUT_LOCAL_DATA',
      session: null,
      user: null,
      email: null,
      localAthleteId: local?.athleteId ?? this.state.localAthleteId,
      cloudAthleteId: null,
      lastError: null,
    })
  }

  async signOutAllDevicesKeepLocalData(): Promise<void> {
    const local = await this.bootstrap.getLocalAthleteSummary()

    await this.auth.signOutAllDevices()
    await wipeAuthDatabase()

    this.patch({
      mode: 'SIGNED_OUT_LOCAL_DATA',
      session: null,
      user: null,
      email: null,
      localAthleteId: local?.athleteId ?? this.state.localAthleteId,
      cloudAthleteId: null,
      lastError: null,
    })
  }

  async removePrivateDataFromThisDevice(): Promise<void> {
    // The UI must warn about pending/unsynced work before calling this.
    try {
      await this.auth.signOutThisDevice()
    } catch {
      // Local device wipe should still be possible if cloud logout is unreachable.
    }

    await wipeAuthDatabase()
    await wipePrivateDatabase()

    this.patch({
      mode: 'DEVICE_WIPED',
      session: null,
      user: null,
      email: null,
      localAthleteId: null,
      cloudAthleteId: null,
      pending: 0,
      conflicts: 0,
      lastSyncAt: null,
      lastError: null,
    })
  }

  async getLocalStorageEstimate() {
    return getStorageEstimate()
  }

  private async executeLinkDecision(
    userId: string,
    decision: CloudLinkDecision,
  ): Promise<void> {
    const user = this.state.user
    if (!user || user.id !== userId) {
      throw new Error('Authenticated user changed during linking')
    }

    switch (decision.kind) {
      case 'bootstrap-local-to-cloud':
        this.patch({ mode: 'CLOUD_BOOTSTRAP' })
        await this.bootstrap.bootstrapLocalToCloud(
          user,
          decision.athleteId,
          this.appVersion,
        )
        this.patch({
          mode: 'SYNC_ENABLED',
          localAthleteId: decision.athleteId,
          cloudAthleteId: decision.athleteId,
        })
        await this.syncNow()
        return

      case 'link-existing-same-athlete':
        await this.bootstrap.linkExistingSameAthlete(
          user,
          decision.athleteId,
          this.appVersion,
        )
        this.patch({
          mode: 'SYNC_ENABLED',
          localAthleteId: decision.athleteId,
          cloudAthleteId: decision.athleteId,
        })
        await this.syncNow()
        return

      case 'hydrate-cloud-to-empty-device':
        this.patch({ mode: 'CLOUD_BOOTSTRAP' })
        await this.bootstrap.hydrateEmptyDevice(
          user,
          decision.athleteId,
          this.appVersion,
        )
        this.patch({
          mode: 'SYNC_ENABLED',
          localAthleteId: decision.athleteId,
          cloudAthleteId: decision.athleteId,
        })
        await this.syncNow()
        return

      case 'manual-choice-required':
        this.patch({
          mode: 'AUTHENTICATED_UNLINKED',
          localAthleteId: decision.localAthleteId,
          cloudAthleteId: decision.cloudAthleteId,
          lastError:
            'Local and cloud athletes differ. Automatic merge is blocked.',
        })
        return

      case 'no-local-no-cloud':
        this.patch({
          mode: 'AUTHENTICATED_UNLINKED',
          lastError:
            'No athlete profile exists locally or in the cloud. Create a local profile first.',
        })
        return
    }
  }

  private async reconcileAuthenticatedUser(
    expectedUserId: string,
  ): Promise<void> {
    const user = await this.auth.getTrustedCurrentUser()
    if (!user || user.id !== expectedUserId) {
      this.patch({ mode: 'REAUTH_REQUIRED' })
      return
    }

    const decision = await this.bootstrap.decideLink(user)
    await this.executeLinkDecision(user.id, decision)
  }

  private async handleAuthEvent(
    event: AuthChangeEvent,
    session: Session | null,
  ): Promise<void> {
    if (event === 'SIGNED_OUT') {
      // IMPORTANT: never wipe athlete IndexedDB merely because Supabase says signed out.
      this.patch({
        mode: this.state.localAthleteId
          ? 'SIGNED_OUT_LOCAL_DATA'
          : 'LOCAL_ONLY',
        session: null,
        user: null,
        email: null,
        cloudAthleteId: null,
      })
      return
    }

    if (event === 'TOKEN_REFRESHED' || event === 'SIGNED_IN') {
      if (session) {
        this.patch({
          session,
          user: session.user,
          email: session.user.email ?? null,
        })
      }
      return
    }

    if (event === 'INITIAL_SESSION' && session) {
      this.patch({
        session,
        user: session.user,
        email: session.user.email ?? null,
      })
    }
  }

  private async countConflicts(athleteId: string): Promise<number> {
    const rows = await getAll<{
      athleteId: string
      resolvedAt: string | null
    }>('syncConflicts')

    return rows.filter(
      (row) => row.athleteId === athleteId && row.resolvedAt == null,
    ).length
  }

  private patch(patch: Partial<AccountSnapshot>): void {
    this.state = { ...this.state, ...patch }
    for (const listener of this.listeners) listener(this.state)
  }
}

function errorMessage(error: unknown): string {
  return error instanceof Error ? error.message : String(error)
}
