import { CROWNFORGE_WEEK_3, CROWNFORGE_WEEK_4, CROWNFORGE_WEEK_5, CROWNFORGE_WEEK_6 } from './crownforge-weeks-3-6'

export type ExerciseCategory =
  | 'primary'
  | 'secondary'
  | 'power'
  | 'kettlebell'
  | 'sled'
  | 'core'
  | 'carry'
  | 'recovery'

export interface ProgramSet {
  label: string
  reps?: number | string
  loadValue?: number
  loadUnit?: 'lb' | 'kg'
  loadText?: string
  duration?: string
  distance?: string
  notes?: string
}

export interface ProgramExercise {
  id: string
  name: string
  category: ExerciseCategory
  priority: 'mandatory' | 'conditional' | 'optional'
  sets: ProgramSet[]
  notes?: string
  coaching?: string
  videoQuery?: string
}

export interface WorkoutSection {
  id: string
  title: string
  subtitle?: string
  exercises: ProgramExercise[]
}

export interface ProgramDay {
  day: number
  date: string
  title: string
  role: string
  readinessRule: string
  cutOrder?: string
  restDay?: boolean
  sections: WorkoutSection[]
}

export interface ProgramWeek {
  week: number
  start: string
  end: string
  intent: string
  days: ProgramDay[]
}

export interface PublicProgramDefinition {
  key: 'crownforge' | 'black-crown'
  name: string
  version: string
  sourceEngine?: string
  description: string
  weeks: number
  trainingDaysPerWeek: number
  status: 'active-source' | 'catalog-only'
  sourceNotes: string[]
  weekData: ProgramWeek[]
}

const s = (
  label: string,
  reps?: number | string,
  loadText?: string,
  loadValue?: number,
  loadUnit?: 'lb' | 'kg',
  notes?: string,
): ProgramSet => ({ label, reps, loadText, loadValue, loadUnit, notes })

const ex = (
  id: string,
  name: string,
  category: ExerciseCategory,
  priority: ProgramExercise['priority'],
  sets: ProgramSet[],
  notes?: string,
  coaching?: string,
): ProgramExercise => ({
  id,
  name,
  category,
  priority,
  sets,
  notes,
  coaching,
  videoQuery: `${name} exercise tutorial`,
})

export const CROWNFORGE_WEEK_1: ProgramWeek = {
  week: 1,
  start: '2026-09-07',
  end: '2026-09-13',
  intent: 'Build clean opening-wave volume while preserving barbell and Olympic quality.',
  days: [
    {
      day: 1,
      date: '2026-09-07',
      title: 'LOWER + PUSH STRENGTH / GLUTES',
      role: 'Strength-density day. Main lifts ramp; final heavy sets may be focused alone.',
      readinessRule: 'Front Squat + Bench are mandatory. Yellow keeps clean primary work and highest-value chest/glute support. Stop the ramp before a grinder.',
      cutOrder: 'Lowest priority first: lateral raise, lower-value accessories. Never compress primary rest to preserve density.',
      sections: [
        {
          id: 'warmup',
          title: 'Warm-Up',
          exercises: [
            ex('bike-incline-walk', 'Bike / Incline Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('backward-sled-drag-primer', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m'), s('2', '20m')]),
            ex('glute-bridge-iso', 'Glute Bridge ISO', 'secondary', 'mandatory', [s('1', '20 sec'), s('2', '20 sec')]),
            ex('tibialis-raise', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20')]),
            ex('front-squat-bench-ramp', 'Front Squat + Bench Ramp Sets', 'primary', 'mandatory', [s('Ramp', 'Empty bar → first work set')]),
          ],
        },
        {
          id: 'main',
          title: 'Main Strength Circuit',
          subtitle: 'Drop completed support movements; remaining main-lift sets finish alone. Full rest always wins.',
          exercises: [
            ex('front-squat', 'Front Squat', 'primary', 'mandatory', [
              s('R1', 5, '95 lb', 95, 'lb'),
              s('R2', 4, '110 lb', 110, 'lb'),
              s('R3', 3, '125 lb', 125, 'lb'),
              s('R4', 3, '125 lb', 125, 'lb'),
              s('R5', 3, '135 lb', 135, 'lb'),
              s('R6', 3, '135 lb', 135, 'lb'),
              s('R7', 4, '120 lb', 120, 'lb'),
            ], 'Barbell quality overrides circuit density.'),
            ex('bench-press', 'Bench Press', 'primary', 'mandatory', [
              s('R1', 5, '120 lb', 120, 'lb'),
              s('R2', 5, '130 lb', 130, 'lb'),
              s('R3', 3, '140 lb', 140, 'lb'),
              s('R4', 2, '150 lb', 150, 'lb'),
            ]),
            ex('chest-supported-row', 'Chest-Supported Row', 'secondary', 'conditional', [
              s('R1', 10, '40 lb DBs'), s('R2', 10, '40 lb DBs'), s('R3', 10, '40 lb DBs'), s('R4', 10, '40 lb DBs'),
            ]),
            ex('kb-swing', 'KB Swing', 'kettlebell', 'conditional', [
              s('R1', 12, '16 kg (35 lb) KB'), s('R2', 12, '16 kg (35 lb) KB'), s('R3', 12, '16 kg (35 lb) KB'),
            ], 'Crisp hip snap.'),
            ex('hanging-knee-raise', 'Hanging Knee Raise', 'core', 'conditional', [s('R1', '10–12'), s('R2', '10–12'), s('R3', '10–12')]),
            ex('backward-sled-drag-main', 'Backward Sled Drag', 'sled', 'conditional', [
              s('R1', '20–30m', 'sled + 25 lb'), s('R2', '20–30m', 'sled + 25 lb'), s('R3', '20–30m', 'sled + 25 lb'), s('R4', '20–30m', 'sled + 25 lb'),
            ]),
          ],
        },
        {
          id: 'secondary',
          title: 'Secondary Circuit',
          exercises: [
            ex('belt-squat', 'Belt Squat', 'secondary', 'conditional', [s('R1', 12, '90 lb', 90, 'lb'), s('R2', 10, '110 lb', 110, 'lb'), s('R3', 8, '130 lb', 130, 'lb')]),
            ex('incline-db-press', 'Incline DB Press', 'secondary', 'conditional', [s('R1', 10, '30 lb DBs'), s('R2', 8, '35 lb DBs'), s('R3', 8, '35 lb DBs')]),
            ex('hamstring-curl', 'Hamstring Curl', 'secondary', 'conditional', [s('R1', 12, '40 lb'), s('R2', 10, '50 lb'), s('R3', 10, '60 lb')]),
            ex('lateral-raise', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs')]),
            ex('hip-thrust', 'Hip Thrust', 'secondary', 'conditional', [s('R1', 10, '95 lb', 95, 'lb'), s('R2', 10, '115 lb', 115, 'lb'), s('R3', 10, '135 lb', 135, 'lb')], '2-second squeeze.'),
          ],
        },
      ],
    },
    {
      day: 2,
      date: '2026-09-08',
      title: 'OLYMPIC SKILL + UPPER PUSH / DELTS / ARMS',
      role: 'Crisp Olympic work. No HIIT. Push/delt/arm support only; avoid heavy pulling overlap before Day 4.',
      readinessRule: 'Olympic prep + Hang Power Clean / Clean Pull / Push Press quality are mandatory. Stop a set when timing, receiving position, grip, or bar speed deteriorates.',
      cutOrder: 'Extra arm/delt rounds and completed support drills first. Never add rows, hard carries, HIIT, or heavy hinge work.',
      sections: [
        {
          id: 'olympic-prep',
          title: 'Olympic Prep Circuit — 3 Rounds',
          exercises: [
            ex('front-rack-mobility', 'Front Rack Mobility', 'power', 'mandatory', [s('R1', '30–45 sec'), s('R2', '30–45 sec'), s('R3', '30–45 sec')]),
            ex('muscle-clean', 'Muscle Clean', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('tall-clean', 'Tall Clean', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('clean-grip-rdl-knee', 'Clean-Grip RDL to Knee', 'power', 'mandatory', [s('R1', 3, 'light'), s('R2', 3, 'light'), s('R3', 3, 'light')]),
            ex('jump-stick', 'Jump and Stick Landing', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('dead-bug', 'Dead Bug', 'core', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side')]),
          ],
        },
        {
          id: 'receiving',
          title: 'Main Receiving Lift Circuit',
          subtitle: 'Drop completed support drills; finish remaining Hang Power Clean work alone. Full rest and clean catches always win.',
          exercises: [
            ex('hang-power-clean', 'Hang Power Clean', 'power', 'mandatory', [
              s('R1', 3, '90 lb', 90, 'lb'), s('R2', 3, '95 lb', 95, 'lb'),
              s('R3', 3, '100 lb', 100, 'lb'), s('R4', 3, '100 lb', 100, 'lb'),
              s('R5', 3, '100 lb', 100, 'lb'), s('R6', 3, '100 lb', 100, 'lb'),
            ], 'Crisp catches only. Stop before misses, slow turnover, or poor receiving position.'),
            ex('cable-external-rotation-d2', 'Cable External Rotation', 'secondary', 'mandatory', [
              s('R1', '10/side', '5 lb/side'), s('R2', '10/side', '5 lb/side'), s('R3', '10/side', '5 lb/side'), s('R4', '10/side', '5 lb/side'),
            ]),
            ex('hip-flexor-rockback-d2', 'Hip Flexor Rockback', 'recovery', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side'), s('R4', '6/side')]),
            ex('ankle-rock-d2', 'Ankle Rock', 'recovery', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side')]),
          ],
        },
        {
          id: 'clean-pull-reset',
          title: 'Clean Pull Reset Block',
          subtitle: 'Loaded extension strength, not conditioning. Support drills drop out when complete.',
          exercises: [
            ex('clean-pull', 'Clean Pull', 'power', 'mandatory', [
              s('R1', 3, '135 lb', 135, 'lb'), s('R2', 3, '145 lb', 145, 'lb'),
              s('R3', 2, '150 lb', 150, 'lb'), s('R4', 2, '150 lb', 150, 'lb'),
            ]),
            ex('serratus-wall-slide-d2', 'Serratus Wall Slide', 'secondary', 'mandatory', [s('R1', 8), s('R2', 8), s('R3', 8)]),
            ex('t-spine-rotation-d2', 'T-Spine Rotation', 'recovery', 'mandatory', [s('R1', '5/side'), s('R2', '5/side'), s('R3', '5/side')]),
            ex('wrist-pulses-d2', 'Wrist Flexor/Extensor Pulses', 'recovery', 'mandatory', [s('R1', '10 each'), s('R2', '10 each'), s('R3', '10 each')]),
          ],
        },
        {
          id: 'push-support',
          title: 'Push Press Support — 3 Rounds',
          exercises: [
            ex('push-press', 'Push Press', 'power', 'mandatory', [s('R1', 5, '65 lb', 65, 'lb'), s('R2', 5, '70 lb', 70, 'lb'), s('R3', 3, '75 lb', 75, 'lb')]),
            ex('band-pull-apart', 'Band Pull-Apart', 'secondary', 'conditional', [s('R1', '15–20'), s('R2', '15–20'), s('R3', '15–20')]),
          ],
        },
        {
          id: 'upper-support',
          title: 'Upper Push / Delt / Arm Circuit — 3–4 Rounds Conditional',
          subtitle: 'Three source rounds are programmed. A fourth round is optional only while shoulder, trap, grip, and bar-speed quality stay Green.',
          exercises: [
            ex('cable-press-around', 'Cable Press-Around', 'secondary', 'conditional', [s('R1', 12, '15 lb/side'), s('R2', 12, '15 lb/side'), s('R3', 12, '15 lb/side'), s('R4', 12, '15 lb/side', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('rear-delt-fly', 'Rear Delt Fly', 'secondary', 'conditional', [s('R1', '15–20', '10 lb DBs'), s('R2', '15–20', '10 lb DBs'), s('R3', '15–20', '10 lb DBs'), s('R4', '15–20', '10 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('rope-pushdown', 'Rope Pushdown', 'secondary', 'conditional', [s('R1', 12, '35 lb'), s('R2', 12, '35 lb'), s('R3', 12, '35 lb'), s('R4', 12, '35 lb', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('scap-pushup', 'Scap Push-Up', 'secondary', 'conditional', [s('R1', '10–15'), s('R2', '10–15'), s('R3', '10–15'), s('R4', '10–15', undefined, undefined, undefined, 'Optional 4th round only if Green.')], 'Shoulder-friendly.'),
            ex('lateral-raise-d2', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs'), s('R4', 15, '10 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('db-curl', 'DB Curl', 'secondary', 'optional', [s('R1', '10–12', '20 lb DBs'), s('R2', '10–12', '20 lb DBs'), s('R3', '10–12', '20 lb DBs'), s('R4', '10–12', '20 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('box-breathing', 'Box Breathing', 'recovery', 'optional', [s('Final reset', '2–4 min')]),
          ],
        },
      ],
    },
    {
      day: 3,
      date: '2026-09-09',
      title: 'RECOVERY + KNEES + HIP FLEXORS',
      role: 'Recovery day. Move blood, restore positions, and protect Day 4 pulling.',
      readinessRule: 'Target 30–45 minutes. Yellow = minimum recovery core. Red = easy walk/mobility or full rest. Finish feeling better than you started.',
      cutOrder: 'No hidden hinge, hard carry, heavy row, or intervals.',
      sections: [
        {
          id: 'recovery-flow',
          title: 'Recovery Flow — Conditional',
          exercises: [
            ex('turkish-getup', 'Turkish Get-Up', 'kettlebell', 'conditional', [s('R1', '1/side', '8 kg (20 lb) KB'), s('R2', '1/side', '8 kg (20 lb) KB')], 'Light and smooth.'),
            ex('kb-halo', 'KB Halo', 'kettlebell', 'conditional', [s('R1', '5 each direction', '8 kg (20 lb) KB'), s('R2', '5 each direction', '8 kg (20 lb) KB')]),
            ex('windmill', 'Windmill', 'kettlebell', 'conditional', [s('R1', '3/side', '8 kg (20 lb) KB'), s('R2', '3/side', '8 kg (20 lb) KB')]),
            ex('arm-bar', 'Arm Bar', 'kettlebell', 'conditional', [s('R1', '3 slow breaths/side', '8 kg (20 lb) KB'), s('R2', '3 slow breaths/side', '8 kg (20 lb) KB')]),
          ],
        },
        {
          id: 'hip-core',
          title: 'Hip Flexor / Core — Mandatory Minimum',
          exercises: [
            ex('reverse-crunch', 'Reverse Crunch', 'core', 'mandatory', [s('R1', '10–15'), s('R2', '10–15')]),
            ex('cable-march', 'Band or Cable March', 'core', 'mandatory', [s('R1', '10/leg', '20 lb cable'), s('R2', '10/leg', '20 lb cable')]),
            ex('dead-bug-hollow', 'Dead Bug or Hollow Hold', 'core', 'mandatory', [s('R1', '20–30 sec'), s('R2', '20–30 sec')]),
            ex('half-kneeling-chop', 'Half-Kneeling Chop', 'core', 'conditional', [s('R1', '10/side', '20 lb cable'), s('R2', '10/side', '20 lb cable')]),
            ex('half-kneeling-lift', 'Half-Kneeling Lift', 'core', 'conditional', [s('R1', '10/side', '20 lb cable'), s('R2', '10/side', '20 lb cable')]),
          ],
        },
        {
          id: 'knee-sled',
          title: 'Knee / Sled Block',
          exercises: [
            ex('backward-sled-drag-d3', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m', 'sled + 25 lb'), s('2', '20m', 'sled + 25 lb'), s('3', '20m', 'sled + 25 lb'), s('4', '20m', 'sled + 25 lb')], 'Easy.'),
            ex('forward-sled-push-light', 'Light Forward Sled Push', 'sled', 'conditional', [s('1', '20m', 'sled + 25 lb'), s('2', '20m', 'sled + 25 lb'), s('3', '20m', 'sled + 25 lb')], 'Easy.'),
            ex('tibialis-raise-d3', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20'), s('3', '15–20')]),
            ex('step-up-d3', 'Step-Up', 'secondary', 'conditional', [s('1', '8–10/leg', '20 lb DBs'), s('2', '8–10/leg', '20 lb DBs'), s('3', '8–10/leg', '20 lb DBs', undefined, undefined, 'Optional third set only if restorative.')], 'Source range is 2–3 sets; use the third only when it improves recovery.'),
            ex('easy-cardio-d3', 'Walk or Bike', 'recovery', 'optional', [s('Zone 2', '20–30 min easy')]),
          ],
        },
      ],
    },
    {
      day: 4,
      date: '2026-09-10',
      title: 'PULL + HINGE STRENGTH',
      role: 'Heavy hinge/pull day. Deadlift lives inside the circuit but never gets rushed.',
      readinessRule: 'Deadlift main work is mandatory with full rest. Stop before bar speed or position clearly degrades.',
      cutOrder: 'Extra yoke/trunk volume, redundant pulldown/row work, then anything that changes grip or low-back quality.',
      sections: [
        {
          id: 'warmup-d4',
          title: 'Warm-Up',
          exercises: [
            ex('bike-walk-d4', 'Bike / Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('glute-bridge-d4', 'Glute Bridge', 'secondary', 'mandatory', [s('1', 12), s('2', 12)]),
            ex('hip-hinge-drill', 'Hip Hinge Drill', 'secondary', 'mandatory', [s('1', 8), s('2', 8)]),
            ex('bird-dog', 'Bird Dog', 'core', 'mandatory', [s('1', '8/side'), s('2', '8/side')]),
            ex('lat-pulldown-warmup', 'Lat Pulldown Warm-Up', 'secondary', 'mandatory', [s('1', 10), s('2', 10)]),
          ],
        },
        {
          id: 'main-d4',
          title: 'Main Pull / Hinge Circuit',
          subtitle: 'Drop completed supports. Finish remaining deadlift work alone. Preserve full rest.',
          exercises: [
            ex('deadlift', 'Deadlift', 'primary', 'mandatory', [s('R1', 5, '155 lb', 155, 'lb'), s('R2', 4, '170 lb', 170, 'lb'), s('R3', 3, '180 lb', 180, 'lb'), s('R4', 2, '190 lb', 190, 'lb')]),
            ex('pullup-pulldown-d4', 'Pull-Up or Lat Pulldown', 'secondary', 'conditional', [
              s('R1', 'BW 4–6 OR 90 lb × 10', 'bodyweight OR 90 lb lat pulldown'),
              s('R2', 'BW 4–6 OR 90 lb × 10', 'bodyweight OR 90 lb lat pulldown'),
              s('R3', 'BW 4–6 OR 90 lb × 10', 'bodyweight OR 90 lb lat pulldown'),
              s('R4', 'BW 4–6 OR 90 lb × 10', 'bodyweight OR 90 lb lat pulldown'),
            ]),
            ex('chest-supported-row-d4', 'Chest-Supported Row', 'secondary', 'conditional', [s('R1', 10, '40 lb DBs'), s('R2', 10, '40 lb DBs'), s('R3', 10, '40 lb DBs'), s('R4', 10, '40 lb DBs')]),
            ex('hamstring-curl-d4', 'Hamstring Curl', 'secondary', 'conditional', [s('R1', 10, '50 lb'), s('R2', 10, '50 lb'), s('R3', 10, '50 lb')]),
            ex('pallof-press', 'Pallof Press', 'core', 'conditional', [s('R1', '10/side', '20 lb/side'), s('R2', '10/side', '20 lb/side'), s('R3', '10/side', '20 lb/side')]),
            ex('backward-sled-drag-d4', 'Backward Sled Drag', 'sled', 'conditional', [s('R1', '20–30m', 'sled + 25 lb'), s('R2', '20–30m', 'sled + 25 lb'), s('R3', '20–30m', 'sled + 25 lb'), s('R4', '20–30m', 'sled + 25 lb')]),
          ],
        },
        {
          id: 'yoke-trunk',
          title: 'Back / Yoke / Trunk Support — Conditional',
          exercises: [
            ex('cable-pullover', 'Cable Pullover', 'secondary', 'optional', [s('1', 12, '40 lb'), s('2', 12, '40 lb'), s('3', 12, '40 lb')]),
            ex('face-pull', 'Face Pull', 'secondary', 'optional', [s('1', 15, '35 lb'), s('2', 15, '35 lb'), s('3', 15, '35 lb')]),
            ex('chest-supported-shrug', 'Chest-Supported Shrug', 'secondary', 'optional', [s('1', '10–12', '50 lb DBs')], 'v2.1 integrated release explicitly caps this Week 1 support exposure at one set.'),
            ex('reverse-crunch-d4', 'Reverse Crunch or Dead Bug', 'core', 'optional', [s('1', '10–12'), s('2', '10–12'), s('3', '10–12')]),
          ],
        },
      ],
    },
    {
      day: 5,
      date: '2026-09-11',
      title: 'KB / SLED / GPP CONTROL DAY',
      role: 'Controlled conditioning after Day 4 without stealing from Day 6 bench/full-body quality.',
      readinessRule: 'GREEN = full source GPP. YELLOW = 2 clean KB-flow rounds, then choose either 2 controlled sled trips or 8–12 min easy engine. RED = recovery/rest.',
      cutOrder: 'Never make skipped GPP up on Day 6. End if grip, low back, knees, or breathing effort will reduce Day 6 quality.',
      sections: [
        {
          id: 'kb-flow',
          title: 'KB Control Flow — 3 Rounds',
          exercises: [
            ex('kb-swing-d5', 'KB Swing', 'kettlebell', 'conditional', [s('R1', 15, '16 kg (35 lb) KB'), s('R2', 15, '16 kg (35 lb) KB'), s('R3', 15, '16 kg (35 lb) KB')], 'Crisp.'),
            ex('goblet-squat', 'Goblet Squat', 'kettlebell', 'conditional', [s('R1', 10, '16 kg (35 lb) KB'), s('R2', 10, '16 kg (35 lb) KB'), s('R3', 10, '16 kg (35 lb) KB')]),
            ex('kb-halo-d5', 'KB Halo', 'kettlebell', 'conditional', [s('R1', '6 each direction', '8 kg (20 lb) KB'), s('R2', '6 each direction', '8 kg (20 lb) KB'), s('R3', '6 each direction', '8 kg (20 lb) KB')]),
            ex('suitcase-march', 'Suitcase March', 'carry', 'conditional', [s('R1', '20 steps/side', '16 kg (35 lb) KB'), s('R2', '20 steps/side', '16 kg (35 lb) KB'), s('R3', '20 steps/side', '16 kg (35 lb) KB')]),
            ex('dead-bug-pullover', 'Dead Bug Pullover', 'core', 'conditional', [s('R1', '8/side', '8 kg (20 lb) KB'), s('R2', '8/side', '8 kg (20 lb) KB'), s('R3', '8/side', '8 kg (20 lb) KB')]),
          ],
        },
        {
          id: 'sled-engine',
          title: 'Sled / Engine Block',
          exercises: [
            ex('sled-push-d5', 'Sled Push', 'sled', 'conditional', [s('1', '20–30m', 'sled + 25 lb'), s('2', '20–30m', 'sled + 25 lb'), s('3', '20–30m', 'sled + 25 lb'), s('4', '20–30m', 'sled + 25 lb', undefined, undefined, 'Optional fourth trip in full Green source dose.')]),
            ex('backward-sled-d5', 'Backward Sled Drag', 'sled', 'conditional', [s('1', '20–30m', 'sled + 25 lb'), s('2', '20–30m', 'sled + 25 lb'), s('3', '20–30m', 'sled + 25 lb'), s('4', '20–30m', 'sled + 25 lb', undefined, undefined, 'Optional fourth trip in full Green source dose.')]),
            ex('bike-row-walk-d5', 'Bike / Row / Walk', 'recovery', 'optional', [s('1', '60–90 sec'), s('2', '60–90 sec'), s('3', '60–90 sec'), s('4', '60–90 sec')], 'Easy/moderate.'),
            ex('plank-shoulder-tap', 'Plank Shoulder Tap', 'core', 'optional', [s('1', 20), s('2', 20), s('3', 20)]),
          ],
        },
        {
          id: 'mobility-reset',
          title: 'Mobility Reset',
          exercises: [
            ex('hip-flexor-rockback', 'Hip Flexor Rockback', 'recovery', 'optional', [s('1', '8/side'), s('2', '8/side')]),
            ex('serratus-wall-slide', 'Serratus Wall Slide', 'recovery', 'optional', [s('1', 10), s('2', 10)]),
            ex('9090-breathing', '90/90 Breathing', 'recovery', 'optional', [s('1', '4 breaths'), s('2', '4 breaths')]),
          ],
        },
      ],
    },
    {
      day: 6,
      date: '2026-09-12',
      title: 'FULL BODY VOLUME + BENCH/CHEST BIAS + FRONTAL PLANE KB',
      role: 'Bench/chest gets the push; everything else stays moderate and density-focused.',
      readinessRule: 'Bench quality is the session authority. If Day 5 was FULL, omit the separate Day 6 sled finisher by default.',
      cutOrder: 'Sled/engine → extra KB/core → tertiary delt/arm → secondary lower body. Do not cut bench/chest priority first.',
      sections: [
        {
          id: 'warmup-d6',
          title: 'Warm-Up + Sled / Glute / Knee Primer',
          exercises: [
            ex('bike-walk-d6', 'Bike or Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('backward-sled-primer-d6', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m'), s('2', '20m')]),
            ex('miniband-lateral-walk', 'Mini-Band Lateral Walk', 'secondary', 'mandatory', [s('1', '10 each way'), s('2', '10 each way')]),
            ex('glute-bridge-iso-d6', 'Glute Bridge ISO', 'secondary', 'mandatory', [s('1', '20 sec'), s('2', '20 sec')]),
            ex('tibialis-d6', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20')]),
            ex('kb-swing-primer-d6', 'KB Swing', 'kettlebell', 'mandatory', [s('1', 10, '16 kg (35 lb) KB'), s('2', 10, '16 kg (35 lb) KB')], 'Primer.'),
          ],
        },
        {
          id: 'main-d6',
          title: 'Main Full-Body + Bench Volume Circuit',
          subtitle: 'Bench can finish extra sets alone. Legs/back/KB/sled remain moderate.',
          exercises: [
            ex('bench-volume-d6', 'Bench Press', 'primary', 'mandatory', [
              s('R1', 5, '95 lb', 95, 'lb'), s('R2', 4, '115 lb', 115, 'lb'),
              s('R3', 3, '130 lb', 130, 'lb'), s('R4', 3, '130 lb', 130, 'lb'),
              s('R5', 3, '140 lb', 140, 'lb'), s('R6', 3, '140 lb', 140, 'lb'), s('R7', 3, '140 lb', 140, 'lb'), s('R8', 3, '140 lb', 140, 'lb'),
              s('R9', 4, '130 lb', 130, 'lb'), s('R10', 4, '130 lb', 130, 'lb'),
            ]),
            ex('belt-squat-d6', 'Belt Squat', 'secondary', 'conditional', [s('R1', 12, '90 lb', 90, 'lb'), s('R2', 10, '110 lb', 110, 'lb'), s('R3', 8, '130 lb', 130, 'lb')]),
            ex('pulldown-d6', 'Wide or Neutral Pulldown', 'secondary', 'conditional', [s('R1', 10, '90 lb'), s('R2', 10, '90 lb'), s('R3', 10, '90 lb'), s('R4', 10, '90 lb')]),
            ex('kb-swing-d6', 'KB Swing', 'kettlebell', 'conditional', [s('R1', '15–20', '16 kg (35 lb) KB'), s('R2', '15–20', '16 kg (35 lb) KB'), s('R3', '15–20', '16 kg (35 lb) KB'), s('R4', '15–20', '16 kg (35 lb) KB', undefined, undefined, 'Optional fourth set if fresh/Green.')]),
            ex('hanging-knee-d6', 'Hanging Knee Raise', 'core', 'conditional', [s('R1', '10–12'), s('R2', '10–12'), s('R3', '10–12')]),
            ex('sled-push-main-d6', 'Sled Push', 'sled', 'conditional', [s('R1', '20–30m', 'sled + 35 lb'), s('R2', '20–30m', 'sled + 35 lb'), s('R3', '20–30m', 'sled + 35 lb'), s('R4', '20–30m', 'sled + 35 lb')], 'This is the source main-circuit sled dose, distinct from the separate conditional finisher.'),
          ],
        },
        {
          id: 'secondary-d6',
          title: 'Secondary Volume Circuit — 2–3 Rounds',
          exercises: [
            ex('rdl-d6', 'RDL', 'secondary', 'conditional', [s('R1', 10, '95 lb', 95, 'lb'), s('R2', 10, '95 lb', 95, 'lb'), s('R3', 10, '95 lb', 95, 'lb')], 'Crisp, not heavy.'),
            ex('step-up-d6', 'Step-Up', 'secondary', 'conditional', [s('R1', '10/leg', '20 lb DBs'), s('R2', '10/leg', '20 lb DBs'), s('R3', '10/leg', '20 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
            ex('straight-arm-pulldown-d6', 'Straight-Arm Pulldown', 'secondary', 'conditional', [s('R1', 12, '35 lb'), s('R2', 12, '35 lb'), s('R3', 12, '35 lb')], 'Lat work without heavy row fatigue.'),
            ex('lateral-raise-d6', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
          ],
        },
        {
          id: 'chest-triceps-d6',
          title: 'Chest / Shoulder / Triceps Focus — 2–3 Rounds',
          exercises: [
            ex('cable-press-around-d6', 'Cable Press-Around', 'secondary', 'conditional', [s('R1', '12–15', '15 lb/side'), s('R2', '12–15', '15 lb/side'), s('R3', '12–15', '15 lb/side', undefined, undefined, 'Optional third round if Green.')]),
            ex('jm-press', 'JM Press', 'secondary', 'conditional', [s('R1', '6–10', '45 lb'), s('R2', '6–10', '45 lb'), s('R3', '6–10', '45 lb', undefined, undefined, 'Optional third round if Green.')]),
            ex('pushup-d6', 'Push-Up', 'secondary', 'conditional', [s('R1', 'Near failure — stop before form breaks'), s('R2', 'Near failure — stop before form breaks'), s('R3', 'Near failure — stop before form breaks', undefined, undefined, undefined, 'Optional third round if Green.')]),
            ex('rear-delt-d6', 'Rear Delt Fly', 'secondary', 'optional', [s('R1', '15–20', '10 lb DBs'), s('R2', '15–20', '10 lb DBs'), s('R3', '15–20', '10 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
            ex('rope-pushdown-d6', 'Rope Pushdown', 'secondary', 'optional', [s('R1', '10–12', '35 lb'), s('R2', '10–12', '35 lb'), s('R3', '10–12', '35 lb', undefined, undefined, 'Optional third round if Green.')]),
          ],
        },
        {
          id: 'frontal-d6',
          title: 'Frontal Plane / Lateral Core — 2 Rounds',
          exercises: [
            ex('kb-lateral-lunge', 'KB Lateral Lunge', 'kettlebell', 'conditional', [s('R1', '8/side', '12 kg (25 lb) KB'), s('R2', '8/side', '12 kg (25 lb) KB')]),
            ex('copenhagen-plank', 'Copenhagen Plank', 'core', 'conditional', [s('R1', '15–25 sec/side'), s('R2', '15–25 sec/side')]),
            ex('offset-rack-march', 'Offset Rack March', 'carry', 'conditional', [s('R1', '20 steps/side', '16 kg (35 lb) KB'), s('R2', '20 steps/side', '16 kg (35 lb) KB')]),
            ex('kb-lateral-clean', 'KB Lateral Clean or Outside Swing to Rack', 'kettlebell', 'conditional', [s('R1', '5/side', '12 kg (25 lb) KB'), s('R2', '5/side', '12 kg (25 lb) KB')]),
          ],
        },
        {
          id: 'sled-finish-d6',
          title: 'Sled Finish — Conditional / Default Omit After Full Day 5',
          subtitle: 'If Day 5 was abbreviated or skipped and readiness is Green, one source sled dose may remain. Do not make up Day 5 volume here.',
          exercises: [
            ex('sled-push-finish-d6', 'Sled Push', 'sled', 'optional', [s('F1-1', '20–30m', 'sled + 35 lb'), s('F1-2', '20–30m', 'sled + 35 lb'), s('F1-3', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional extra source trip only if Green.'), s('F1-4', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional extra source trip only if Green.')]),
            ex('backward-sled-finish-d6', 'Backward Sled Drag', 'sled', 'optional', [s('F2-1', '20–30m', 'sled + 25 lb'), s('F2-2', '20–30m', 'sled + 25 lb'), s('F2-3', '20–30m', 'sled + 25 lb', undefined, undefined, 'Optional extra source trip only if Green.'), s('F2-4', '20–30m', 'sled + 25 lb', undefined, undefined, 'Optional extra source trip only if Green.')]),
          ],
        },
      ],
    },
    {
      day: 7,
      date: '2026-09-13',
      title: 'REST',
      role: 'Recovery is part of the plan. No make-up punishment.',
      readinessRule: 'Rest. Easy walking or mobility only if it makes you feel better.',
      restDay: true,
      sections: [
        {
          id: 'rest-checklist',
          title: 'Rest Day Checklist',
          exercises: [
            ex('easy-walk-rest', 'Optional Easy Walk', 'recovery', 'optional', [s('Optional', '20–40 min')]),
            ex('mobility-rest', 'Mobility', 'recovery', 'optional', [s('Optional', 'Only if restorative')]),
          ],
        },
      ],
    },
  ],
}


export const CROWNFORGE_WEEK_2: ProgramWeek = {
  week: 2,
  start: '2026-09-14',
  end: '2026-09-20',
  intent: 'Accumulate the highest clean volume of the opening wave.',
  days: [
    {
      day: 1,
      date: '2026-09-14',
      title: 'LOWER + PUSH STRENGTH / GLUTES',
      role: 'Strength-density day. Main lifts ramp; final heavy sets may be focused alone.',
      readinessRule: 'Front Squat + Bench are mandatory. Yellow keeps clean primary work and highest-value chest/glute support. Stop the ramp before a grinder.',
      cutOrder: 'Lowest priority first: lateral raise, lower-value accessories. Never compress primary rest to preserve density.',
      sections: [
        {
          id: 'warmup',
          title: 'Warm-Up',
          exercises: [
            ex('bike-incline-walk', 'Bike / Incline Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('backward-sled-drag-primer', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m'), s('2', '20m')]),
            ex('glute-bridge-iso', 'Glute Bridge ISO', 'secondary', 'mandatory', [s('1', '20 sec'), s('2', '20 sec')]),
            ex('tibialis-raise', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20')]),
            ex('front-squat-bench-ramp', 'Front Squat + Bench Ramp Sets', 'primary', 'mandatory', [s('Ramp', 'Empty bar → first work set')]),
          ],
        },
        {
          id: 'main',
          title: 'Main Strength Circuit',
          subtitle: 'Drop completed support movements; remaining main-lift sets finish alone. Full rest always wins.',
          exercises: [
            ex('front-squat', 'Front Squat', 'primary', 'mandatory', [
              s('R1', 5, '100 lb', 100, 'lb'),
              s('R2', 4, '115 lb', 115, 'lb'),
              s('R3', 3, '130 lb', 130, 'lb'),
              s('R4', 3, '130 lb', 130, 'lb'),
              s('R5', 3, '140 lb', 140, 'lb'),
              s('R6', 3, '140 lb', 140, 'lb'),
              s('R7', 4, '125 lb', 125, 'lb'),
            ], 'Barbell quality overrides circuit density.'),
            ex('bench-press', 'Bench Press', 'primary', 'mandatory', [
              s('R1', 5, '125 lb', 125, 'lb'),
              s('R2', 4, '135 lb', 135, 'lb'),
              s('R3', 3, '145 lb', 145, 'lb'),
              s('R4', 2, '155 lb', 155, 'lb'),
            ]),
            ex('chest-supported-row', 'Chest-Supported Row', 'secondary', 'conditional', [
              s('R1', 10, '45 lb DBs'), s('R2', 10, '45 lb DBs'), s('R3', 10, '45 lb DBs'), s('R4', 10, '45 lb DBs'),
            ]),
            ex('kb-swing', 'KB Swing', 'kettlebell', 'conditional', [
              s('R1', 12, '16 kg (35 lb) KB'), s('R2', 12, '16 kg (35 lb) KB'), s('R3', 12, '16 kg (35 lb) KB'),
            ], 'Crisp hip snap.'),
            ex('hanging-knee-raise', 'Hanging Knee Raise', 'core', 'conditional', [s('R1', '10–12'), s('R2', '10–12'), s('R3', '10–12')]),
            ex('backward-sled-drag-main', 'Backward Sled Drag', 'sled', 'conditional', [
              s('R1', '20–30m', 'sled + 35 lb'), s('R2', '20–30m', 'sled + 35 lb'), s('R3', '20–30m', 'sled + 35 lb'), s('R4', '20–30m', 'sled + 35 lb'),
            ]),
          ],
        },
        {
          id: 'secondary',
          title: 'Secondary Circuit',
          exercises: [
            ex('belt-squat', 'Belt Squat', 'secondary', 'conditional', [s('R1', 12, '100 lb', 100, 'lb'), s('R2', 10, '120 lb', 120, 'lb'), s('R3', 8, '140 lb', 140, 'lb')]),
            ex('incline-db-press', 'Incline DB Press', 'secondary', 'conditional', [s('R1', 10, '35 lb DBs'), s('R2', 8, '35 lb DBs'), s('R3', 8, '40 lb DBs')]),
            ex('hamstring-curl', 'Hamstring Curl', 'secondary', 'conditional', [s('R1', 12, '45 lb'), s('R2', 10, '55 lb'), s('R3', 10, '65 lb')]),
            ex('lateral-raise', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs')]),
            ex('hip-thrust', 'Hip Thrust', 'secondary', 'conditional', [s('R1', 10, '105 lb', 105, 'lb'), s('R2', 10, '125 lb', 125, 'lb'), s('R3', 10, '145 lb', 145, 'lb')], '2-second squeeze.'),
          ],
        },
      ],
    },
    {
      day: 2,
      date: '2026-09-15',
      title: 'OLYMPIC SKILL + UPPER PUSH / DELTS / ARMS',
      role: 'Crisp Olympic work. No HIIT. Push/delt/arm support only; avoid heavy pulling overlap before Day 4.',
      readinessRule: 'Olympic prep + Hang Power Clean / Clean Pull / Push Press quality are mandatory. Stop a set when timing, receiving position, grip, or bar speed deteriorates.',
      cutOrder: 'Extra arm/delt rounds and completed support drills first. Never add rows, hard carries, HIIT, or heavy hinge work.',
      sections: [
        {
          id: 'olympic-prep',
          title: 'Olympic Prep Circuit — 3 Rounds',
          exercises: [
            ex('front-rack-mobility', 'Front Rack Mobility', 'power', 'mandatory', [s('R1', '30–45 sec'), s('R2', '30–45 sec'), s('R3', '30–45 sec')]),
            ex('muscle-clean', 'Muscle Clean', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('tall-clean', 'Tall Clean', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('clean-grip-rdl-knee', 'Clean-Grip RDL to Knee', 'power', 'mandatory', [s('R1', 3, 'light'), s('R2', 3, 'light'), s('R3', 3, 'light')]),
            ex('jump-stick', 'Jump and Stick Landing', 'power', 'mandatory', [s('R1', 3), s('R2', 3), s('R3', 3)]),
            ex('dead-bug', 'Dead Bug', 'core', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side')]),
          ],
        },
        {
          id: 'receiving',
          title: 'Main Receiving Lift Circuit',
          subtitle: 'Drop completed support drills; finish remaining Hang Power Clean work alone. Full rest and clean catches always win.',
          exercises: [
            ex('hang-power-clean', 'Hang Power Clean', 'power', 'mandatory', [
              s('R1', 3, '95 lb', 95, 'lb'), s('R2', 3, '100 lb', 100, 'lb'),
              s('R3', 3, '105 lb', 105, 'lb'), s('R4', 3, '105 lb', 105, 'lb'),
              s('R5', 3, '105 lb', 105, 'lb'), s('R6', 3, '105 lb', 105, 'lb'),
            ], 'Crisp catches only. Stop before misses, slow turnover, or poor receiving position.'),
            ex('cable-external-rotation-d2', 'Cable External Rotation', 'secondary', 'mandatory', [
              s('R1', '10/side', '5 lb/side'), s('R2', '10/side', '5 lb/side'), s('R3', '10/side', '5 lb/side'), s('R4', '10/side', '5 lb/side'),
            ]),
            ex('hip-flexor-rockback-d2', 'Hip Flexor Rockback', 'recovery', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side'), s('R4', '6/side')]),
            ex('ankle-rock-d2', 'Ankle Rock', 'recovery', 'mandatory', [s('R1', '6/side'), s('R2', '6/side'), s('R3', '6/side')]),
          ],
        },
        {
          id: 'clean-pull-reset',
          title: 'Clean Pull Reset Block',
          subtitle: 'Loaded extension strength, not conditioning. Support drills drop out when complete.',
          exercises: [
            ex('clean-pull', 'Clean Pull', 'power', 'mandatory', [
              s('R1', 3, '140 lb', 140, 'lb'), s('R2', 2, '150 lb', 150, 'lb'),
              s('R3', 2, '155 lb', 155, 'lb'), s('R4', 2, '155 lb', 155, 'lb'),
            ]),
            ex('serratus-wall-slide-d2', 'Serratus Wall Slide', 'secondary', 'mandatory', [s('R1', 8), s('R2', 8), s('R3', 8)]),
            ex('t-spine-rotation-d2', 'T-Spine Rotation', 'recovery', 'mandatory', [s('R1', '5/side'), s('R2', '5/side'), s('R3', '5/side')]),
            ex('wrist-pulses-d2', 'Wrist Flexor/Extensor Pulses', 'recovery', 'mandatory', [s('R1', '10 each'), s('R2', '10 each'), s('R3', '10 each')]),
          ],
        },
        {
          id: 'push-support',
          title: 'Push Press Support — 3 Rounds',
          exercises: [
            ex('push-press', 'Push Press', 'power', 'mandatory', [s('R1', 5, '70 lb', 70, 'lb'), s('R2', 5, '75 lb', 75, 'lb'), s('R3', 3, '80 lb', 80, 'lb')]),
            ex('band-pull-apart', 'Band Pull-Apart', 'secondary', 'conditional', [s('R1', '15–20'), s('R2', '15–20'), s('R3', '15–20')]),
          ],
        },
        {
          id: 'upper-support',
          title: 'Upper Push / Delt / Arm Circuit — 3–4 Rounds Conditional',
          subtitle: 'Three source rounds are programmed. A fourth round is optional only while shoulder, trap, grip, and bar-speed quality stay Green.',
          exercises: [
            ex('cable-press-around', 'Cable Press-Around', 'secondary', 'conditional', [s('R1', 12, '20 lb/side'), s('R2', 12, '20 lb/side'), s('R3', 12, '20 lb/side'), s('R4', 12, '20 lb/side', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('rear-delt-fly', 'Rear Delt Fly', 'secondary', 'conditional', [s('R1', '15–20', '10 lb DBs'), s('R2', '15–20', '10 lb DBs'), s('R3', '15–20', '10 lb DBs'), s('R4', '15–20', '10 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('rope-pushdown', 'Rope Pushdown', 'secondary', 'conditional', [s('R1', 12, '40 lb'), s('R2', 12, '40 lb'), s('R3', 12, '40 lb'), s('R4', 12, '40 lb', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('scap-pushup', 'Scap Push-Up', 'secondary', 'conditional', [s('R1', '10–15'), s('R2', '10–15'), s('R3', '10–15'), s('R4', '10–15', undefined, undefined, undefined, 'Optional 4th round only if Green.')], 'Shoulder-friendly.'),
            ex('lateral-raise-d2', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs'), s('R4', 15, '10 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('db-curl', 'DB Curl', 'secondary', 'optional', [s('R1', '10–12', '20 lb DBs'), s('R2', '10–12', '20 lb DBs'), s('R3', '10–12', '20 lb DBs'), s('R4', '10–12', '20 lb DBs', undefined, undefined, 'Optional 4th round only if Green.')]),
            ex('box-breathing', 'Box Breathing', 'recovery', 'optional', [s('Final reset', '2–4 min')]),
          ],
        },
      ],
    },
    {
      day: 3,
      date: '2026-09-16',
      title: 'RECOVERY + KNEES + HIP FLEXORS',
      role: 'Recovery day. Move blood, restore positions, and protect Day 4 pulling.',
      readinessRule: 'Target 30–45 minutes. Yellow = minimum recovery core. Red = easy walk/mobility or full rest. Finish feeling better than you started.',
      cutOrder: 'No hidden hinge, hard carry, heavy row, or intervals.',
      sections: [
        {
          id: 'recovery-flow',
          title: 'Recovery Flow — Conditional',
          exercises: [
            ex('turkish-getup', 'Turkish Get-Up', 'kettlebell', 'conditional', [s('R1', '1/side', '8 kg (20 lb) KB'), s('R2', '1/side', '8 kg (20 lb) KB')], 'Light and smooth.'),
            ex('kb-halo', 'KB Halo', 'kettlebell', 'conditional', [s('R1', '5 each direction', '8 kg (20 lb) KB'), s('R2', '5 each direction', '8 kg (20 lb) KB')]),
            ex('windmill', 'Windmill', 'kettlebell', 'conditional', [s('R1', '3/side', '8 kg (20 lb) KB'), s('R2', '3/side', '8 kg (20 lb) KB')]),
            ex('arm-bar', 'Arm Bar', 'kettlebell', 'conditional', [s('R1', '3 slow breaths/side', '8 kg (20 lb) KB'), s('R2', '3 slow breaths/side', '8 kg (20 lb) KB')]),
          ],
        },
        {
          id: 'hip-core',
          title: 'Hip Flexor / Core — Mandatory Minimum',
          exercises: [
            ex('reverse-crunch', 'Reverse Crunch', 'core', 'mandatory', [s('R1', '10–15'), s('R2', '10–15')]),
            ex('cable-march', 'Band or Cable March', 'core', 'mandatory', [s('R1', '10/leg', '20 lb cable'), s('R2', '10/leg', '20 lb cable')]),
            ex('dead-bug-hollow', 'Dead Bug or Hollow Hold', 'core', 'mandatory', [s('R1', '20–30 sec'), s('R2', '20–30 sec')]),
            ex('half-kneeling-chop', 'Half-Kneeling Chop', 'core', 'conditional', [s('R1', '10/side', '20 lb cable'), s('R2', '10/side', '20 lb cable')]),
            ex('half-kneeling-lift', 'Half-Kneeling Lift', 'core', 'conditional', [s('R1', '10/side', '20 lb cable'), s('R2', '10/side', '20 lb cable')]),
          ],
        },
        {
          id: 'knee-sled',
          title: 'Knee / Sled Block',
          exercises: [
            ex('backward-sled-drag-d3', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m', 'sled + 25 lb'), s('2', '20m', 'sled + 25 lb'), s('3', '20m', 'sled + 25 lb'), s('4', '20m', 'sled + 25 lb')], 'Easy.'),
            ex('forward-sled-push-light', 'Light Forward Sled Push', 'sled', 'conditional', [s('1', '20m', 'sled + 25 lb'), s('2', '20m', 'sled + 25 lb'), s('3', '20m', 'sled + 25 lb')], 'Easy.'),
            ex('tibialis-raise-d3', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20'), s('3', '15–20')]),
            ex('step-up-d3', 'Step-Up', 'secondary', 'conditional', [s('1', '8–10/leg', '20 lb DBs'), s('2', '8–10/leg', '20 lb DBs'), s('3', '8–10/leg', '20 lb DBs', undefined, undefined, 'Optional third set only if restorative.')], 'Source range is 2–3 sets; use the third only when it improves recovery.'),
            ex('easy-cardio-d3', 'Walk or Bike', 'recovery', 'optional', [s('Zone 2', '20–30 min easy')]),
          ],
        },
      ],
    },
    {
      day: 4,
      date: '2026-09-17',
      title: 'PULL + HINGE STRENGTH',
      role: 'Heavy hinge/pull day. Deadlift lives inside the circuit but never gets rushed.',
      readinessRule: 'Deadlift main work is mandatory with full rest. Stop before bar speed or position clearly degrades.',
      cutOrder: 'Extra yoke/trunk volume, redundant pulldown/row work, then anything that changes grip or low-back quality.',
      sections: [
        {
          id: 'warmup-d4',
          title: 'Warm-Up',
          exercises: [
            ex('bike-walk-d4', 'Bike / Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('glute-bridge-d4', 'Glute Bridge', 'secondary', 'mandatory', [s('1', 12), s('2', 12)]),
            ex('hip-hinge-drill', 'Hip Hinge Drill', 'secondary', 'mandatory', [s('1', 8), s('2', 8)]),
            ex('bird-dog', 'Bird Dog', 'core', 'mandatory', [s('1', '8/side'), s('2', '8/side')]),
            ex('lat-pulldown-warmup', 'Lat Pulldown Warm-Up', 'secondary', 'mandatory', [s('1', 10), s('2', 10)]),
          ],
        },
        {
          id: 'main-d4',
          title: 'Main Pull / Hinge Circuit',
          subtitle: 'Drop completed supports. Finish remaining deadlift work alone. Preserve full rest.',
          exercises: [
            ex('deadlift', 'Deadlift', 'primary', 'mandatory', [s('R1', 5, '160 lb', 160, 'lb'), s('R2', 4, '175 lb', 175, 'lb'), s('R3', 3, '185 lb', 185, 'lb'), s('R4', 2, '195 lb', 195, 'lb')]),
            ex('pullup-pulldown-d4', 'Pull-Up or Lat Pulldown', 'secondary', 'conditional', [
              s('R1', 'BW 4–6 OR 95 lb × 10', 'bodyweight OR 95 lb lat pulldown'),
              s('R2', 'BW 4–6 OR 95 lb × 10', 'bodyweight OR 95 lb lat pulldown'),
              s('R3', 'BW 4–6 OR 95 lb × 10', 'bodyweight OR 95 lb lat pulldown'),
              s('R4', 'BW 4–6 OR 95 lb × 10', 'bodyweight OR 95 lb lat pulldown'),
            ]),
            ex('chest-supported-row-d4', 'Chest-Supported Row', 'secondary', 'conditional', [s('R1', 10, '45 lb DBs'), s('R2', 10, '45 lb DBs'), s('R3', 10, '45 lb DBs'), s('R4', 10, '45 lb DBs')]),
            ex('hamstring-curl-d4', 'Hamstring Curl', 'secondary', 'conditional', [s('R1', 10, '55 lb'), s('R2', 10, '55 lb'), s('R3', 10, '55 lb')]),
            ex('pallof-press', 'Pallof Press', 'core', 'conditional', [s('R1', '10/side', '20 lb/side'), s('R2', '10/side', '20 lb/side'), s('R3', '10/side', '20 lb/side')]),
            ex('backward-sled-drag-d4', 'Backward Sled Drag', 'sled', 'conditional', [s('R1', '20–30m', 'sled + 35 lb'), s('R2', '20–30m', 'sled + 35 lb'), s('R3', '20–30m', 'sled + 35 lb'), s('R4', '20–30m', 'sled + 35 lb')]),
          ],
        },
        {
          id: 'yoke-trunk',
          title: 'Back / Yoke / Trunk Support — Conditional',
          exercises: [
            ex('cable-pullover', 'Cable Pullover', 'secondary', 'optional', [s('1', 12, '45 lb'), s('2', 12, '45 lb'), s('3', 12, '45 lb')]),
            ex('face-pull', 'Face Pull', 'secondary', 'optional', [s('1', 15, '40 lb'), s('2', 15, '40 lb'), s('3', 15, '40 lb')]),
            ex('chest-supported-shrug', 'Chest-Supported Shrug', 'secondary', 'optional', [s('1', '10–12', '55 lb DBs'), s('2', '10–12', '55 lb DBs'), s('3', '10–12', '55 lb DBs')]),
            ex('reverse-crunch-d4', 'Reverse Crunch or Dead Bug', 'core', 'optional', [s('1', '10–12'), s('2', '10–12'), s('3', '10–12')]),
          ],
        },
      ],
    },
    {
      day: 5,
      date: '2026-09-18',
      title: 'KB / SLED / GPP CONTROL DAY',
      role: 'Controlled conditioning after Day 4 without stealing from Day 6 bench/full-body quality.',
      readinessRule: 'GREEN = full source GPP. YELLOW = 2 clean KB-flow rounds, then choose either 2 controlled sled trips or 8–12 min easy engine. RED = recovery/rest.',
      cutOrder: 'Never make skipped GPP up on Day 6. End if grip, low back, knees, or breathing effort will reduce Day 6 quality.',
      sections: [
        {
          id: 'kb-flow',
          title: 'KB Control Flow — 3 Rounds',
          exercises: [
            ex('kb-swing-d5', 'KB Swing', 'kettlebell', 'conditional', [s('R1', 15, '16 kg (35 lb) KB'), s('R2', 15, '16 kg (35 lb) KB'), s('R3', 15, '16 kg (35 lb) KB')], 'Crisp.'),
            ex('goblet-squat', 'Goblet Squat', 'kettlebell', 'conditional', [s('R1', 10, '16 kg (35 lb) KB'), s('R2', 10, '16 kg (35 lb) KB'), s('R3', 10, '16 kg (35 lb) KB')]),
            ex('kb-halo-d5', 'KB Halo', 'kettlebell', 'conditional', [s('R1', '6 each direction', '8 kg (20 lb) KB'), s('R2', '6 each direction', '8 kg (20 lb) KB'), s('R3', '6 each direction', '8 kg (20 lb) KB')]),
            ex('suitcase-march', 'Suitcase March', 'carry', 'conditional', [s('R1', '20 steps/side', '20 kg (45 lb) KB'), s('R2', '20 steps/side', '20 kg (45 lb) KB'), s('R3', '20 steps/side', '20 kg (45 lb) KB')]),
            ex('dead-bug-pullover', 'Dead Bug Pullover', 'core', 'conditional', [s('R1', '8/side', '8 kg (20 lb) KB'), s('R2', '8/side', '8 kg (20 lb) KB'), s('R3', '8/side', '8 kg (20 lb) KB')]),
          ],
        },
        {
          id: 'sled-engine',
          title: 'Sled / Engine Block',
          exercises: [
            ex('sled-push-d5', 'Sled Push', 'sled', 'conditional', [s('1', '20–30m', 'sled + 35 lb'), s('2', '20–30m', 'sled + 35 lb'), s('3', '20–30m', 'sled + 35 lb'), s('4', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional fourth trip in full Green source dose.')]),
            ex('backward-sled-d5', 'Backward Sled Drag', 'sled', 'conditional', [s('1', '20–30m', 'sled + 35 lb'), s('2', '20–30m', 'sled + 35 lb'), s('3', '20–30m', 'sled + 35 lb'), s('4', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional fourth trip in full Green source dose.')]),
            ex('bike-row-walk-d5', 'Bike / Row / Walk', 'recovery', 'optional', [s('1', '60–90 sec'), s('2', '60–90 sec'), s('3', '60–90 sec'), s('4', '60–90 sec')], 'Easy/moderate.'),
            ex('plank-shoulder-tap', 'Plank Shoulder Tap', 'core', 'optional', [s('1', 20), s('2', 20), s('3', 20)]),
          ],
        },
        {
          id: 'mobility-reset',
          title: 'Mobility Reset',
          exercises: [
            ex('hip-flexor-rockback', 'Hip Flexor Rockback', 'recovery', 'optional', [s('1', '8/side'), s('2', '8/side')]),
            ex('serratus-wall-slide', 'Serratus Wall Slide', 'recovery', 'optional', [s('1', 10), s('2', 10)]),
            ex('9090-breathing', '90/90 Breathing', 'recovery', 'optional', [s('1', '4 breaths'), s('2', '4 breaths')]),
          ],
        },
      ],
    },
    {
      day: 6,
      date: '2026-09-19',
      title: 'FULL BODY VOLUME + BENCH/CHEST BIAS + FRONTAL PLANE KB',
      role: 'Bench/chest gets the push; everything else stays moderate and density-focused.',
      readinessRule: 'Bench quality is the session authority. If Day 5 was FULL, omit the separate Day 6 sled finisher by default.',
      cutOrder: 'Sled/engine → extra KB/core → tertiary delt/arm → secondary lower body. Do not cut bench/chest priority first.',
      sections: [
        {
          id: 'warmup-d6',
          title: 'Warm-Up + Sled / Glute / Knee Primer',
          exercises: [
            ex('bike-walk-d6', 'Bike or Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
            ex('backward-sled-primer-d6', 'Backward Sled Drag', 'sled', 'mandatory', [s('1', '20m'), s('2', '20m')]),
            ex('miniband-lateral-walk', 'Mini-Band Lateral Walk', 'secondary', 'mandatory', [s('1', '10 each way'), s('2', '10 each way')]),
            ex('glute-bridge-iso-d6', 'Glute Bridge ISO', 'secondary', 'mandatory', [s('1', '20 sec'), s('2', '20 sec')]),
            ex('tibialis-d6', 'Tibialis Raise', 'secondary', 'mandatory', [s('1', '15–20'), s('2', '15–20')]),
            ex('kb-swing-primer-d6', 'KB Swing', 'kettlebell', 'mandatory', [s('1', 10, '16 kg (35 lb) KB'), s('2', 10, '16 kg (35 lb) KB')], 'Primer.'),
          ],
        },
        {
          id: 'main-d6',
          title: 'Main Full-Body + Bench Volume Circuit',
          subtitle: 'Bench can finish extra sets alone. Legs/back/KB/sled remain moderate.',
          exercises: [
            ex('bench-volume-d6', 'Bench Press', 'primary', 'mandatory', [
              s('R1', 5, '95 lb', 95, 'lb'), s('R2', 4, '120 lb', 120, 'lb'),
              s('R3', 3, '135 lb', 135, 'lb'), s('R4', 3, '135 lb', 135, 'lb'),
              s('R5', 3, '145 lb', 145, 'lb'), s('R6', 3, '145 lb', 145, 'lb'), s('R7', 3, '145 lb', 145, 'lb'), s('R8', 3, '145 lb', 145, 'lb'),
              s('R9', 4, '135 lb', 135, 'lb'), s('R10', 4, '135 lb', 135, 'lb'),
            ]),
            ex('belt-squat-d6', 'Belt Squat', 'secondary', 'conditional', [s('R1', 12, '100 lb', 100, 'lb'), s('R2', 10, '120 lb', 120, 'lb'), s('R3', 8, '140 lb', 140, 'lb')]),
            ex('pulldown-d6', 'Wide or Neutral Pulldown', 'secondary', 'conditional', [s('R1', 10, '95 lb'), s('R2', 10, '95 lb'), s('R3', 10, '95 lb'), s('R4', 10, '95 lb')]),
            ex('kb-swing-d6', 'KB Swing', 'kettlebell', 'conditional', [s('R1', '15–20', '16 kg (35 lb) KB'), s('R2', '15–20', '16 kg (35 lb) KB'), s('R3', '15–20', '16 kg (35 lb) KB'), s('R4', '15–20', '16 kg (35 lb) KB', undefined, undefined, 'Optional fourth set if fresh/Green.')]),
            ex('hanging-knee-d6', 'Hanging Knee Raise', 'core', 'conditional', [s('R1', '10–12'), s('R2', '10–12'), s('R3', '10–12')]),
            ex('sled-push-main-d6', 'Sled Push', 'sled', 'conditional', [s('R1', '20–30m', 'sled + 45 lb'), s('R2', '20–30m', 'sled + 45 lb'), s('R3', '20–30m', 'sled + 45 lb'), s('R4', '20–30m', 'sled + 45 lb')], 'This is the source main-circuit sled dose, distinct from the separate conditional finisher.'),
          ],
        },
        {
          id: 'secondary-d6',
          title: 'Secondary Volume Circuit — 2–3 Rounds',
          exercises: [
            ex('rdl-d6', 'RDL', 'secondary', 'conditional', [s('R1', 10, '105 lb', 105, 'lb'), s('R2', 10, '105 lb', 105, 'lb'), s('R3', 10, '105 lb', 105, 'lb')], 'Crisp, not heavy.'),
            ex('step-up-d6', 'Step-Up', 'secondary', 'conditional', [s('R1', '10/leg', '20 lb DBs'), s('R2', '10/leg', '20 lb DBs'), s('R3', '10/leg', '20 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
            ex('straight-arm-pulldown-d6', 'Straight-Arm Pulldown', 'secondary', 'conditional', [s('R1', 12, '40 lb'), s('R2', 12, '40 lb'), s('R3', 12, '40 lb')], 'Lat work without heavy row fatigue.'),
            ex('lateral-raise-d6', 'Lateral Raise', 'secondary', 'optional', [s('R1', 15, '10 lb DBs'), s('R2', 15, '10 lb DBs'), s('R3', 15, '10 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
          ],
        },
        {
          id: 'chest-triceps-d6',
          title: 'Chest / Shoulder / Triceps Focus — 2–3 Rounds',
          exercises: [
            ex('cable-press-around-d6', 'Cable Press-Around', 'secondary', 'conditional', [s('R1', '12–15', '20 lb/side'), s('R2', '12–15', '20 lb/side'), s('R3', '12–15', '20 lb/side', undefined, undefined, 'Optional third round if Green.')]),
            ex('jm-press', 'JM Press', 'secondary', 'conditional', [s('R1', '6–10', '50 lb'), s('R2', '6–10', '50 lb'), s('R3', '6–10', '50 lb', undefined, undefined, 'Optional third round if Green.')]),
            ex('pushup-d6', 'Push-Up', 'secondary', 'conditional', [s('R1', 'Near failure — stop before form breaks'), s('R2', 'Near failure — stop before form breaks'), s('R3', 'Near failure — stop before form breaks', undefined, undefined, undefined, 'Optional third round if Green.')]),
            ex('rear-delt-d6', 'Rear Delt Fly', 'secondary', 'optional', [s('R1', '15–20', '10 lb DBs'), s('R2', '15–20', '10 lb DBs'), s('R3', '15–20', '10 lb DBs', undefined, undefined, 'Optional third round if Green.')]),
            ex('rope-pushdown-d6', 'Rope Pushdown', 'secondary', 'optional', [s('R1', '10–12', '40 lb'), s('R2', '10–12', '40 lb'), s('R3', '10–12', '40 lb', undefined, undefined, 'Optional third round if Green.')]),
          ],
        },
        {
          id: 'frontal-d6',
          title: 'Frontal Plane / Lateral Core — 2 Rounds',
          exercises: [
            ex('kb-lateral-lunge', 'KB Lateral Lunge', 'kettlebell', 'conditional', [s('R1', '8/side', '12 kg (25 lb) KB'), s('R2', '8/side', '12 kg (25 lb) KB')]),
            ex('copenhagen-plank', 'Copenhagen Plank', 'core', 'conditional', [s('R1', '15–25 sec/side'), s('R2', '15–25 sec/side')]),
            ex('offset-rack-march', 'Offset Rack March', 'carry', 'conditional', [s('R1', '20 steps/side', '16 kg (35 lb) KB'), s('R2', '20 steps/side', '16 kg (35 lb) KB')]),
            ex('kb-lateral-clean', 'KB Lateral Clean or Outside Swing to Rack', 'kettlebell', 'conditional', [s('R1', '5/side', '12 kg (25 lb) KB'), s('R2', '5/side', '12 kg (25 lb) KB')]),
          ],
        },
        {
          id: 'sled-finish-d6',
          title: 'Sled Finish — Conditional / Default Omit After Full Day 5',
          subtitle: 'If Day 5 was abbreviated or skipped and readiness is Green, one source sled dose may remain. Do not make up Day 5 volume here.',
          exercises: [
            ex('sled-push-finish-d6', 'Sled Push', 'sled', 'optional', [s('F1-1', '20–30m', 'sled + 45 lb'), s('F1-2', '20–30m', 'sled + 45 lb'), s('F1-3', '20–30m', 'sled + 45 lb', undefined, undefined, 'Optional extra source trip only if Green.'), s('F1-4', '20–30m', 'sled + 45 lb', undefined, undefined, 'Optional extra source trip only if Green.')]),
            ex('backward-sled-finish-d6', 'Backward Sled Drag', 'sled', 'optional', [s('F2-1', '20–30m', 'sled + 35 lb'), s('F2-2', '20–30m', 'sled + 35 lb'), s('F2-3', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional extra source trip only if Green.'), s('F2-4', '20–30m', 'sled + 35 lb', undefined, undefined, 'Optional extra source trip only if Green.')]),
          ],
        },
      ],
    },
    {
      day: 7,
      date: '2026-09-20',
      title: 'REST',
      role: 'Recovery is part of the plan. No make-up punishment.',
      readinessRule: 'Rest. Easy walking or mobility only if it makes you feel better.',
      restDay: true,
      sections: [
        {
          id: 'rest-checklist',
          title: 'Rest Day Checklist',
          exercises: [
            ex('easy-walk-rest', 'Optional Easy Walk', 'recovery', 'optional', [s('Optional', '20–40 min')]),
            ex('mobility-rest', 'Mobility', 'recovery', 'optional', [s('Optional', 'Only if restorative')]),
          ],
        },
      ],
    },
  ],
}

export { CROWNFORGE_WEEK_3, CROWNFORGE_WEEK_4, CROWNFORGE_WEEK_5, CROWNFORGE_WEEK_6 }

export const CROWNFORGE: PublicProgramDefinition = {
  key: 'crownforge',
  name: 'Crownforge Revised — Integrated',
  version: 'v2.1',
  sourceEngine: 'v1.7.20',
  description: '14-week strength, work-capacity, and Black Crown entry-preparation program plus a 3-week Crown Maintenance bridge.',
  weeks: 14,
  trainingDaysPerWeek: 6,
  status: 'active-source',
  sourceNotes: [
    'Exact-load/testing engine retained from v1.7.20; v2.1 governs readiness, priority, Day 5 FLEX, and Day 6 anti-duplication.',
    'Percentage/TM and exact programmed weights remain loading authority; RPE is an effort ceiling only where shown.',
    'Weeks 1–6 are embedded from Crownforge Revised v2.1 with exact-load prescriptions cross-checked against the retained source engine. Remaining weeks are imported only from governing source material, never extrapolated.',
    'Program exercise names resolve through the source Exercise Demo Library; source video status and approved alternatives never rewrite the governed program.',
  ],
  weekData: [CROWNFORGE_WEEK_1, CROWNFORGE_WEEK_2, CROWNFORGE_WEEK_3, CROWNFORGE_WEEK_4, CROWNFORGE_WEEK_5, CROWNFORGE_WEEK_6],
}

export const BLACK_CROWN: PublicProgramDefinition = {
  key: 'black-crown',
  name: 'Black Crown Revised',
  version: 'v2.0',
  description: '54-week strength / powerbuilding / realization system with governed TM calibration and readiness rules.',
  weeks: 54,
  trainingDaysPerWeek: 5,
  status: 'catalog-only',
  sourceNotes: [
    'Normal Block 1 entry is 90% of verified Crownforge 1RM, lift by lift; 87.5% is protective Yellow entry only.',
    'Percentage/TM prescriptions are loading authority. Strict OHP occurs by replacement, not as an added training day.',
    'Full 54-week source has intentionally not been retyped into this reconstruction; import the governing v2.0 source database before Black Crown begins.',
  ],
  weekData: [],
}

export const PROGRAMS = [CROWNFORGE, BLACK_CROWN]

export function getCrownforgeWeek(week: number): ProgramWeek | null {
  return CROWNFORGE.weekData.find((item) => item.week === week) ?? null
}

export function getCrownforgeDay(week: number, day: number): ProgramDay | null {
  const w = CROWNFORGE.weekData.find((item) => item.week === week)
  return w?.days.find((item) => item.day === day) ?? null
}

export function getCalendarDay(date = new Date()): { week: number; day: number; program: 'crownforge' } | null {
  const iso = toLocalIsoDate(date)
  for (const week of CROWNFORGE.weekData) {
    const day = week.days.find((item) => item.date === iso)
    if (day) return { week: week.week, day: day.day, program: 'crownforge' }
  }
  return null
}

export function toLocalIsoDate(date: Date): string {
  const y = date.getFullYear()
  const m = String(date.getMonth() + 1).padStart(2, '0')
  const d = String(date.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}
