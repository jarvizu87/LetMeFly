import type {
  ExerciseCategory,
  ProgramDay,
  ProgramExercise,
  ProgramSet,
  ProgramWeek,
} from './programs'

const s = (
  label: string,
  reps?: number | string,
  loadText?: string,
  loadValue?: number,
  loadUnit?: 'lb' | 'kg',
  notes?: string,
): ProgramSet => ({ label, reps, loadText, loadValue, loadUnit, notes })

const ex = (
  id: string,
  name: string,
  category: ExerciseCategory,
  priority: ProgramExercise['priority'],
  sets: ProgramSet[],
  notes?: string,
  coaching?: string,
): ProgramExercise => ({
  id,
  name,
  category,
  priority,
  sets,
  notes,
  coaching,
  videoQuery: `${name} exercise tutorial`,
})

const lb = (label: string, reps: number | string, value: number, notes?: string) =>
  s(label, reps, `${value} lb`, value, 'lb', notes)

const repeated = (
  count: number,
  reps: number | string,
  loadText?: string,
  prefix = 'R',
  noteForLast?: string,
): ProgramSet[] =>
  Array.from({ length: count }, (_, index) =>
    s(`${prefix}${index + 1}`, reps, loadText, undefined, undefined, index === count - 1 ? noteForLast : undefined),
  )

const DAY_TITLES = {
  1: 'LOWER + PUSH STRENGTH / GLUTES',
  2: 'OLYMPIC SKILL + UPPER PUSH / DELTS / ARMS',
  3: 'RECOVERY + KNEES + HIP FLEXORS',
  4: 'PULL + HINGE STRENGTH',
  5: 'KB / SLED / GPP CONTROL DAY',
  6: 'FULL BODY VOLUME + BENCH/CHEST BIAS + FRONTAL PLANE KB',
  7: 'REST',
} as const

type LoadRep = [reps: number | string, load: number, notes?: string]
type TextLoadRep = [reps: number | string, load: string]

interface D1Config {
  date: string
  frontSquat: LoadRep[]
  bench: LoadRep[]
  row: string
  kbSwing: string
  sled: string
  belt: LoadRep[]
  incline: TextLoadRep[]
  ham: TextLoadRep[]
  lateral: string
  hip: LoadRep[]
  phase?: 'BUILD' | 'DELOAD'
}

interface D2Config {
  date: string
  hpc: LoadRep[]
  cleanPull: LoadRep[]
  pushPress: LoadRep[]
  cablePress: string
  rearDelt: string
  rope: string
  lateral: string
  curl: string
  deload?: boolean
}

interface D4Config {
  date: string
  deadlift: LoadRep[]
  verticalPull: string
  row: string
  ham: string
  pallof: string
  sled: string
  pullover: string
  face: string
  shrug: string
  deload?: boolean
}

interface D5Config {
  date: string
  swing: string
  goblet: string
  halo: string
  suitcase: string
  deadBug: string
  sled: string
  engine: string
  plank: string
  rounds: number
  sourceRoundNote?: string
  deload?: boolean
}

interface D6Config {
  date: string
  bench: LoadRep[]
  belt: LoadRep[]
  pulldown: string
  kb: string
  kneeRaise: string
  mainSled: string
  secondaryHingeName: 'RDL' | 'Cable Pull-Through' | 'Hamstring Curl'
  secondaryHinge: string
  stepUp: string
  straightArm: string
  lateral: string
  cablePress: string
  jm: string
  pushup: string
  rearDelt: string
  rope: string
  lateralLunge: string
  copenhagen: string
  offsetMarch: string
  lateralClean: string
  finishPush: string
  finishBackward: string
  deload?: boolean
}

const makeWarmupD1 = (): ProgramExercise[] => [
  ex('bike-incline-walk', 'Bike / Incline Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
  ex('backward-sled-drag-primer', 'Backward Sled Drag', 'sled', 'mandatory', repeated(2, '20m')),
  ex('glute-bridge-iso', 'Glute Bridge ISO', 'secondary', 'mandatory', repeated(2, '20 sec')),
  ex('tibialis-raise', 'Tibialis Raise', 'secondary', 'mandatory', repeated(2, '15–20')),
  ex('front-squat-bench-ramp', 'Front Squat + Bench Ramp Sets', 'primary', 'mandatory', [s('Ramp', 'Empty bar → first work set')]),
]

const makeD1 = (config: D1Config): ProgramDay => ({
  day: 1,
  date: config.date,
  title: DAY_TITLES[1],
  role: 'Strength-density day. Main lifts ramp; final heavy sets may be focused alone.',
  readinessRule:
    config.phase === 'DELOAD'
      ? 'DELOAD: Front Squat + Bench remain mandatory technique work. Keep every rep easy and clean; no grinders and no added volume.'
      : 'Front Squat + Bench are mandatory. Yellow keeps clean primary work and highest-value chest/glute support. Stop the ramp before a grinder.',
  cutOrder: 'Lateral raise and lower-value accessories first. Never compress primary rest to preserve density.',
  sections: [
    { id: 'warmup', title: 'Warm-Up', exercises: makeWarmupD1() },
    {
      id: 'main',
      title: 'Main Strength Circuit',
      subtitle: 'Drop completed support movements; remaining main-lift sets finish alone. Full rest always wins.',
      exercises: [
        ex('front-squat', 'Front Squat', 'primary', 'mandatory', config.frontSquat.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('bench-press', 'Bench Press', 'primary', 'mandatory', config.bench.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('chest-supported-row', 'Chest-Supported Row', 'secondary', 'conditional', repeated(config.phase === 'DELOAD' ? 2 : 4, config.phase === 'DELOAD' ? 8 : 8, config.row)),
        ex('kb-swing', 'KB Swing', 'kettlebell', 'conditional', repeated(config.phase === 'DELOAD' ? 2 : 3, config.phase === 'DELOAD' ? 10 : 12, config.kbSwing), config.phase === 'DELOAD' ? 'Crisp and easy.' : 'Crisp hip snap.'),
        ex('hanging-knee-raise', 'Hanging Knee Raise', 'core', 'conditional', repeated(config.phase === 'DELOAD' ? 2 : 3, config.phase === 'DELOAD' ? '8–10 easy' : '10–12')),
        ex('backward-sled-drag-main', 'Backward Sled Drag', 'sled', 'conditional', repeated(config.phase === 'DELOAD' ? 2 : 4, config.phase === 'DELOAD' ? '20m' : '20–30m', config.sled)),
      ],
    },
    {
      id: 'secondary',
      title: config.phase === 'DELOAD' ? 'Secondary Circuit — Easy Deload' : 'Secondary Circuit',
      exercises: [
        ex('belt-squat', 'Belt Squat', 'secondary', 'conditional', config.belt.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('incline-db-press', 'Incline DB Press', 'secondary', 'conditional', config.incline.map(([reps, load], i) => s(`R${i + 1}`, reps, load))),
        ex('hamstring-curl', 'Hamstring Curl', 'secondary', 'conditional', config.ham.map(([reps, load], i) => s(`R${i + 1}`, reps, load))),
        ex('lateral-raise', 'Lateral Raise', 'secondary', 'optional', repeated(config.phase === 'DELOAD' ? 2 : 3, config.phase === 'DELOAD' ? 12 : 15, config.lateral)),
        ex('hip-thrust', 'Hip Thrust', 'secondary', 'conditional', config.hip.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes)), config.phase === 'DELOAD' ? 'Easy deload sets.' : '2-second squeeze.'),
      ],
    },
  ],
})

const makeD2 = (config: D2Config): ProgramDay => {
  const prepRounds = config.deload ? 2 : 3
  const smallRounds = config.deload ? 2 : 3
  return {
    day: 2,
    date: config.date,
    title: DAY_TITLES[2],
    role: 'Crisp Olympic work. No HIIT. Push/delt/arm support only; avoid heavy pulling overlap before Day 4.',
    readinessRule: config.deload
      ? 'DELOAD: Olympic positions stay crisp and easy. No misses, grinders, extra clean/pull sets, or added upper-body volume.'
      : 'Olympic prep + Hang Power Clean / Clean Pull / Push Press quality are mandatory. Stop a set when timing, receiving position, grip, or bar speed deteriorates.',
    cutOrder: 'Extra arm/delt rounds and completed support drills first. Never add rows, hard carries, HIIT, or heavy hinge work.',
    sections: [
      {
        id: 'olympic-prep',
        title: `Olympic Prep Circuit — ${config.deload ? '1–2 Easy Rounds' : '3 Rounds'}`,
        exercises: [
          ex('front-rack-mobility', 'Front Rack Mobility', 'power', 'mandatory', repeated(prepRounds, '30–45 sec')),
          ex('muscle-clean', 'Muscle Clean', 'power', 'mandatory', repeated(prepRounds, config.deload ? 2 : 3)),
          ex('tall-clean', 'Tall Clean', 'power', 'mandatory', repeated(prepRounds, config.deload ? 2 : 3)),
          ex('clean-grip-rdl-knee', 'Clean-Grip RDL to Knee', 'power', 'mandatory', repeated(prepRounds, config.deload ? 2 : 3, 'light')),
          ex('jump-stick', 'Jump and Stick Landing', 'power', 'mandatory', repeated(prepRounds, config.deload ? 2 : 3)),
          ex('dead-bug', 'Dead Bug', 'core', 'mandatory', repeated(prepRounds, config.deload ? '5/side' : '6/side')),
        ],
      },
      {
        id: 'receiving',
        title: 'Main Receiving Lift Circuit',
        subtitle: 'Drop completed support drills; finish remaining Hang Power Clean work alone. Full rest and clean catches always win.',
        exercises: [
          ex('hang-power-clean', 'Hang Power Clean', 'power', 'mandatory', config.hpc.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes)), config.deload ? 'Easy technique work.' : 'Crisp catches only.'),
          ex('cable-external-rotation-d2', 'Cable External Rotation', 'secondary', 'mandatory', repeated(config.deload ? 4 : 4, '10/side', '5 lb/side')),
          ex('hip-flexor-rockback-d2', 'Hip Flexor Rockback', 'recovery', 'mandatory', repeated(config.deload ? 2 : 4, '6/side')),
          ex('ankle-rock-d2', 'Ankle Rock', 'recovery', 'mandatory', repeated(config.deload ? 2 : 3, '6/side')),
        ],
      },
      {
        id: 'clean-pull-reset',
        title: 'Clean Pull Reset Block',
        exercises: [
          ex('clean-pull', 'Clean Pull', 'power', 'mandatory', config.cleanPull.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes)), config.deload ? 'Easy extension patterning.' : 'Loaded extension strength, not conditioning.'),
          ex('serratus-wall-slide-d2', 'Serratus Wall Slide', 'secondary', 'mandatory', repeated(smallRounds, 8)),
          ex('t-spine-rotation-d2', 'T-Spine Rotation', 'recovery', 'mandatory', repeated(smallRounds, '5/side')),
          ex('wrist-pulses-d2', 'Wrist Flexor/Extensor Pulses', 'recovery', 'mandatory', repeated(smallRounds, '10 each')),
        ],
      },
      {
        id: 'push-support',
        title: config.deload ? 'Push Press Support — Easy Deload' : 'Push Press Support — 3 Rounds',
        exercises: [
          ex('push-press', 'Push Press', 'power', 'mandatory', config.pushPress.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
          ex('band-pull-apart', 'Band Pull-Apart', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? '12–15' : '15–20')),
        ],
      },
      {
        id: 'upper-support',
        title: config.deload ? 'Upper Push / Delt / Arm — 2 Easy Rounds' : 'Upper Push / Delt / Arm — 3 Rounds Conditional',
        exercises: [
          ex('cable-press-around', 'Cable Press-Around', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 10 : 12, config.cablePress)),
          ex('rear-delt-fly', 'Rear Delt Fly', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 12 : '15–20', config.rearDelt)),
          ex('rope-pushdown', 'Rope Pushdown', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 10 : 12, config.rope)),
          ex('scap-pushup', 'Scap Push-Up', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? '8–10' : '10–15')),
          ex('lateral-raise-d2', 'Lateral Raise', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 12 : 15, config.lateral)),
          ex('db-curl', 'DB Curl', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 10 : '10–12', config.curl)),
          ex('box-breathing', 'Box Breathing', 'recovery', 'optional', [s('Final reset', '2–4 min')]),
        ],
      },
    ],
  }
}

const makeRecoveryD3 = (date: string, deload = false): ProgramDay => ({
  day: 3,
  date,
  title: DAY_TITLES[3],
  role: 'Recovery day. Move blood, restore positions, and protect Day 4 pulling.',
  readinessRule: 'Target 30–45 minutes. Yellow = minimum recovery core. Red = easy walk/mobility or full rest. Finish feeling better than you started.',
  cutOrder: 'No hidden hinge, hard carry, heavy row, or intervals.',
  sections: [
    {
      id: 'recovery-flow',
      title: 'Recovery Flow — 2 Rounds Conditional',
      exercises: [
        ex('turkish-getup', 'Turkish Get-Up', 'kettlebell', 'conditional', repeated(2, '1/side', '8 kg (20 lb) KB'), 'Light and smooth.'),
        ex('kb-halo', 'KB Halo', 'kettlebell', 'conditional', repeated(2, '5 each direction', '8 kg (20 lb) KB')),
        ex('windmill', 'Windmill', 'kettlebell', 'conditional', repeated(2, '3/side', '8 kg (20 lb) KB'), 'Controlled.'),
        ex('arm-bar', 'Arm Bar', 'kettlebell', 'conditional', repeated(2, '3 slow breaths/side', '8 kg (20 lb) KB')),
      ],
    },
    {
      id: 'hip-core',
      title: 'Hip Flexor / Core Block — 2 Rounds',
      exercises: [
        ex('reverse-crunch', 'Reverse Crunch', 'core', 'mandatory', repeated(2, '10–15')),
        ex('cable-march', 'Band or Cable March', 'core', 'mandatory', repeated(2, '10/leg', '20 lb cable')),
        ex('dead-bug-hollow', 'Dead Bug or Hollow Hold', 'core', 'mandatory', repeated(2, '20–30 sec')),
      ],
    },
    {
      id: 'rotation',
      title: 'Controlled Rotation Block',
      exercises: [
        ex('half-kneeling-chop', 'Half-Kneeling Chop', 'core', 'conditional', repeated(2, '10/side', '20 lb cable')),
        ex('half-kneeling-lift', 'Half-Kneeling Lift', 'core', 'conditional', repeated(2, '10/side', '20 lb cable')),
      ],
    },
    {
      id: 'knee-sled',
      title: 'Knee / Sled Block',
      exercises: [
        ex('backward-sled-d3', 'Backward Sled Drag', 'sled', 'mandatory', repeated(4, '20m', 'sled + 25 lb'), 'Easy.'),
        ex('forward-sled-d3', 'Light Forward Sled Push', 'sled', 'conditional', repeated(3, '20m', 'sled + 25 lb'), 'Easy.'),
        ex('tibialis-d3', 'Tibialis Raise', 'secondary', 'mandatory', repeated(3, '15–20')),
        ex('step-up-d3', 'Step-Up', 'secondary', 'conditional', repeated(3, '8–10/leg', '20 lb DBs', 'R', 'Source range is 2–3 sets; third set only if restorative.')),
      ],
    },
    {
      id: 'easy-cardio',
      title: 'Easy Cardio — Optional / Restorative Only',
      exercises: [ex('walk-bike-d3', 'Walk or Bike', 'recovery', 'optional', [s('Easy Zone 2', '20–30 min')])],
    },
  ],
})

const makeD4 = (config: D4Config): ProgramDay => ({
  day: 4,
  date: config.date,
  title: DAY_TITLES[4],
  role: 'Heavy hinge/pull day. Deadlift work lives inside the circuit but does not get rushed.',
  readinessRule: config.deload
    ? 'DELOAD: Deadlift remains technique work. Use full rest, easy bar speed, and no extra hinge or yoke work.'
    : 'Deadlift main work is mandatory with full rest. Stop before bar speed or position clearly degrades; required pulling/posterior support comes next.',
  cutOrder: 'Extra yoke/trunk volume, redundant pulling, and anything that degrades grip or low-back quality first.',
  sections: [
    {
      id: 'warmup-d4',
      title: 'Warm-Up',
      exercises: [
        ex('bike-walk-d4', 'Bike / Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
        ex('glute-bridge-d4', 'Glute Bridge', 'secondary', 'mandatory', repeated(2, 12)),
        ex('hip-hinge-drill-d4', 'Hip Hinge Drill', 'recovery', 'mandatory', repeated(2, 8)),
        ex('bird-dog-d4', 'Bird Dog', 'core', 'mandatory', repeated(2, '8/side')),
        ex('lat-pulldown-warmup-d4', 'Lat Pulldown Warm-Up', 'secondary', 'mandatory', repeated(2, 10)),
      ],
    },
    {
      id: 'main-d4',
      title: config.deload ? 'Main Pull / Hinge — Easy Deload' : 'Main Pull / Hinge Circuit',
      exercises: [
        ex('deadlift', 'Deadlift', 'primary', 'mandatory', config.deadlift.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('pullup-pulldown-d4', 'Pull-Up or Lat Pulldown', 'secondary', 'conditional', repeated(config.deload ? 2 : 4, config.verticalPull, undefined)),
        ex('chest-supported-row-d4', 'Chest-Supported Row', 'secondary', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? 8 : 8, config.row)),
        ex('hamstring-curl-d4', 'Hamstring Curl', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 8 : 10, config.ham)),
        ex('pallof-press', 'Pallof Press', 'core', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? '8/side' : '10/side', config.pallof)),
        ex('backward-sled-drag-d4', 'Backward Sled Drag', 'sled', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? '20m' : '20–30m', config.sled)),
      ],
    },
    {
      id: 'yoke-trunk',
      title: config.deload ? 'Back / Yoke / Trunk — Easy Deload' : 'Back / Yoke / Trunk Support — Conditional',
      exercises: [
        ex('cable-pullover', 'Cable Pullover', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 10 : 12, config.pullover)),
        ex('face-pull', 'Face Pull', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 12 : 15, config.face)),
        ex('chest-supported-shrug', 'Chest-Supported Shrug', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 10 : '10–12', config.shrug)),
        ex('reverse-crunch-d4', 'Reverse Crunch or Dead Bug', 'core', 'optional', repeated(config.deload ? 2 : 3, config.deload ? '8–10 easy' : '10–12')),
      ],
    },
  ],
})

const makeD5 = (config: D5Config): ProgramDay => ({
  day: 5,
  date: config.date,
  title: DAY_TITLES[5],
  role: 'Controlled conditioning after Day 4 without stealing from Day 6 bench/full-body quality.',
  readinessRule: config.deload
    ? 'DELOAD / FLEX: Keep the written easy two-round source dose. Yellow may abbreviate further; Red = walk/mobility or rest.'
    : 'GREEN = full source GPP. YELLOW = 2 clean KB-flow rounds, then choose either 2 controlled sled trips or 8–12 min easy engine. RED = recovery/rest.',
  cutOrder: 'Never make skipped GPP up on Day 6. Carries / extra sled trips / KB press-style extras leave first when fatigue rises.',
  sections: [
    {
      id: 'kb-flow',
      title: `KB Control Flow — ${config.rounds}${config.deload ? ' Easy' : ''} Rounds`,
      subtitle: config.sourceRoundNote,
      exercises: [
        ex('kb-swing-d5', 'KB Swing', 'kettlebell', 'conditional', repeated(config.rounds, config.deload ? 10 : 15, config.swing), config.deload ? 'Easy and crisp.' : 'Crisp.'),
        ex('goblet-squat', 'Goblet Squat', 'kettlebell', 'conditional', repeated(config.rounds, config.deload ? 8 : 10, config.goblet)),
        ex('kb-halo-d5', 'KB Halo', 'kettlebell', 'conditional', repeated(config.rounds, config.deload ? '5 each direction' : '6 each direction', config.halo)),
        ex('suitcase-march', 'Suitcase March', 'carry', 'conditional', repeated(config.rounds, config.deload ? '15 steps/side' : '20 steps/side', config.suitcase)),
        ex('dead-bug-pullover', 'Dead Bug Pullover', 'core', 'conditional', repeated(config.rounds, config.deload ? '6/side' : '8/side', config.deadBug)),
      ],
    },
    {
      id: 'sled-engine',
      title: 'Sled / Engine Block',
      exercises: [
        ex('sled-push-d5', 'Sled Push', 'sled', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? '20m easy' : '20–30m', config.sled, 'R', config.deload ? undefined : 'Source dose is 3–4 trips; stop at 3 if quality or Day 6 readiness says so.')),
        ex('backward-sled-d5', 'Backward Sled Drag', 'sled', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? '20m easy' : '20–30m', config.sled, 'R', config.deload ? undefined : 'Source dose is 3–4 trips; stop at 3 if quality or Day 6 readiness says so.')),
        ex('bike-row-walk-d5', 'Bike / Row / Walk', 'recovery', 'optional', repeated(config.deload ? 2 : 4, config.engine), config.deload ? 'Easy.' : 'Easy/moderate.'),
        ex('plank-shoulder-tap', 'Plank Shoulder Tap', 'core', 'optional', repeated(config.deload ? 2 : 3, config.plank)),
      ],
    },
    {
      id: 'mobility-reset',
      title: 'Mobility Reset',
      exercises: [
        ex('hip-flexor-rockback', 'Hip Flexor Rockback', 'recovery', 'optional', repeated(2, '8/side')),
        ex('serratus-wall-slide', 'Serratus Wall Slide', 'recovery', 'optional', repeated(2, 10)),
        ex('9090-breathing', '90/90 Breathing', 'recovery', 'optional', repeated(2, '4 breaths')),
      ],
    },
  ],
})

const makeD6 = (config: D6Config): ProgramDay => ({
  day: 6,
  date: config.date,
  title: DAY_TITLES[6],
  role: config.deload
    ? 'Deload full-body session. Bench/chest stays first, everything else is easy and restorative.'
    : 'Bench/chest gets the push; everything else stays moderate and density-focused.',
  readinessRule: config.deload
    ? 'DELOAD: Keep every written set easy. If Day 5 was full, omit the separate sled finisher by default; do not add near-failure or make-up work.'
    : 'Bench quality is the session authority. If Day 5 was FULL, omit the separate Day 6 sled finisher by default.',
  cutOrder: 'Sled/engine → extra KB/core → tertiary delt/arm → secondary lower body. Protect bench/chest priority.',
  sections: [
    {
      id: 'warmup-d6',
      title: 'Warm-Up + Sled / Glute / Knee Primer',
      exercises: [
        ex('bike-walk-d6', 'Bike or Walk', 'recovery', 'mandatory', [s('Easy', '3–5 min')]),
        ex('backward-sled-primer-d6', 'Backward Sled Drag', 'sled', 'mandatory', repeated(2, '20m')),
        ex('miniband-lateral-walk', 'Mini-Band Lateral Walk', 'secondary', 'mandatory', repeated(2, '10 each way')),
        ex('glute-bridge-iso-d6', 'Glute Bridge ISO', 'secondary', 'mandatory', repeated(2, '20 sec')),
        ex('tibialis-d6', 'Tibialis Raise', 'secondary', 'mandatory', repeated(2, '15–20')),
        ex('kb-swing-primer-d6', 'KB Swing', 'kettlebell', 'mandatory', repeated(2, 10, config.deload ? '12 kg (25 lb) KB' : config.kb), 'Primer.'),
      ],
    },
    {
      id: 'main-d6',
      title: config.deload ? 'Main Full-Body + Bench — Easy Deload' : 'Main Full-Body + Bench Volume Circuit',
      exercises: [
        ex('bench-volume-d6', 'Bench Press', 'primary', 'mandatory', config.bench.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('belt-squat-d6', 'Belt Squat', 'secondary', 'conditional', config.belt.map(([reps, load, notes], i) => lb(`R${i + 1}`, reps, load, notes))),
        ex('pulldown-d6', 'Wide or Neutral Pulldown', 'secondary', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? 8 : 10, config.pulldown)),
        ex('kb-swing-d6', 'KB Swing', 'kettlebell', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? 10 : '15–20', config.kb, 'R', config.deload ? undefined : 'Fourth set is the top of the source range; stop at 3 if not fresh.')),
        ex('hanging-knee-d6', 'Hanging Knee Raise', 'core', 'conditional', repeated(config.deload ? 2 : 3, config.kneeRaise)),
        ex('sled-push-main-d6', 'Sled Push', 'sled', 'conditional', repeated(config.deload ? 2 : 4, config.deload ? '20m easy' : '20–30m', config.mainSled)),
      ],
    },
    {
      id: 'secondary-d6',
      title: config.deload ? 'Secondary Volume — 1–2 Easy Rounds' : 'Secondary Volume Circuit — 2–3 Rounds',
      exercises: [
        ex('secondary-hinge-d6', config.secondaryHingeName, 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 10 : config.secondaryHingeName === 'RDL' ? 10 : 12, config.secondaryHinge), config.deload ? 'Easy deload.' : config.secondaryHingeName === 'RDL' ? 'Crisp, not heavy.' : undefined),
        ex('step-up-d6', 'Step-Up', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? '8/leg' : '10/leg', config.stepUp, 'R', config.deload ? undefined : 'Third round only if Green.')),
        ex('straight-arm-pulldown-d6', 'Straight-Arm Pulldown', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 10 : 12, config.straightArm)),
        ex('lateral-raise-d6', 'Lateral Raise', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 12 : 15, config.lateral)),
      ],
    },
    {
      id: 'chest-triceps-d6',
      title: config.deload ? 'Chest / Shoulder / Triceps — 1–2 Easy Rounds' : 'Chest / Shoulder / Triceps Focus — 2–3 Rounds',
      exercises: [
        ex('cable-press-around-d6', 'Cable Press-Around', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 10 : '12–15', config.cablePress)),
        ex('jm-press', 'JM Press', 'secondary', 'conditional', repeated(config.deload ? 2 : 3, config.deload ? 8 : '6–10', config.jm), config.deload ? 'Easy; no elbow strain.' : undefined),
        ex('pushup-d6', 'Push-Up', 'secondary', 'conditional', [s('Work', config.pushup)]),
        ex('rear-delt-d6', 'Rear Delt Fly', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 12 : '15–20', config.rearDelt)),
        ex('rope-pushdown-d6', 'Rope Pushdown', 'secondary', 'optional', repeated(config.deload ? 2 : 3, config.deload ? 10 : '10–12', config.rope)),
      ],
    },
    {
      id: 'frontal-d6',
      title: config.deload ? 'Frontal Plane / Lateral Core — Easy' : 'Frontal Plane / Lateral Core — 2 Rounds',
      exercises: [
        ex('kb-lateral-lunge', 'KB Lateral Lunge', 'kettlebell', 'conditional', repeated(2, config.deload ? '6/side' : '8/side', config.lateralLunge)),
        ex('copenhagen-plank', 'Copenhagen Plank', 'core', 'conditional', repeated(config.deload ? 1 : 2, config.copenhagen)),
        ex('offset-rack-march', 'Offset Rack March', 'carry', 'conditional', repeated(2, config.deload ? '15 steps/side' : '20 steps/side', config.offsetMarch)),
        ex('kb-lateral-clean', 'KB Lateral Clean or Outside Swing to Rack', 'kettlebell', 'conditional', repeated(2, config.deload ? '3/side' : '5/side', config.lateralClean)),
      ],
    },
    {
      id: 'sled-finish-d6',
      title: 'Sled Finish — Conditional / Default Omit After Full Day 5',
      subtitle: 'If Day 5 was abbreviated or skipped and readiness is Green, one source sled dose may remain. Never use this to make up Day 5.',
      exercises: [
        ex('sled-push-finish-d6', 'Sled Push', 'sled', 'optional', repeated(config.deload ? 2 : 4, config.deload ? '20m easy' : '20–30m', config.finishPush, 'F', config.deload ? undefined : 'Source range is 2–4 trips.')),
        ex('backward-sled-finish-d6', 'Backward Sled Drag', 'sled', 'optional', repeated(config.deload ? 2 : 4, config.deload ? '20m easy' : '20–30m', config.finishBackward, 'F', config.deload ? undefined : 'Source range is 2–4 trips.')),
      ],
    },
  ],
})

const makeRestD7 = (date: string): ProgramDay => ({
  day: 7,
  date,
  title: DAY_TITLES[7],
  role: 'Recovery is part of the plan. No make-up punishment.',
  readinessRule: 'Rest. Easy walking or mobility only if it makes you feel better.',
  restDay: true,
  sections: [
    {
      id: 'rest-checklist',
      title: 'Rest Day Checklist',
      exercises: [
        ex('easy-walk-rest', 'Optional Easy Walk', 'recovery', 'optional', [s('Optional', '20–40 min')]),
        ex('mobility-rest', 'Mobility', 'recovery', 'optional', [s('Optional', 'Only if restorative')]),
      ],
    },
  ],
})

export const CROWNFORGE_WEEK_3: ProgramWeek = {
  week: 3,
  start: '2026-09-21',
  end: '2026-09-27',
  intent: 'Build the opening wave with controlled progression while preserving repeatable primary and Olympic quality.',
  days: [
    makeD1({
      date: '2026-09-21',
      frontSquat: [[5,105],[4,120],[3,135],[3,135],[3,145],[3,145],[4,130]],
      bench: [[4,130],[4,140],[3,150],[2,160]],
      row: '50 lb DBs', kbSwing: '20 kg (45 lb) KB', sled: 'sled + 45 lb',
      belt: [[12,110],[10,130],[8,150]],
      incline: [[10,'35 lb DBs'],[8,'40 lb DBs'],[8,'40 lb DBs']],
      ham: [[12,'50 lb'],[10,'60 lb'],[10,'70 lb']], lateral: '15 lb DBs',
      hip: [[10,115],[10,135],[10,155]],
    }),
    makeD2({
      date: '2026-09-22',
      hpc: [[3,100],[3,105],[3,110],[3,110],[3,110],[3,110]],
      cleanPull: [[3,145],[2,155],[2,160],[2,160]],
      pushPress: [[5,75],[4,80],[3,85]],
      cablePress: '20 lb/side', rearDelt: '15 lb DBs', rope: '45 lb', lateral: '15 lb DBs', curl: '25 lb DBs',
    }),
    makeRecoveryD3('2026-09-23'),
    makeD4({
      date: '2026-09-24', deadlift: [[4,170],[3,180],[2,190],['1–2',200]],
      verticalPull: 'BW 4–6 OR 100 lb × 10', row: '50 lb DBs', ham: '60 lb', pallof: '25 lb/side', sled: 'sled + 45 lb',
      pullover: '50 lb', face: '40 lb', shrug: '60 lb DBs',
    }),
    makeD5({
      date: '2026-09-25', swing: '20 kg (45 lb) KB', goblet: '20 kg (45 lb) KB', halo: '12 kg (25 lb) KB',
      suitcase: '20 kg (45 lb) KB', deadBug: '12 kg (25 lb) KB', sled: 'sled + 45 lb',
      engine: '60–90 sec easy/moderate', plank: '20 total', rounds: 3,
      sourceRoundNote: 'Three explicit exercise rounds are encoded; the retained source header allows an additional round only when fresh/Green.',
    }),
    makeD6({
      date: '2026-09-26',
      bench: [[5,100],[4,125],[3,140],[3,140],[3,150],[3,150],[3,150],[3,150],[4,140],[4,140]],
      belt: [[12,110],[10,130],[8,150]], pulldown: '100 lb', kb: '20 kg (45 lb) KB', kneeRaise: '10–12', mainSled: 'sled + 55 lb',
      secondaryHingeName: 'RDL', secondaryHinge: '115 lb', stepUp: '20 lb DBs', straightArm: '45 lb', lateral: '15 lb DBs',
      cablePress: '20 lb/side', jm: '55 lb', pushup: 'Near failure — stop before form breaks', rearDelt: '15 lb DBs', rope: '45 lb',
      lateralLunge: '12 kg (25 lb) KB', copenhagen: '15–25 sec/side', offsetMarch: '20 kg (45 lb) KB', lateralClean: '12 kg (25 lb) KB',
      finishPush: 'sled + 55 lb', finishBackward: 'sled + 45 lb',
    }),
    makeRestD7('2026-09-27'),
  ],
}

export const CROWNFORGE_WEEK_4: ProgramWeek = {
  week: 4,
  start: '2026-09-28',
  end: '2026-10-04',
  intent: 'Complete the hardest week of the wave without random extra work.',
  days: [
    makeD1({
      date: '2026-09-28',
      frontSquat: [[5,110],[4,125],[3,140],[3,140],['2–3',150],['2–3',150],[4,135]],
      bench: [[3,135],[3,145],[2,155],[2,165]],
      row: '55 lb DBs', kbSwing: '20 kg (45 lb) KB', sled: 'sled + 45 lb',
      belt: [[12,120],[10,140],[8,160]],
      incline: [[10,'40 lb DBs'],[8,'45 lb DBs'],[8,'45 lb DBs']],
      ham: [[12,'55 lb'],[10,'65 lb'],[10,'75 lb']], lateral: '15 lb DBs',
      hip: [[10,135],[10,155],[10,175]],
    }),
    makeD2({
      date: '2026-09-29',
      hpc: [[3,105],[3,110],[2,115],[2,115],[2,115],[2,115]],
      cleanPull: [[2,150],[2,160],[2,165],[2,165]],
      pushPress: [[4,75],[3,85],[2,90]],
      cablePress: '25 lb/side', rearDelt: '15 lb DBs', rope: '50 lb', lateral: '15 lb DBs', curl: '25 lb DBs',
    }),
    makeRecoveryD3('2026-09-30'),
    makeD4({
      date: '2026-10-01', deadlift: [[3,175],[3,185],[2,195],[1,205]],
      verticalPull: 'BW 4–6 OR 105 lb × 10', row: '55 lb DBs', ham: '65 lb', pallof: '25 lb/side', sled: 'sled + 45 lb',
      pullover: '55 lb', face: '45 lb', shrug: '65 lb DBs',
    }),
    makeD5({
      date: '2026-10-02', swing: '20 kg (45 lb) KB', goblet: '20 kg (45 lb) KB', halo: '12 kg (25 lb) KB',
      suitcase: '24 kg (55 lb) KB', deadBug: '12 kg (25 lb) KB', sled: 'sled + 55 lb',
      engine: '60–90 sec easy/moderate', plank: '20 total', rounds: 4,
    }),
    makeD6({
      date: '2026-10-03',
      bench: [[5,100],[4,130],[3,145],[3,145],[3,155],[3,155],[3,155],[4,145],[4,145]],
      belt: [[12,120],[10,140],[8,160]], pulldown: '105 lb', kb: '20 kg (45 lb) KB', kneeRaise: '10–12', mainSled: 'sled + 65 lb',
      secondaryHingeName: 'Cable Pull-Through', secondaryHinge: '50 lb', stepUp: '20 lb DBs', straightArm: '50 lb', lateral: '15 lb DBs',
      cablePress: '25 lb/side', jm: '60 lb', pushup: 'Near failure — stop before form breaks', rearDelt: '15 lb DBs', rope: '50 lb',
      lateralLunge: '16 kg (35 lb) KB', copenhagen: '15–25 sec/side', offsetMarch: '20 kg (45 lb) KB', lateralClean: '16 kg (35 lb) KB',
      finishPush: 'sled + 65 lb', finishBackward: 'sled + 55 lb',
    }),
    makeRestD7('2026-10-04'),
  ],
}

export const CROWNFORGE_WEEK_5: ProgramWeek = {
  week: 5,
  start: '2026-10-05',
  end: '2026-10-11',
  intent: 'Push the build wave to its highest clean stress while refusing grinders and unscheduled finishers.',
  days: [
    makeD1({
      date: '2026-10-05',
      frontSquat: [[4,115],[3,130],[2,145],[2,145],['1–2',155],['1–2',155],[3,135]],
      bench: [[3,135],[2,150],[1,160],[1,170],[1,175,'Only if crisp.']],
      row: '60 lb DBs', kbSwing: '20 kg (45 lb) KB', sled: 'sled + 55 lb',
      belt: [[12,130],[10,150],[8,170]],
      incline: [[10,'45 lb DBs'],[8,'45 lb DBs'],[8,'45 lb DBs']],
      ham: [[12,'60 lb'],[10,'70 lb'],[10,'80 lb']], lateral: '15 lb DBs',
      hip: [[10,145],[10,165],[10,185]],
    }),
    makeD2({
      date: '2026-10-06',
      hpc: [[2,110],[2,115],[2,120],[2,120],[2,120],[2,120],[1,125,'Only if crisp.']],
      cleanPull: [[2,155],[2,165],[2,170],[1,175,'Only if crisp.']],
      pushPress: [[3,80],[2,90],[1,95]],
      cablePress: '25 lb/side', rearDelt: '15 lb DBs', rope: '55 lb', lateral: '15 lb DBs', curl: '30 lb DBs',
    }),
    makeRecoveryD3('2026-10-07'),
    makeD4({
      date: '2026-10-08', deadlift: [[3,170],[2,185],[1,195],[1,205],[1,210,'Only if crisp.']],
      verticalPull: 'BW 4–6 OR 110 lb × 10', row: '60 lb DBs', ham: '70 lb', pallof: '30 lb/side', sled: 'sled + 55 lb',
      pullover: '60 lb', face: '50 lb', shrug: '70 lb DBs',
    }),
    makeD5({
      date: '2026-10-09', swing: '20 kg (45 lb) KB', goblet: '24 kg (55 lb) KB', halo: '12 kg (25 lb) KB',
      suitcase: '24 kg (55 lb) KB', deadBug: '12 kg (25 lb) KB', sled: 'sled + 65 lb',
      engine: '60–90 sec easy/moderate', plank: '20 total', rounds: 3,
      sourceRoundNote: 'Three explicit exercise rounds are encoded. The retained source heading notes 4–5 if fresh; extra work is never automatic and remains subordinate to v2.1 Day 5 FLEX readiness.',
    }),
    makeD6({
      date: '2026-10-10',
      bench: [[5,105],[4,135],[3,150],[3,150],['2–3',160],['2–3',160],['2–3',160],[4,145],[4,145]],
      belt: [[12,130],[10,150],[8,170]], pulldown: '110 lb', kb: '20 kg (45 lb) KB', kneeRaise: '10–12', mainSled: 'sled + 75 lb',
      secondaryHingeName: 'Cable Pull-Through', secondaryHinge: '55 lb', stepUp: '20 lb DBs', straightArm: '55 lb', lateral: '15 lb DBs',
      cablePress: '25 lb/side', jm: '65 lb', pushup: 'Near failure — stop before form breaks', rearDelt: '15 lb DBs', rope: '55 lb',
      lateralLunge: '16 kg (35 lb) KB', copenhagen: '15–25 sec/side', offsetMarch: '24 kg (55 lb) KB', lateralClean: '16 kg (35 lb) KB',
      finishPush: 'sled + 75 lb', finishBackward: 'sled + 65 lb',
    }),
    makeRestD7('2026-10-11'),
  ],
}

export const CROWNFORGE_WEEK_6: ProgramWeek = {
  week: 6,
  start: '2026-10-12',
  end: '2026-10-18',
  intent: 'Deload the full system: reduce load and volume, preserve technical positions, and exit the week fresh enough to reload.',
  days: [
    makeD1({
      date: '2026-10-12',
      frontSquat: [[5,90],[3,100],[2,110]], bench: [[5,105],[3,115],[2,125]],
      row: '30 lb DBs', kbSwing: '12 kg (25 lb) KB', sled: 'sled + 25 lb',
      belt: [[10,70],[8,90]], incline: [[10,'25 lb DBs'],[8,'25 lb DBs']],
      ham: [[12,'30 lb'],[10,'40 lb']], lateral: '5 lb DBs', hip: [[10,95],[10,115]], phase: 'DELOAD',
    }),
    makeD2({
      date: '2026-10-13', hpc: [[3,80],[3,85],[2,90]], cleanPull: [[3,115],[2,125],[2,135]], pushPress: [[5,60],[3,65]],
      cablePress: '10 lb/side', rearDelt: '5 lb DBs', rope: '25 lb', lateral: '5 lb DBs', curl: '15 lb DBs', deload: true,
    }),
    makeRecoveryD3('2026-10-14', true),
    makeD4({
      date: '2026-10-15', deadlift: [[5,135],[3,155],[2,170]], verticalPull: 'BW 3–5 OR 70 lb × 8', row: '30 lb DBs', ham: '40 lb',
      pallof: '15 lb/side', sled: 'sled + 25 lb', pullover: '30 lb', face: '25 lb', shrug: '40 lb DBs', deload: true,
    }),
    makeD5({
      date: '2026-10-16', swing: '12 kg (25 lb) KB', goblet: '12 kg (25 lb) KB', halo: '8 kg (20 lb) KB', suitcase: '12 kg (25 lb) KB',
      deadBug: '8 kg (20 lb) KB', sled: 'sled + 25 lb', engine: '60 sec easy', plank: '12–16 total easy', rounds: 2, deload: true,
    }),
    makeD6({
      date: '2026-10-17', bench: [[5,95],[4,115],[3,125],[3,125]], belt: [[10,70],[8,90]], pulldown: '70 lb', kb: '12 kg (25 lb) KB',
      kneeRaise: '8–10 easy', mainSled: 'sled + 25 lb', secondaryHingeName: 'Hamstring Curl', secondaryHinge: '40 lb', stepUp: 'bodyweight',
      straightArm: '25 lb', lateral: '5 lb DBs', cablePress: '10 lb/side', jm: '35 lb', pushup: 'Easy reps only; no failure', rearDelt: '5 lb DBs', rope: '25 lb',
      lateralLunge: '8 kg (20 lb) KB', copenhagen: '10–15 sec/side easy', offsetMarch: '12 kg (25 lb) KB', lateralClean: '8 kg (20 lb) KB',
      finishPush: 'sled + 25 lb', finishBackward: 'sled + 25 lb', deload: true,
    }),
    makeRestD7('2026-10-18'),
  ],
}
