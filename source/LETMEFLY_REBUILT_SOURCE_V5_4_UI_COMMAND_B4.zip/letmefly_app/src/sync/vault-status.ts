import type { SyncRunResult, VaultStatus } from './sync-types'

export interface VaultStatusCard {
  vault: 'READY' | 'SAVED'
  cloud:
    | 'LOCAL ONLY'
    | 'SYNCING'
    | 'SYNCED'
    | 'OFFLINE'
    | 'SIGN-IN REQUIRED'
    | 'CONFLICT NEEDS REVIEW'
    | 'SYNC ERROR'
  pending: number
  lastSyncAt?: string | null
}

export function deriveVaultStatus(
  state: VaultStatus,
  pending: number,
  lastSyncAt?: string | null,
): VaultStatusCard {
  switch (state) {
    case 'local-only':
      return { vault: 'READY', cloud: 'LOCAL ONLY', pending, lastSyncAt }
    case 'saved-local':
      return { vault: 'SAVED', cloud: 'LOCAL ONLY', pending, lastSyncAt }
    case 'syncing':
      return { vault: 'SAVED', cloud: 'SYNCING', pending, lastSyncAt }
    case 'synced':
      return { vault: 'READY', cloud: 'SYNCED', pending: 0, lastSyncAt }
    case 'offline-pending':
      return { vault: 'SAVED', cloud: 'OFFLINE', pending, lastSyncAt }
    case 'reauth-required':
      return {
        vault: 'SAVED',
        cloud: 'SIGN-IN REQUIRED',
        pending,
        lastSyncAt,
      }
    case 'conflict':
      return {
        vault: 'SAVED',
        cloud: 'CONFLICT NEEDS REVIEW',
        pending,
        lastSyncAt,
      }
    case 'sync-error':
      return { vault: 'SAVED', cloud: 'SYNC ERROR', pending, lastSyncAt }
  }
}

export function resultToVaultStatus(result: SyncRunResult): VaultStatus {
  if (result.conflicts > 0) return 'conflict'
  if (result.offline && result.pending > 0) return 'offline-pending'
  if (!result.authenticated && result.pending > 0) return 'reauth-required'
  if (result.pending > 0) return 'syncing'
  return 'synced'
}
