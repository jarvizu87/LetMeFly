import type {
  DomainStoreName,
  LocalDomainRecord,
  SyncOutboxEntry,
} from '../db/local-db'

export type WireEntityType =
  | 'athletes'
  | 'athlete_preferences'
  | 'athlete_goals'
  | 'athlete_equipment'
  | 'devices'
  | 'training_max_history'
  | 'program_instances'
  | 'program_events'
  | 'readiness_entries'
  | 'workout_sessions'
  | 'workout_exercises'
  | 'workout_sets'
  | 'bodyweight_entries'
  | 'personal_records'
  | 'coaching_decisions'
  | 'exercise_substitutions'
  | 'tm_recommendations'

export const STORE_TO_WIRE: Record<DomainStoreName, WireEntityType> = {
  athletes: 'athletes',
  athletePreferences: 'athlete_preferences',
  athleteGoals: 'athlete_goals',
  athleteEquipment: 'athlete_equipment',
  devices: 'devices',
  trainingMaxHistory: 'training_max_history',
  programInstances: 'program_instances',
  programEvents: 'program_events',
  readinessEntries: 'readiness_entries',
  workoutSessions: 'workout_sessions',
  workoutExercises: 'workout_exercises',
  workoutSets: 'workout_sets',
  bodyweightEntries: 'bodyweight_entries',
  personalRecords: 'personal_records',
  coachingDecisions: 'coaching_decisions',
  exerciseSubstitutions: 'exercise_substitutions',
  tmRecommendations: 'tm_recommendations',
}

export const WIRE_TO_STORE = Object.fromEntries(
  Object.entries(STORE_TO_WIRE).map(([store, wire]) => [wire, store]),
) as Record<WireEntityType, DomainStoreName>

export type ConflictPolicy =
  | 'critical-program'
  | 'workout-performance'
  | 'historical-record'
  | 'standard'

export const CONFLICT_POLICY: Record<DomainStoreName, ConflictPolicy> = {
  athletes: 'standard',
  athletePreferences: 'standard',
  athleteGoals: 'standard',
  athleteEquipment: 'standard',
  devices: 'standard',
  trainingMaxHistory: 'historical-record',
  programInstances: 'critical-program',
  programEvents: 'critical-program',
  readinessEntries: 'historical-record',
  workoutSessions: 'workout-performance',
  workoutExercises: 'workout-performance',
  workoutSets: 'workout-performance',
  bodyweightEntries: 'historical-record',
  personalRecords: 'historical-record',
  coachingDecisions: 'critical-program',
  exerciseSubstitutions: 'critical-program',
  tmRecommendations: 'critical-program',
}

export const PUSH_PRIORITY: Record<DomainStoreName, number> = {
  athletes: 0,
  athletePreferences: 10,
  athleteGoals: 10,
  athleteEquipment: 10,
  devices: 10,
  trainingMaxHistory: 20,
  programInstances: 30,
  readinessEntries: 30,
  programEvents: 40,
  workoutSessions: 50,
  workoutExercises: 60,
  workoutSets: 70,
  bodyweightEntries: 70,
  coachingDecisions: 75,
  personalRecords: 80,
  exerciseSubstitutions: 80,
  tmRecommendations: 80,
}

export interface RemoteApplyRequest {
  operationId: string
  athleteId: string
  entityType: WireEntityType
  entityId: string
  operation: 'upsert' | 'delete'
  baseRevision: number
  payload: Record<string, unknown>
  deviceId: string
}

export interface RemoteApplyResult {
  status: 'applied' | 'noop' | 'conflict' | 'rejected'
  duplicate?: boolean
  operation_id?: string
  entity_type?: WireEntityType
  entity_id?: string
  reason?: string
  message?: string
  server_revision?: number | null
  server_updated_at?: string | null
  remote_payload?: Record<string, unknown> | null
}

export interface RemoteSyncChange {
  change_seq: number
  athlete_id: string
  entity_type: WireEntityType
  entity_id: string
  operation: 'upsert' | 'delete'
  entity_revision: number
  changed_at: string
  payload: Record<string, unknown> | null
  source_operation_id: string | null
  source_device_id: string | null
}

export interface SyncRemote {
  verifyAuthenticated(): Promise<boolean>
  applyOperation(request: RemoteApplyRequest): Promise<RemoteApplyResult>
  pullChanges(
    athleteId: string,
    afterChangeSeq: number,
    limit: number,
  ): Promise<RemoteSyncChange[]>
  fetchEntity(
    entityType: WireEntityType,
    entityId: string,
  ): Promise<Record<string, unknown> | null>
}

export interface Stage6ConflictRecord {
  conflictId: string
  athleteId: string
  entityType: DomainStoreName
  entityId: string
  policy: ConflictPolicy
  localPayload: Record<string, unknown>
  remotePayload: Record<string, unknown> | null
  baseRevision: number
  remoteRevision: number | null
  sourceChangeSeq: number | null
  detectedAt: string
  resolvedAt: string | null
  resolution: 'local' | 'remote' | 'merged' | null
}

export interface PushCandidate {
  entry: SyncOutboxEntry
  current: LocalDomainRecord
  effectiveBaseRevision: number
}

export interface SyncRunResult {
  authenticated: boolean
  pushed: number
  pulled: number
  conflicts: number
  rejected: number
  pending: number
  offline: boolean
}

export type VaultStatus =
  | 'local-only'
  | 'saved-local'
  | 'syncing'
  | 'synced'
  | 'offline-pending'
  | 'reauth-required'
  | 'conflict'
  | 'sync-error'
