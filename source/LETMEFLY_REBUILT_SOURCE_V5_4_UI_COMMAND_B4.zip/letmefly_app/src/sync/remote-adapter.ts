import type {
  RemoteApplyRequest,
  RemoteApplyResult,
  RemoteSyncChange,
  SyncRemote,
  WireEntityType,
} from './sync-types'

type ApiError = { message?: string; code?: string }

interface ThenableResult<T> extends PromiseLike<{
  data: T | null
  error: ApiError | null
}> {}

interface QueryBuilder<T> extends ThenableResult<T> {
  select(columns?: string): QueryBuilder<T>
  eq(column: string, value: unknown): QueryBuilder<T>
  gt(column: string, value: unknown): QueryBuilder<T>
  order(column: string, options?: { ascending?: boolean }): QueryBuilder<T>
  limit(count: number): QueryBuilder<T>
  maybeSingle(): ThenableResult<Record<string, unknown>>
}

export interface SupabaseLike {
  auth: {
    getUser(): ThenableResult<{ user: { id: string } | null }>
  }
  rpc(
    fn: string,
    args: Record<string, unknown>,
  ): ThenableResult<RemoteApplyResult>
  from<T = Record<string, unknown>[]>(table: string): QueryBuilder<T>
}

const ALLOWED_TABLES = new Set<WireEntityType>([
  'athletes',
  'athlete_preferences',
  'athlete_goals',
  'athlete_equipment',
  'devices',
  'training_max_history',
  'program_instances',
  'program_events',
  'readiness_entries',
  'workout_sessions',
  'workout_exercises',
  'workout_sets',
  'bodyweight_entries',
  'personal_records',
  'coaching_decisions',
  'exercise_substitutions',
  'tm_recommendations',
])

export class SupabaseSyncRemote implements SyncRemote {
  constructor(private readonly supabase: SupabaseLike) {}

  async verifyAuthenticated(): Promise<boolean> {
    const { data, error } = await this.supabase.auth.getUser()
    return !error && Boolean(data?.user)
  }

  async applyOperation(
    request: RemoteApplyRequest,
  ): Promise<RemoteApplyResult> {
    const { data, error } = await this.supabase.rpc('apply_sync_operation', {
      p_operation_id: request.operationId,
      p_athlete_id: request.athleteId,
      p_entity_type: request.entityType,
      p_entity_id: request.entityId,
      p_operation: request.operation,
      p_base_revision: request.baseRevision,
      p_payload: request.payload,
      p_device_id: request.deviceId,
    })

    if (error) {
      throw new Error(error.message ?? 'Cloud sync RPC failed')
    }
    if (!data) throw new Error('Cloud sync RPC returned no result')
    return data
  }

  async pullChanges(
    athleteId: string,
    afterChangeSeq: number,
    limit: number,
  ): Promise<RemoteSyncChange[]> {
    const { data, error } = await this.supabase
      .from<RemoteSyncChange[]>('sync_changes')
      .select(
        'change_seq,athlete_id,entity_type,entity_id,operation,' +
          'entity_revision,changed_at,payload,source_operation_id,source_device_id',
      )
      .eq('athlete_id', athleteId)
      .gt('change_seq', afterChangeSeq)
      .order('change_seq', { ascending: true })
      .limit(limit)

    if (error) throw new Error(error.message ?? 'Failed to pull cloud changes')
    return data ?? []
  }

  async fetchEntity(
    entityType: WireEntityType,
    entityId: string,
  ): Promise<Record<string, unknown> | null> {
    if (!ALLOWED_TABLES.has(entityType)) {
      throw new Error(`Unknown cloud entity: ${entityType}`)
    }

    const { data, error } = await this.supabase
      .from(entityType)
      .select('*')
      .eq('id', entityId)
      .maybeSingle()

    if (error) {
      throw new Error(error.message ?? `Failed to fetch ${entityType}/${entityId}`)
    }

    return data
  }
}
