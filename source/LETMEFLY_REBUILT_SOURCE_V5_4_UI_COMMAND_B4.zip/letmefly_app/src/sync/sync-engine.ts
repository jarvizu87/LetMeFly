import {
  type SyncRunResult,
  STORE_TO_WIRE,
  type SyncRemote,
} from './sync-types'
import {
  acknowledge,
  applyRemoteChange,
  getSyncState,
  loadPushCandidates,
  markFailed,
  markSyncing,
  pendingCount,
  recordPushConflict,
  scheduleRetry,
} from './local-sync'

export interface SyncEngineOptions {
  pushBatchSize?: number
  pullBatchSize?: number
  maxPullPages?: number
}

export class LetMeFlySyncEngine {
  private running: Promise<SyncRunResult> | null = null

  constructor(
    private readonly remote: SyncRemote,
    private readonly athleteId: string,
    private readonly deviceId: string,
    private readonly options: SyncEngineOptions = {},
  ) {}

  syncNow(): Promise<SyncRunResult> {
    if (this.running) return this.running

    this.running = this.run().finally(() => {
      this.running = null
    })
    return this.running
  }

  private async run(): Promise<SyncRunResult> {
    const result: SyncRunResult = {
      authenticated: false,
      pushed: 0,
      pulled: 0,
      conflicts: 0,
      rejected: 0,
      pending: 0,
      offline: typeof navigator !== 'undefined' && navigator.onLine === false,
    }

    if (result.offline) {
      result.pending = await pendingCount(this.athleteId)
      return result
    }

    const authenticated = await this.remote.verifyAuthenticated()
    result.authenticated = authenticated
    if (!authenticated) {
      result.pending = await pendingCount(this.athleteId)
      return result
    }

    const candidates = await loadPushCandidates(
      this.athleteId,
      this.options.pushBatchSize ?? 50,
    )

    for (const candidate of candidates) {
      await markSyncing(candidate.entry.operationId)

      try {
        const response = await this.remote.applyOperation({
          operationId: candidate.entry.operationId,
          athleteId: this.athleteId,
          entityType: STORE_TO_WIRE[candidate.entry.entityType],
          entityId: candidate.entry.entityId,
          operation: candidate.entry.operation,
          baseRevision: candidate.effectiveBaseRevision,
          payload: candidate.entry.payload,
          deviceId: this.deviceId,
        })

        if (response.status === 'applied' || response.status === 'noop') {
          await acknowledge(candidate, response)
          result.pushed += 1
        } else if (response.status === 'conflict') {
          await recordPushConflict(candidate, response)
          result.conflicts += 1
        } else {
          await markFailed(
            candidate.entry.operationId,
            response.message ?? response.reason ?? 'Cloud write rejected',
          )
          result.rejected += 1
        }
      } catch (error) {
        const attempt = candidate.entry.attemptCount + 1
        await scheduleRetry(
          candidate.entry.operationId,
          error,
          retryDelayMs(attempt),
        )
      }
    }

    const pullLimit = this.options.pullBatchSize ?? 100
    const maxPages = this.options.maxPullPages ?? 20

    for (let page = 0; page < maxPages; page += 1) {
      const state = await getSyncState(this.athleteId)
      const cursor = state?.lastChangeSeq ?? 0

      let changes
      try {
        changes = await this.remote.pullChanges(
          this.athleteId,
          cursor,
          pullLimit,
        )
      } catch {
        break
      }

      if (changes.length === 0) break

      for (const change of changes) {
        let payload = change.payload

        // Older/change-feed rows without embedded payload can still converge
        // by fetching the current authorized entity.
        if (!payload) {
          payload = await this.remote.fetchEntity(
            change.entity_type,
            change.entity_id,
          )
        }

        if (!payload) {
          // A physical server deletion should not normally happen for syncable
          // domain records; ordinary deletion is a tombstone with a payload.
          // Stop rather than skipping the cursor and silently losing information.
          throw new Error(
            `Missing payload for change ${change.change_seq}`,
          )
        }

        const outcome = await applyRemoteChange(
          this.athleteId,
          change,
          payload,
        )

        result.pulled += 1
        if (outcome === 'conflict') result.conflicts += 1
      }

      if (changes.length < pullLimit) break
    }

    result.pending = await pendingCount(this.athleteId)
    return result
  }
}

export function retryDelayMs(attempt: number): number {
  const exponent = Math.max(0, Math.min(attempt - 1, 8))
  const base = 2_000 * 2 ** exponent
  const capped = Math.min(base, 5 * 60_000)
  const jitter = 0.75 + Math.random() * 0.5
  return Math.round(capped * jitter)
}
