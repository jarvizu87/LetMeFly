import {
  type DomainStoreName,
  type LocalDomainRecord,
  type SyncOutboxEntry,
  type SyncState,
  newId,
  openLetMeFlyDb,
  requestToPromise,
  transactionDone,
} from '../db/local-db'
import {
  CONFLICT_POLICY,
  PUSH_PRIORITY,
  type PushCandidate,
  type RemoteApplyResult,
  type RemoteSyncChange,
  type Stage6ConflictRecord,
  WIRE_TO_STORE,
} from './sync-types'

function keyOf(entityType: DomainStoreName, entityId: string): string {
  return `${entityType}:${entityId}`
}

function eligible(entry: SyncOutboxEntry, now: number): boolean {
  if (entry.status !== 'pending' && entry.status !== 'retry') return false
  if (!entry.nextAttemptAt) return true
  const due = Date.parse(entry.nextAttemptAt)
  return !Number.isFinite(due) || due <= now
}

export function compactOutbox(
  entries: SyncOutboxEntry[],
  now = Date.now(),
): SyncOutboxEntry[] {
  const blocked = new Set<string>()
  for (const entry of entries) {
    if (entry.status === 'conflict') {
      blocked.add(keyOf(entry.entityType, entry.entityId))
    }
  }

  const latest = new Map<string, SyncOutboxEntry>()
  for (const entry of entries) {
    const key = keyOf(entry.entityType, entry.entityId)
    if (blocked.has(key) || !eligible(entry, now)) continue

    const prior = latest.get(key)
    if (
      !prior ||
      entry.localVersion > prior.localVersion ||
      (entry.localVersion === prior.localVersion &&
        entry.createdAt > prior.createdAt)
    ) {
      latest.set(key, entry)
    }
  }

  return [...latest.values()].sort((a, b) => {
    const priority = PUSH_PRIORITY[a.entityType] - PUSH_PRIORITY[b.entityType]
    if (priority !== 0) return priority
    return a.createdAt.localeCompare(b.createdAt)
  })
}

export async function loadPushCandidates(
  athleteId: string,
  limit = 50,
): Promise<PushCandidate[]> {
  const db = await openLetMeFlyDb()
  let selected: SyncOutboxEntry[]
  try {
    const tx = db.transaction('syncOutbox', 'readonly')
    const all = await requestToPromise<SyncOutboxEntry[]>(
      tx.objectStore('syncOutbox').getAll(),
    )
    await transactionDone(tx)
    selected = compactOutbox(
      all.filter((entry) => entry.athleteId === athleteId),
    ).slice(0, limit)
  } finally {
    db.close()
  }

  const candidates: PushCandidate[] = []

  for (const entry of selected) {
    const entityDb = await openLetMeFlyDb()
    try {
      const tx = entityDb.transaction(entry.entityType, 'readonly')
      const current = await requestToPromise<LocalDomainRecord | undefined>(
        tx.objectStore(entry.entityType).get(entry.entityId),
      )
      await transactionDone(tx)

      if (!current) continue

      // If another local edit happened after compaction, use the newer outbox item
      // on the next sync pass rather than sending stale desired state.
      if (current._local.localVersion !== entry.localVersion) continue

      candidates.push({
        entry,
        current,
        effectiveBaseRevision: current._local.baseRevision,
      })
    } finally {
      entityDb.close()
    }
  }

  return candidates
}

async function deleteOutboxThroughVersion(
  store: IDBObjectStore,
  entityType: DomainStoreName,
  entityId: string,
  localVersion: number,
): Promise<void> {
  const operations = await requestToPromise<SyncOutboxEntry[]>(
    store.index('by-entity').getAll([entityType, entityId]),
  )

  for (const op of operations) {
    if (op.localVersion <= localVersion) {
      store.delete(op.operationId)
    }
  }
}

function cleanRemote(
  payload: Record<string, unknown>,
  previous?: LocalDomainRecord,
): LocalDomainRecord {
  const revision = Number(payload.revision ?? 0)
  return {
    ...payload,
    id: String(payload.id),
    created_at: String(
      payload.created_at ?? previous?.created_at ?? new Date().toISOString(),
    ),
    updated_at: String(payload.updated_at ?? new Date().toISOString()),
    deleted_at:
      payload.deleted_at == null ? null : String(payload.deleted_at),
    revision,
    _local: {
      localVersion: previous?._local.localVersion ?? 0,
      baseRevision: revision,
      dirty: false,
      createdOffline: false,
      lastModifiedByDeviceId:
        previous?._local.lastModifiedByDeviceId ?? 'cloud',
    },
  }
}

export async function markSyncing(operationId: string): Promise<void> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('syncOutbox', 'readwrite')
    const store = tx.objectStore('syncOutbox')
    const entry = await requestToPromise<SyncOutboxEntry | undefined>(
      store.get(operationId),
    )

    if (entry) {
      store.put({
        ...entry,
        status: 'syncing',
        attemptCount: entry.attemptCount + 1,
        updatedAt: new Date().toISOString(),
        lastError: null,
      } satisfies SyncOutboxEntry)
    }

    await transactionDone(tx)
  } finally {
    db.close()
  }
}

export async function acknowledge(
  candidate: PushCandidate,
  result: RemoteApplyResult,
): Promise<void> {
  if (result.status !== 'applied' && result.status !== 'noop') {
    throw new Error('Only applied/noop results can be acknowledged')
  }

  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction(
      [candidate.entry.entityType, 'syncOutbox'],
      'readwrite',
    )
    const entityStore = tx.objectStore(candidate.entry.entityType)
    const outboxStore = tx.objectStore('syncOutbox')
    const current = await requestToPromise<LocalDomainRecord | undefined>(
      entityStore.get(candidate.entry.entityId),
    )

    if (
      result.status === 'noop' &&
      candidate.entry.operation === 'delete'
    ) {
      if (
        current &&
        current._local.localVersion === candidate.entry.localVersion &&
        current._local.baseRevision === 0
      ) {
        entityStore.delete(candidate.entry.entityId)
      }

      await deleteOutboxThroughVersion(
        outboxStore,
        candidate.entry.entityType,
        candidate.entry.entityId,
        candidate.entry.localVersion,
      )
      await transactionDone(tx)
      return
    }

    if (!result.remote_payload) {
      tx.abort()
      throw new Error('Applied cloud response omitted remote payload')
    }

    const serverRevision = Number(
      result.server_revision ?? result.remote_payload.revision ?? 0,
    )

    if (current) {
      if (current._local.localVersion === candidate.entry.localVersion) {
        entityStore.put(cleanRemote(result.remote_payload, current))
      } else {
        // A newer local edit occurred while this operation was in flight.
        entityStore.put({
          ...current,
          revision: Math.max(current.revision, serverRevision),
          _local: {
            ...current._local,
            baseRevision: Math.max(
              current._local.baseRevision,
              serverRevision,
            ),
            dirty: true,
            createdOffline: false,
          },
        } satisfies LocalDomainRecord)
      }
    }

    await deleteOutboxThroughVersion(
      outboxStore,
      candidate.entry.entityType,
      candidate.entry.entityId,
      candidate.entry.localVersion,
    )

    await transactionDone(tx)
  } finally {
    db.close()
  }
}

export async function scheduleRetry(
  operationId: string,
  error: unknown,
  retryAfterMs: number,
): Promise<void> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('syncOutbox', 'readwrite')
    const store = tx.objectStore('syncOutbox')
    const entry = await requestToPromise<SyncOutboxEntry | undefined>(
      store.get(operationId),
    )

    if (entry) {
      store.put({
        ...entry,
        status: 'retry',
        nextAttemptAt: new Date(Date.now() + retryAfterMs).toISOString(),
        updatedAt: new Date().toISOString(),
        lastError: error instanceof Error ? error.message : String(error),
      } satisfies SyncOutboxEntry)
    }

    await transactionDone(tx)
  } finally {
    db.close()
  }
}

export async function markFailed(
  operationId: string,
  message: string,
): Promise<void> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('syncOutbox', 'readwrite')
    const store = tx.objectStore('syncOutbox')
    const entry = await requestToPromise<SyncOutboxEntry | undefined>(
      store.get(operationId),
    )

    if (entry) {
      store.put({
        ...entry,
        status: 'failed',
        updatedAt: new Date().toISOString(),
        lastError: message,
      } satisfies SyncOutboxEntry)
    }

    await transactionDone(tx)
  } finally {
    db.close()
  }
}

export async function recordPushConflict(
  candidate: PushCandidate,
  result: RemoteApplyResult,
): Promise<void> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction(
      ['syncOutbox', 'syncConflicts'],
      'readwrite',
    )
    const outboxStore = tx.objectStore('syncOutbox')
    const conflictStore = tx.objectStore('syncConflicts')

    const entry = await requestToPromise<SyncOutboxEntry | undefined>(
      outboxStore.get(candidate.entry.operationId),
    )
    if (entry) {
      outboxStore.put({
        ...entry,
        status: 'conflict',
        updatedAt: new Date().toISOString(),
        lastError: result.reason ?? 'Revision conflict',
      } satisfies SyncOutboxEntry)
    }

    const conflict: Stage6ConflictRecord = {
      conflictId: newId(),
      athleteId: candidate.entry.athleteId,
      entityType: candidate.entry.entityType,
      entityId: candidate.entry.entityId,
      policy: CONFLICT_POLICY[candidate.entry.entityType],
      localPayload: candidate.current,
      remotePayload: result.remote_payload ?? null,
      baseRevision: candidate.effectiveBaseRevision,
      remoteRevision: result.server_revision ?? null,
      sourceChangeSeq: null,
      detectedAt: new Date().toISOString(),
      resolvedAt: null,
      resolution: null,
    }

    conflictStore.add(conflict)
    await transactionDone(tx)
  } finally {
    db.close()
  }
}

function stable(value: unknown): string {
  if (Array.isArray(value)) {
    return `[${value.map(stable).join(',')}]`
  }

  if (value && typeof value === 'object') {
    const obj = value as Record<string, unknown>
    return `{${Object.keys(obj)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stable(obj[key])}`)
      .join(',')}}`
  }

  return JSON.stringify(value)
}

function semantic(record: Record<string, unknown>): Record<string, unknown> {
  const copy = { ...record }
  delete copy._local
  delete copy.revision
  delete copy.updated_at
  delete copy.owner_user_id
  if ('deleted_at' in copy) {
    copy.__deleted = copy.deleted_at != null
    delete copy.deleted_at
  }
  return copy
}

function semanticallyEqual(
  a: Record<string, unknown>,
  b: Record<string, unknown>,
): boolean {
  return stable(semantic(a)) === stable(semantic(b))
}

export async function applyRemoteChange(
  athleteId: string,
  change: RemoteSyncChange,
  payload: Record<string, unknown>,
): Promise<'applied' | 'ignored' | 'converged' | 'conflict'> {
  const storeName = WIRE_TO_STORE[change.entity_type]
  if (!storeName) throw new Error(`Unknown entity ${change.entity_type}`)
  if (change.athlete_id !== athleteId) {
    throw new Error('Refusing cross-athlete remote change')
  }

  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction(
      [storeName, 'syncOutbox', 'syncConflicts', 'syncState'],
      'readwrite',
    )
    const entityStore = tx.objectStore(storeName)
    const outboxStore = tx.objectStore('syncOutbox')
    const conflictStore = tx.objectStore('syncConflicts')
    const stateStore = tx.objectStore('syncState')

    const current = await requestToPromise<LocalDomainRecord | undefined>(
      entityStore.get(change.entity_id),
    )

    let outcome: 'applied' | 'ignored' | 'converged' | 'conflict' = 'ignored'

    if (!current) {
      entityStore.put(cleanRemote(payload))
      outcome = 'applied'
    } else if (!current._local.dirty) {
      if (change.entity_revision > current.revision) {
        entityStore.put(cleanRemote(payload, current))
        outcome = 'applied'
      }
    } else if (change.entity_revision <= current._local.baseRevision) {
      outcome = 'ignored'
    } else if (semanticallyEqual(current, payload)) {
      entityStore.put(cleanRemote(payload, current))
      await deleteOutboxThroughVersion(
        outboxStore,
        storeName,
        change.entity_id,
        current._local.localVersion,
      )
      outcome = 'converged'
    } else {
      const conflict: Stage6ConflictRecord = {
        conflictId: newId(),
        athleteId,
        entityType: storeName,
        entityId: change.entity_id,
        policy: CONFLICT_POLICY[storeName],
        localPayload: current,
        remotePayload: payload,
        baseRevision: current._local.baseRevision,
        remoteRevision: change.entity_revision,
        sourceChangeSeq: change.change_seq,
        detectedAt: new Date().toISOString(),
        resolvedAt: null,
        resolution: null,
      }
      conflictStore.add(conflict)

      const operations = await requestToPromise<SyncOutboxEntry[]>(
        outboxStore.index('by-entity').getAll([
          storeName,
          change.entity_id,
        ]),
      )

      for (const op of operations) {
        outboxStore.put({
          ...op,
          status: 'conflict',
          updatedAt: new Date().toISOString(),
          lastError: `Remote change ${change.change_seq} needs review`,
        } satisfies SyncOutboxEntry)
      }

      outcome = 'conflict'
    }

    const priorState = await requestToPromise<SyncState | undefined>(
      stateStore.get(athleteId),
    )

    stateStore.put({
      ...(priorState ?? {
        athleteId,
        deviceId: 'unknown',
        lastChangeSeq: 0,
        cloudSchemaVersion: 1,
        bootstrapStatus: 'complete' as const,
      }),
      lastChangeSeq: Math.max(
        priorState?.lastChangeSeq ?? 0,
        change.change_seq,
      ),
      lastSuccessfulSyncAt: new Date().toISOString(),
    } satisfies SyncState)

    await transactionDone(tx)
    return outcome
  } finally {
    db.close()
  }
}

export async function getSyncState(
  athleteId: string,
): Promise<SyncState | undefined> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('syncState', 'readonly')
    const state = await requestToPromise<SyncState | undefined>(
      tx.objectStore('syncState').get(athleteId),
    )
    await transactionDone(tx)
    return state
  } finally {
    db.close()
  }
}

export async function pendingCount(athleteId: string): Promise<number> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('syncOutbox', 'readonly')
    const all = await requestToPromise<SyncOutboxEntry[]>(
      tx.objectStore('syncOutbox').getAll(),
    )
    await transactionDone(tx)
    return all.filter(
      (entry) =>
        entry.athleteId === athleteId &&
        entry.status !== 'failed' &&
        entry.status !== 'conflict',
    ).length
  } finally {
    db.close()
  }
}
