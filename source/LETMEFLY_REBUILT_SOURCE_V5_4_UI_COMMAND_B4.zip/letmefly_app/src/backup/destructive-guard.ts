import type {
  LetMeFlyBackup,
  BackupVerification,
} from './backup-types'
import {
  createAthleteBackup,
  verifyAthleteBackup,
} from './backup-service'

export interface PreDestructiveBackupResult {
  backup: LetMeFlyBackup
  verification: BackupVerification
}

export async function requirePreDestructiveBackup(
  athleteId: string,
  appVersion: string | null = null,
): Promise<PreDestructiveBackupResult> {
  const backup = await createAthleteBackup(athleteId, appVersion)
  const verification = await verifyAthleteBackup(backup)

  if (!verification.valid) {
    throw new Error(
      'Current athlete backup failed verification; destructive operation blocked',
    )
  }

  return { backup, verification }
}

// Stage 11 restore must call this guard BEFORE any destructive clear/import.
// The caller can additionally force a user download of `backup` before continuing.
