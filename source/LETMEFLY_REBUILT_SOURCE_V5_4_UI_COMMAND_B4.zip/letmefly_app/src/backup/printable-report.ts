import type { LetMeFlyBackup } from './backup-types'

export function buildPrintableReportHtml(
  backup: LetMeFlyBackup,
): string {
  const athlete = backup.payload.domain.athletes[0] ?? {}
  const tms = activeTrainingMaxes(
    backup.payload.domain.trainingMaxHistory,
  )
  const recentWorkouts = [...backup.payload.domain.workoutSessions]
    .filter((row: any) => !row.deleted_at)
    .sort(
      (a: any, b: any) =>
        Date.parse(b.started_at ?? b.created_at) -
        Date.parse(a.started_at ?? a.created_at),
    )
    .slice(0, 10)

  const recentBodyweight = [...backup.payload.domain.bodyweightEntries]
    .filter((row: any) => !row.deleted_at)
    .sort(
      (a: any, b: any) =>
        Date.parse(b.measured_at) - Date.parse(a.measured_at),
    )
    .slice(0, 10)

  const prs = [...backup.payload.domain.personalRecords]
    .filter((row: any) => !row.deleted_at)
    .sort(
      (a: any, b: any) =>
        Date.parse(b.achieved_at) - Date.parse(a.achieved_at),
    )
    .slice(0, 12)

  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>LetMeFly Athlete Report</title>
<style>
  body { font-family: Arial, sans-serif; margin: 36px; color: #111; }
  h1 { margin-bottom: 4px; }
  h2 { margin-top: 28px; border-bottom: 1px solid #bbb; padding-bottom: 6px; }
  .muted { color: #666; font-size: 12px; }
  .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
  .card { border: 1px solid #ccc; border-radius: 8px; padding: 12px; }
  table { width: 100%; border-collapse: collapse; margin-top: 8px; }
  th, td { text-align: left; padding: 7px; border-bottom: 1px solid #ddd; font-size: 12px; }
  th { background: #f2f2f2; }
  @media print {
    body { margin: 18mm; }
    .no-print { display: none; }
  }
</style>
</head>
<body>
<h1>LetMeFly Athlete Report</h1>
<div class="muted">Generated ${escapeHtml(backup.createdAt)} - Report only; use the JSON backup for restore.</div>

<h2>Athlete</h2>
<div class="grid">
  <div class="card"><strong>Name</strong><br>${escapeHtml(String((athlete as any).display_name ?? ''))}</div>
  <div class="card"><strong>Backup schema</strong><br>v${backup.formatVersion}</div>
  <div class="card"><strong>Athlete ID</strong><br>${escapeHtml(backup.athleteId)}</div>
</div>

<h2>Active Training Maxes</h2>
${table(
  ['Exercise', 'TM', 'Unit', 'Effective'],
  tms.map((row: any) => [
    row.exercise_key,
    row.tm_value,
    row.tm_unit,
    row.effective_at,
  ]),
)}

<h2>Recent Workouts</h2>
${table(
  ['Workout', 'Program', 'Week', 'Day', 'Status', 'Completed'],
  recentWorkouts.map((row: any) => [
    row.workout_name ?? '',
    row.program_key ?? '',
    row.week_number ?? '',
    row.day_key ?? '',
    row.status ?? '',
    row.completed_at ?? '',
  ]),
)}

<h2>Recent Bodyweight</h2>
${table(
  ['Measured', 'Weight', 'Unit'],
  recentBodyweight.map((row: any) => [
    row.measured_at,
    row.value,
    row.unit,
  ]),
)}

<h2>Recent PRs</h2>
${table(
  ['Exercise', 'Type', 'Achieved', 'Performance'],
  prs.map((row: any) => [
    row.exercise_key ?? '',
    row.pr_type ?? '',
    row.achieved_at ?? '',
    JSON.stringify(row.performance ?? {}),
  ]),
)}

<p class="muted">
This PDF/report is a human-readable export. It is not the authoritative LetMeFly restore file.
</p>
</body>
</html>`
}

export function openPrintableReport(
  backup: LetMeFlyBackup,
): void {
  const html = buildPrintableReportHtml(backup)
  const popup = window.open('', '_blank', 'noopener,noreferrer')
  if (!popup) throw new Error('Print window was blocked')

  popup.document.open()
  popup.document.write(html)
  popup.document.close()
  popup.focus()
  popup.print()
}

function activeTrainingMaxes(rows: any[]): any[] {
  const byExercise = new Map<string, any>()

  for (const row of rows) {
    if (row.deleted_at) continue
    const key = String(row.exercise_key ?? '')
    if (!key) continue

    const prior = byExercise.get(key)
    if (
      !prior ||
      Date.parse(row.effective_at) > Date.parse(prior.effective_at)
    ) {
      byExercise.set(key, row)
    }
  }

  return [...byExercise.values()].sort((a, b) =>
    String(a.exercise_key).localeCompare(String(b.exercise_key)),
  )
}

function table(headers: string[], rows: unknown[][]): string {
  const head = headers
    .map((header) => `<th>${escapeHtml(header)}</th>`)
    .join('')

  const body = rows.length
    ? rows
        .map(
          (row) =>
            `<tr>${row
              .map((value) => `<td>${escapeHtml(String(value ?? ''))}</td>`)
              .join('')}</tr>`,
        )
        .join('')
    : `<tr><td colspan="${headers.length}">No records</td></tr>`

  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;')
}
