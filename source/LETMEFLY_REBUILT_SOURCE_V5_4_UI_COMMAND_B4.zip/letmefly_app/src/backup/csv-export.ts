import type {
  HumanExportRow,
  LetMeFlyBackup,
} from './backup-types'
import { downloadText } from './backup-service'

export interface CsvFile {
  filename: string
  content: string
}

export function buildCsvExports(
  backup: LetMeFlyBackup,
): CsvFile[] {
  const tables: Array<[string, unknown[]]> = [
    ['profile', backup.payload.domain.athletes],
    ['goals', backup.payload.domain.athleteGoals],
    ['equipment', backup.payload.domain.athleteEquipment],
    ['training-maxes', backup.payload.domain.trainingMaxHistory],
    ['program-instances', backup.payload.domain.programInstances],
    ['program-events', backup.payload.domain.programEvents],
    ['workouts', backup.payload.domain.workoutSessions],
    ['workout-exercises', backup.payload.domain.workoutExercises],
    ['workout-sets', backup.payload.domain.workoutSets],
    ['bodyweight', backup.payload.domain.bodyweightEntries],
    ['readiness', backup.payload.domain.readinessEntries],
    ['personal-records', backup.payload.domain.personalRecords],
    ['coaching-decisions', backup.payload.domain.coachingDecisions],
    ['substitutions', backup.payload.domain.exerciseSubstitutions],
    ['tm-recommendations', backup.payload.domain.tmRecommendations],
  ]

  return tables.map(([name, rows]) => ({
    filename: `letmefly-${name}.csv`,
    content: toCsv(rows.map(stripLocalAndFlatten)),
  }))
}

export function downloadCsvExports(
  backup: LetMeFlyBackup,
): void {
  // Dependency-free initial implementation downloads one CSV at a time.
  // A future UI may package these into a ZIP.
  for (const file of buildCsvExports(backup)) {
    downloadText(file.filename, file.content, 'text/csv;charset=utf-8')
  }
}

export function toCsv(rows: HumanExportRow[]): string {
  const columns = [...new Set(rows.flatMap((row) => Object.keys(row)))]

  if (columns.length === 0) return ''

  const output = [columns.map(csvCell).join(',')]

  for (const row of rows) {
    output.push(
      columns.map((column) => csvCell(row[column] ?? null)).join(','),
    )
  }

  return output.join('\r\n')
}

function stripLocalAndFlatten(value: unknown): HumanExportRow {
  const input =
    value && typeof value === 'object'
      ? (value as Record<string, unknown>)
      : { value }

  const row: HumanExportRow = {}

  for (const [key, raw] of Object.entries(input)) {
    if (key === '_local') continue

    if (
      raw == null ||
      typeof raw === 'string' ||
      typeof raw === 'number' ||
      typeof raw === 'boolean'
    ) {
      row[key] = raw as string | number | boolean | null
    } else {
      row[key] = JSON.stringify(raw)
    }
  }

  return row
}

function csvCell(value: unknown): string {
  if (value == null) return ''

  const text =
    typeof value === 'string' ? value : String(value)

  if (/[",\r\n]/.test(text)) {
    return `"${text.replace(/"/g, '""')}"`
  }

  return text
}
