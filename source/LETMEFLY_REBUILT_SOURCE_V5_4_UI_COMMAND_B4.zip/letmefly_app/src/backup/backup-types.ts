import type {
  DomainStoreName,
  LocalDomainRecord,
  SyncConflict,
  SyncOutboxEntry,
  SyncState,
  DeviceState,
} from '../db/local-db'

export const LETMEFLY_BACKUP_FORMAT = 'letmefly-athlete-backup' as const
export const LETMEFLY_BACKUP_FORMAT_VERSION = 1 as const

export interface BackupIntegrity {
  algorithm: 'SHA-256'
  payloadSha256: string
  storeCounts: Record<string, number>
}

export interface BackupDomain {
  athletes: LocalDomainRecord[]
  athletePreferences: LocalDomainRecord[]
  athleteGoals: LocalDomainRecord[]
  athleteEquipment: LocalDomainRecord[]
  devices: LocalDomainRecord[]
  trainingMaxHistory: LocalDomainRecord[]
  programInstances: LocalDomainRecord[]
  programEvents: LocalDomainRecord[]
  readinessEntries: LocalDomainRecord[]
  workoutSessions: LocalDomainRecord[]
  workoutExercises: LocalDomainRecord[]
  workoutSets: LocalDomainRecord[]
  bodyweightEntries: LocalDomainRecord[]
  personalRecords: LocalDomainRecord[]
  coachingDecisions: LocalDomainRecord[]
  exerciseSubstitutions: LocalDomainRecord[]
  tmRecommendations: LocalDomainRecord[]
}

export interface BackupLocalRecovery {
  syncState: SyncState[]
  syncOutbox: SyncOutboxEntry[]
  syncConflicts: SyncConflict[]
  deviceState: DeviceState[]
}

export interface BackupPayload {
  domain: BackupDomain
  localRecovery: BackupLocalRecovery
}

export interface LetMeFlyBackup {
  format: typeof LETMEFLY_BACKUP_FORMAT
  formatVersion: typeof LETMEFLY_BACKUP_FORMAT_VERSION
  createdAt: string
  appVersion: string | null
  dbVersion: number
  domainSchemaVersion: number
  athleteId: string
  integrity: BackupIntegrity
  payload: BackupPayload
}

export interface BackupVerification {
  valid: boolean
  expectedHash: string
  actualHash: string
  countMismatches: Array<{
    store: string
    expected: number
    actual: number
  }>
}

export type HumanExportRow = Record<string, string | number | boolean | null>
