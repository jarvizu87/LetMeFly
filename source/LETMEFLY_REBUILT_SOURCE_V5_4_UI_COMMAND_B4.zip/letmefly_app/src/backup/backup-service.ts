import {
  ALL_STORES,
  DOMAIN_STORES,
  LMF_DB_VERSION,
  LMF_DOMAIN_SCHEMA_VERSION,
  openLetMeFlyDb,
  requestToPromise,
  transactionDone,
} from '../db/local-db'
import {
  LETMEFLY_BACKUP_FORMAT,
  LETMEFLY_BACKUP_FORMAT_VERSION,
  type BackupDomain,
  type BackupLocalRecovery,
  type BackupPayload,
  type BackupVerification,
  type LetMeFlyBackup,
} from './backup-types'

const LOCAL_RECOVERY_STORES = [
  'syncState',
  'syncOutbox',
  'syncConflicts',
  'deviceState',
] as const

export async function createAthleteBackup(
  athleteId: string,
  appVersion: string | null = null,
): Promise<LetMeFlyBackup> {
  const db = await openLetMeFlyDb()
  let payload: BackupPayload

  try {
    const stores = [...DOMAIN_STORES, ...LOCAL_RECOVERY_STORES]
    const tx = db.transaction(stores, 'readonly')

    const domain = {} as BackupDomain
    const localRecovery = {} as BackupLocalRecovery

    for (const storeName of DOMAIN_STORES) {
      const rows = await requestToPromise<any[]>(
        tx.objectStore(storeName).getAll(),
      )

      ;(domain as any)[storeName] = rows.filter((row) => {
        if (storeName === 'athletes') return row.id === athleteId
        return row.athlete_id === athleteId
      })
    }

    for (const storeName of LOCAL_RECOVERY_STORES) {
      const rows = await requestToPromise<any[]>(
        tx.objectStore(storeName).getAll(),
      )

      ;(localRecovery as any)[storeName] = rows.filter((row) => {
        if (storeName === 'deviceState') return true
        return row.athleteId === athleteId
      })
    }

    await transactionDone(tx)
    payload = { domain, localRecovery }
  } finally {
    db.close()
  }

  if (payload.domain.athletes.length !== 1) {
    throw new Error(
      `Expected one athlete for backup; found ${payload.domain.athletes.length}`,
    )
  }

  const payloadSha256 = await sha256Hex(stableStringify(payload))
  const storeCounts = calculateStoreCounts(payload)

  const backup: LetMeFlyBackup = {
    format: LETMEFLY_BACKUP_FORMAT,
    formatVersion: LETMEFLY_BACKUP_FORMAT_VERSION,
    createdAt: new Date().toISOString(),
    appVersion,
    dbVersion: LMF_DB_VERSION,
    domainSchemaVersion: LMF_DOMAIN_SCHEMA_VERSION,
    athleteId,
    integrity: {
      algorithm: 'SHA-256',
      payloadSha256,
      storeCounts,
    },
    payload,
  }

  const verification = await verifyAthleteBackup(backup)
  if (!verification.valid) {
    throw new Error('Backup failed integrity verification before download')
  }

  return backup
}

export async function verifyAthleteBackup(
  backup: LetMeFlyBackup,
): Promise<BackupVerification> {
  if (backup.format !== LETMEFLY_BACKUP_FORMAT) {
    return {
      valid: false,
      expectedHash: backup.integrity?.payloadSha256 ?? '',
      actualHash: '',
      countMismatches: [],
    }
  }

  const actualHash = await sha256Hex(stableStringify(backup.payload))
  const expectedHash = backup.integrity.payloadSha256

  const actualCounts = calculateStoreCounts(backup.payload)
  const countMismatches: BackupVerification['countMismatches'] = []

  for (const [store, expected] of Object.entries(
    backup.integrity.storeCounts,
  )) {
    const actual = actualCounts[store] ?? 0
    if (actual !== expected) {
      countMismatches.push({ store, expected, actual })
    }
  }

  return {
    valid:
      actualHash === expectedHash &&
      countMismatches.length === 0,
    expectedHash,
    actualHash,
    countMismatches,
  }
}

export function calculateStoreCounts(
  payload: BackupPayload,
): Record<string, number> {
  const counts: Record<string, number> = {}

  for (const [store, rows] of Object.entries(payload.domain)) {
    counts[store] = rows.length
  }
  for (const [store, rows] of Object.entries(payload.localRecovery)) {
    counts[store] = rows.length
  }

  return counts
}

export function backupFilename(createdAt = new Date()): string {
  const stamp = createdAt
    .toISOString()
    .replace(/[-:]/g, '')
    .replace(/\.\d{3}Z$/, 'Z')

  return `letmefly-athlete-${stamp}.letmefly-backup.json`
}

export function serializeBackup(
  backup: LetMeFlyBackup,
): string {
  return JSON.stringify(backup, null, 2)
}

export function downloadBackupFile(
  backup: LetMeFlyBackup,
): void {
  downloadText(
    backupFilename(new Date(backup.createdAt)),
    serializeBackup(backup),
    'application/json',
  )
}

export async function parseAndVerifyBackupFile(
  text: string,
): Promise<{
  backup: LetMeFlyBackup
  verification: BackupVerification
}> {
  const parsed = JSON.parse(text) as LetMeFlyBackup
  const verification = await verifyAthleteBackup(parsed)
  return { backup: parsed, verification }
}

export async function sha256Hex(input: string): Promise<string> {
  const encoded = new TextEncoder().encode(input)
  const digest = await crypto.subtle.digest('SHA-256', encoded)

  return [...new Uint8Array(digest)]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('')
}

export function stableStringify(value: unknown): string {
  if (Array.isArray(value)) {
    return `[${value.map(stableStringify).join(',')}]`
  }

  if (value && typeof value === 'object') {
    const object = value as Record<string, unknown>
    const entries = Object.keys(object)
      .sort()
      .map(
        (key) =>
          `${JSON.stringify(key)}:${stableStringify(object[key])}`,
      )
    return `{${entries.join(',')}}`
  }

  return JSON.stringify(value)
}

export function downloadText(
  filename: string,
  text: string,
  mimeType: string,
): void {
  const blob = new Blob([text], { type: mimeType })
  const url = URL.createObjectURL(blob)

  try {
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = filename
    anchor.click()
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 0)
  }
}
