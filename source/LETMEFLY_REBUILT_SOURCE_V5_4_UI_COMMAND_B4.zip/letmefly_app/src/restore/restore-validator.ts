import {
  LETMEFLY_BACKUP_FORMAT,
  LETMEFLY_BACKUP_FORMAT_VERSION,
  type LetMeFlyBackup,
} from '../backup/backup-types'
import { verifyAthleteBackup } from '../backup/backup-service'
import type {
  RestoreIssue,
  RestorePreview,
  RestoreValidation,
} from './restore-types'

type Row = Record<string, any>

export async function validateRestoreBackup(
  backup: LetMeFlyBackup,
): Promise<RestoreValidation> {
  const issues: RestoreIssue[] = []

  if (backup.format !== LETMEFLY_BACKUP_FORMAT) {
    issues.push({
      code: 'wrong-format',
      message: `Expected ${LETMEFLY_BACKUP_FORMAT}`,
    })
    return { valid: false, issues }
  }

  if (backup.formatVersion !== LETMEFLY_BACKUP_FORMAT_VERSION) {
    issues.push({
      code: 'unsupported-format-version',
      message:
        `Supported formatVersion is ${LETMEFLY_BACKUP_FORMAT_VERSION}; ` +
        `received ${backup.formatVersion}`,
    })
    return { valid: false, issues }
  }

  const integrity = await verifyAthleteBackup(backup)
  if (!integrity.valid) {
    issues.push({
      code: 'integrity-failed',
      message:
        integrity.expectedHash === integrity.actualHash
          ? 'Backup store counts do not match payload'
          : 'Backup SHA-256 payload hash does not match',
    })
    return { valid: false, issues }
  }

  issues.push(...validateRelationships(backup))
  return { valid: issues.length === 0, issues }
}

export async function buildRestorePreview(
  backup: LetMeFlyBackup,
): Promise<RestorePreview> {
  const validation = await validateRestoreBackup(backup)
  const athlete = backup.payload.domain.athletes[0] as Row | undefined

  return {
    backup,
    validation,
    storeCounts: { ...backup.integrity.storeCounts },
    athleteName: String(athlete?.display_name ?? 'Athlete'),
    createdAt: backup.createdAt,
  }
}

export function validateRelationships(
  backup: LetMeFlyBackup,
): RestoreIssue[] {
  const d = backup.payload.domain as unknown as Record<string, Row[]>
  const issues: RestoreIssue[] = []
  const athleteRows = d.athletes ?? []

  if (athleteRows.length !== 1) {
    issues.push({
      code: 'athlete-count',
      store: 'athletes',
      message: `Expected exactly one athlete; found ${athleteRows.length}`,
    })
    return issues
  }

  if (String(athleteRows[0].id) !== backup.athleteId) {
    issues.push({
      code: 'athlete-id-mismatch',
      store: 'athletes',
      recordId: String(athleteRows[0].id),
      message: 'Envelope athleteId does not match root athlete record',
    })
  }

  for (const [store, rows] of Object.entries(d)) {
    const seen = new Set<string>()
    for (const row of rows) {
      const id = String(row.id ?? '')
      if (!id) {
        issues.push({
          code: 'missing-id',
          store,
          message: 'Record has no id',
        })
        continue
      }
      if (seen.has(id)) {
        issues.push({
          code: 'duplicate-id',
          store,
          recordId: id,
          message: 'Duplicate record id within store',
        })
      }
      seen.add(id)

      if (
        store !== 'athletes' &&
        String(row.athlete_id ?? '') !== backup.athleteId
      ) {
        issues.push({
          code: 'cross-athlete-record',
          store,
          recordId: id,
          message: 'Child athlete_id does not match backup athlete',
        })
      }
    }
  }

  const ids = (store: string) =>
    new Set((d[store] ?? []).map((row) => String(row.id)))

  const programIds = ids('programInstances')
  const readinessIds = ids('readinessEntries')
  const deviceIds = ids('devices')
  const sessionIds = ids('workoutSessions')
  const exerciseIds = ids('workoutExercises')
  const setIds = ids('workoutSets')
  const coachingIds = ids('coachingDecisions')
  const tmIds = ids('trainingMaxHistory')

  for (const row of d.trainingMaxHistory ?? []) {
    requireOptionalRef(
      issues,
      'trainingMaxHistory',
      row,
      'supersedes_id',
      tmIds,
    )
  }

  for (const row of d.programEvents ?? []) {
    requireRef(
      issues,
      'programEvents',
      row,
      'program_instance_id',
      programIds,
    )
  }

  for (const row of d.workoutSessions ?? []) {
    requireOptionalRef(
      issues,
      'workoutSessions',
      row,
      'program_instance_id',
      programIds,
    )
    requireOptionalRef(
      issues,
      'workoutSessions',
      row,
      'readiness_id',
      readinessIds,
    )
    requireOptionalRef(
      issues,
      'workoutSessions',
      row,
      'originating_device_id',
      deviceIds,
    )
  }

  for (const row of d.workoutExercises ?? []) {
    requireRef(
      issues,
      'workoutExercises',
      row,
      'workout_session_id',
      sessionIds,
    )
  }

  const setNumbers = new Set<string>()
  for (const row of d.workoutSets ?? []) {
    requireRef(
      issues,
      'workoutSets',
      row,
      'workout_session_id',
      sessionIds,
    )
    requireRef(
      issues,
      'workoutSets',
      row,
      'workout_exercise_id',
      exerciseIds,
    )

    const key = `${row.workout_exercise_id}:${row.set_number}`
    if (setNumbers.has(key)) {
      issues.push({
        code: 'duplicate-set-number',
        store: 'workoutSets',
        recordId: String(row.id),
        message:
          'Two workout sets use the same set_number for one exercise',
      })
    }
    setNumbers.add(key)
  }

  for (const row of d.personalRecords ?? []) {
    requireOptionalRef(
      issues,
      'personalRecords',
      row,
      'workout_session_id',
      sessionIds,
    )
    requireOptionalRef(
      issues,
      'personalRecords',
      row,
      'workout_set_id',
      setIds,
    )
  }

  for (const row of d.coachingDecisions ?? []) {
    requireOptionalRef(
      issues,
      'coachingDecisions',
      row,
      'program_instance_id',
      programIds,
    )
    requireOptionalRef(
      issues,
      'coachingDecisions',
      row,
      'workout_session_id',
      sessionIds,
    )
  }

  for (const row of d.exerciseSubstitutions ?? []) {
    requireOptionalRef(
      issues,
      'exerciseSubstitutions',
      row,
      'program_instance_id',
      programIds,
    )
    requireOptionalRef(
      issues,
      'exerciseSubstitutions',
      row,
      'workout_session_id',
      sessionIds,
    )
    requireOptionalRef(
      issues,
      'exerciseSubstitutions',
      row,
      'coaching_decision_id',
      coachingIds,
    )
  }

  for (const row of d.tmRecommendations ?? []) {
    requireOptionalRef(
      issues,
      'tmRecommendations',
      row,
      'resulting_tm_id',
      tmIds,
    )
  }

  return issues
}

function requireRef(
  issues: RestoreIssue[],
  store: string,
  row: Row,
  field: string,
  validIds: Set<string>,
): void {
  const value = row[field]
  if (!value || !validIds.has(String(value))) {
    issues.push({
      code: 'missing-parent',
      store,
      recordId: String(row.id),
      message: `${field} references a missing parent`,
    })
  }
}

function requireOptionalRef(
  issues: RestoreIssue[],
  store: string,
  row: Row,
  field: string,
  validIds: Set<string>,
): void {
  const value = row[field]
  if (value == null || value === '') return
  if (!validIds.has(String(value))) {
    issues.push({
      code: 'missing-parent',
      store,
      recordId: String(row.id),
      message: `${field} references a missing parent`,
    })
  }
}
