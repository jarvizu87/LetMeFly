import {
  DOMAIN_STORES,
  type DomainStoreName,
  type LocalDomainRecord,
  type SyncOutboxEntry,
  type SyncState,
  getAll,
  getOrCreateDeviceState,
  newId,
  openLetMeFlyDb,
  requestToPromise,
  transactionDone,
} from '../db/local-db'
import type { LetMeFlyBackup } from '../backup/backup-types'
import { requirePreDestructiveBackup } from '../backup/destructive-guard'
import {
  buildRestorePreview,
  validateRelationships,
  validateRestoreBackup,
} from './restore-validator'
import type {
  RestoreMode,
  RestorePreview,
  RestoreResult,
} from './restore-types'

const REPLACED_LOCAL_STORES = [
  ...DOMAIN_STORES,
  'syncState',
  'syncOutbox',
  'syncConflicts',
  'deviceState',
  'meta',
] as const

export async function previewRestoreText(
  text: string,
): Promise<RestorePreview> {
  const parsed = JSON.parse(text) as LetMeFlyBackup
  return buildRestorePreview(parsed)
}

export async function restoreFromBackup(
  backup: LetMeFlyBackup,
  mode: RestoreMode,
  appVersion: string | null = null,
): Promise<RestoreResult> {
  const initialValidation = await validateRestoreBackup(backup)
  if (!initialValidation.valid) {
    throw new Error(
      `Restore validation failed: ${initialValidation.issues
        .map((issue) => issue.code)
        .join(', ')}`,
    )
  }

  const currentAthleteId = await detectCurrentAthleteId()
  let preRestoreBackupCreated = false

  if (currentAthleteId) {
    const current = await requirePreDestructiveBackup(currentAthleteId, appVersion)
    await persistPreRestoreBackup(current.backup)
    preRestoreBackupCreated = true
  }

  const newDevice = await createFreshDeviceIdentity(appVersion)
  const staged =
    mode === 'portable-import'
      ? buildPortableImportPayload(backup, newDevice.deviceId)
      : buildFullRecoveryPayload(backup, newDevice)

  await replaceLocalDataAtomically(staged)

  const verificationBackup = buildVerificationEnvelope(
    backup,
    staged.domain,
  )
  const issues = validateRelationships(verificationBackup)

  const restoredCounts = await countRestoredRecords(backup.athleteId)
  for (const [store, expected] of Object.entries(
    countDomain(staged.domain),
  )) {
    const actual = restoredCounts[store] ?? 0
    if (actual < expected) {
      issues.push({
        code: 'post-restore-count',
        store,
        message: `Expected at least ${expected}; found ${actual}`,
      })
    }
  }

  return {
    mode,
    athleteId: backup.athleteId,
    restoredCounts,
    verification: {
      valid: issues.length === 0,
      issues,
    },
    newDeviceId: newDevice.deviceId,
    preRestoreBackupCreated,
  }
}

function buildFullRecoveryPayload(
  backup: LetMeFlyBackup,
  newDevice: {
    id: 'current'
    deviceId: string
    createdAt: string
    label?: string
    platform?: string
    appVersion?: string
  },
) {
  const domain = clone(backup.payload.domain)
  const recovery = clone(backup.payload.localRecovery)

  // Old device rows remain historical cloud/domain records.
  // Current physical installation receives a new local deviceState.
  recovery.deviceState = [newDevice]

  // Preserve existing operation IDs + deviceId fields exactly for idempotent retry.
  // Preserve sync cursor/base revisions from backup.
  for (const state of recovery.syncState) {
    if (state.athleteId === backup.athleteId) {
      state.deviceId = newDevice.deviceId
    }
  }

  return {
    domain,
    recovery,
    meta: {
      restoreMode: 'full-device-recovery',
      restoredAt: new Date().toISOString(),
      sourceBackupCreatedAt: backup.createdAt,
      sourceBackupHash: backup.integrity.payloadSha256,
    },
  }
}

function buildPortableImportPayload(
  backup: LetMeFlyBackup,
  newDeviceId: string,
) {
  const domain = clone(backup.payload.domain)
  // A portable import is independent of the previous cloud/device relationship.
  // Historical cloud device rows are not transplanted into a new account.
  domain.devices = []
  const now = new Date().toISOString()
  const syncOutbox: SyncOutboxEntry[] = []

  for (const storeName of DOMAIN_STORES) {
    const rows = (domain as any)[storeName] as LocalDomainRecord[]

    for (const row of rows) {
      const localVersion = Math.max(1, Number(row._local?.localVersion ?? 1))
      row.revision = 0
      row.updated_at = now
      row._local = {
        localVersion,
        baseRevision: 0,
        dirty: true,
        createdOffline: true,
        lastModifiedByDeviceId: newDeviceId,
      }

      syncOutbox.push({
        operationId: newId(),
        athleteId: backup.athleteId,
        entityType: storeName,
        entityId: row.id,
        operation: row.deleted_at ? 'delete' : 'upsert',
        baseRevision: 0,
        localVersion,
        payload: stripLocal(row),
        deviceId: newDeviceId,
        createdAt: now,
        updatedAt: now,
        attemptCount: 0,
        nextAttemptAt: now,
        status: 'pending',
        lastError: null,
      })
    }
  }

  const syncState: SyncState[] = [
    {
      athleteId: backup.athleteId,
      deviceId: newDeviceId,
      lastChangeSeq: 0,
      cloudSchemaVersion: backup.domainSchemaVersion,
      bootstrapStatus: 'unlinked',
    },
  ]

  return {
    domain,
    recovery: {
      syncState,
      syncOutbox,
      syncConflicts: [],
      deviceState: [
        {
          id: 'current' as const,
          deviceId: newDeviceId,
          createdAt: now,
          appVersion: null,
        },
      ],
    },
    meta: {
      restoreMode: 'portable-import',
      restoredAt: now,
      sourceBackupCreatedAt: backup.createdAt,
      sourceBackupHash: backup.integrity.payloadSha256,
    },
  }
}

async function replaceLocalDataAtomically(staged: {
  domain: any
  recovery: any
  meta: Record<string, unknown>
}): Promise<void> {
  const db = await openLetMeFlyDb()

  try {
    const tx = db.transaction([...REPLACED_LOCAL_STORES], 'readwrite')

    for (const storeName of REPLACED_LOCAL_STORES) {
      tx.objectStore(storeName).clear()
    }

    for (const storeName of DOMAIN_STORES) {
      const store = tx.objectStore(storeName)
      for (const row of staged.domain[storeName] ?? []) {
        store.put(row)
      }
    }

    for (const storeName of [
      'syncState',
      'syncOutbox',
      'syncConflicts',
      'deviceState',
    ] as const) {
      const store = tx.objectStore(storeName)
      for (const row of staged.recovery[storeName] ?? []) {
        store.put(row)
      }
    }

    tx.objectStore('meta').put({
      key: 'lastRestore',
      value: staged.meta,
      updatedAt: new Date().toISOString(),
    })

    await transactionDone(tx)
  } finally {
    db.close()
  }
}

async function persistPreRestoreBackup(backup: LetMeFlyBackup): Promise<void> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('internalBackups', 'readwrite')
    tx.objectStore('internalBackups').add({
      id: newId(),
      createdAt: new Date().toISOString(),
      reason: 'pre-restore',
      dbVersion: backup.dbVersion,
      domainSchemaVersion: backup.domainSchemaVersion,
      stores: { athleteBackup: [backup] },
    })
    await transactionDone(tx)
  } finally {
    db.close()
  }
}

async function detectCurrentAthleteId(): Promise<string | null> {
  const athletes = (
    await getAll<LocalDomainRecord>('athletes')
  ).filter((row) => !row.deleted_at)

  if (athletes.length === 0) return null
  if (athletes.length > 1) {
    throw new Error(
      'Current local database contains multiple active athletes; restore blocked',
    )
  }
  return athletes[0].id
}

async function createFreshDeviceIdentity(
  appVersion: string | null,
) {
  return {
    id: 'current' as const,
    deviceId: newId(),
    createdAt: new Date().toISOString(),
    platform:
      typeof navigator !== 'undefined'
        ? navigator.userAgent
        : 'unknown',
    appVersion: appVersion ?? undefined,
  }
}

async function countRestoredRecords(
  athleteId: string,
): Promise<Record<string, number>> {
  const counts: Record<string, number> = {}
  const db = await openLetMeFlyDb()

  try {
    const tx = db.transaction([...DOMAIN_STORES], 'readonly')
    for (const storeName of DOMAIN_STORES) {
      const rows = await requestToPromise<LocalDomainRecord[]>(
        tx.objectStore(storeName).getAll(),
      )
      counts[storeName] = rows.filter((row) =>
        storeName === 'athletes'
          ? row.id === athleteId
          : row.athlete_id === athleteId,
      ).length
    }
    await transactionDone(tx)
  } finally {
    db.close()
  }

  return counts
}

function countDomain(domain: any): Record<string, number> {
  const result: Record<string, number> = {}
  for (const storeName of DOMAIN_STORES) {
    result[storeName] = (domain[storeName] ?? []).length
  }
  return result
}

function buildVerificationEnvelope(
  original: LetMeFlyBackup,
  domain: any,
): LetMeFlyBackup {
  return {
    ...original,
    payload: {
      ...original.payload,
      domain,
    },
  }
}

function stripLocal(
  record: LocalDomainRecord,
): Record<string, unknown> {
  const { _local, ...cloud } = record
  return cloud
}

function clone<T>(value: T): T {
  return structuredClone(value)
}
