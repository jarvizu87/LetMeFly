import type { LetMeFlyBackup } from '../backup/backup-types'

export type RestoreMode = 'full-device-recovery' | 'portable-import'

export interface RestoreIssue {
  code: string
  store?: string
  recordId?: string
  message: string
}

export interface RestoreValidation {
  valid: boolean
  issues: RestoreIssue[]
}

export interface RestorePreview {
  backup: LetMeFlyBackup
  validation: RestoreValidation
  storeCounts: Record<string, number>
  athleteName: string
  createdAt: string
}

export interface RestoreResult {
  mode: RestoreMode
  athleteId: string
  restoredCounts: Record<string, number>
  verification: RestoreValidation
  newDeviceId: string
  preRestoreBackupCreated: boolean
}
