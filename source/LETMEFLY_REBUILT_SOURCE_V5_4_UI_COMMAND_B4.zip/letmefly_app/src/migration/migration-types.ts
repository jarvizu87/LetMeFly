import type { DomainStoreName, LocalDomainRecord } from '../db/local-db'

export interface LegacyKeySnapshot {
  key: string
  rawValue: string
  parsed: unknown
  parseError: string | null
  confidence: number
}

export interface LegacySnapshot {
  capturedAt: string
  origin: string
  fingerprint: string
  candidates: LegacyKeySnapshot[]
}

export interface UnmappedValue {
  sourceKey: string
  path: string
  valueType: string
  preview: string
}

export interface CanonicalCandidate {
  store: DomainStoreName
  id: string
  sourceKey: string
  sourcePath: string
  record: Record<string, unknown>
  confidence: number
  warnings: string[]
}

export interface MigrationPlan {
  planVersion: 1
  snapshotFingerprint: string
  athleteId: string
  generatedAt: string
  candidates: CanonicalCandidate[]
  unmappedPaths: UnmappedValue[]
  warnings: string[]
}

export interface MigrationVerification {
  fingerprint: string
  athleteId: string
  importedCounts: Record<string, number>
  actualCounts: Record<string, number>
  verified: boolean
  warnings: string[]
}

export interface ImportedRecord extends LocalDomainRecord {
  athlete_id?: string
}
