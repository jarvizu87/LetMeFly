import type {
  LegacySnapshot,
  MigrationPlan,
  MigrationVerification,
} from './migration-types'

export function migrationReportText(
  snapshot: LegacySnapshot,
  plan: MigrationPlan,
  verification?: MigrationVerification,
): string {
  const lines: string[] = []

  lines.push('LETMEFLY LEGACY MIGRATION REPORT')
  lines.push(`Fingerprint: ${snapshot.fingerprint}`)
  lines.push(`Captured: ${snapshot.capturedAt}`)
  lines.push(`Candidate storage keys: ${snapshot.candidates.length}`)
  lines.push(`Canonical candidates: ${plan.candidates.length}`)
  lines.push(`Unmapped paths retained: ${plan.unmappedPaths.length}`)
  lines.push(`Warnings: ${plan.warnings.length}`)
  lines.push('')

  lines.push('CANONICAL RECORDS')
  const counts = new Map<string, number>()
  for (const candidate of plan.candidates) {
    counts.set(candidate.store, (counts.get(candidate.store) ?? 0) + 1)
  }
  for (const [store, count] of [...counts.entries()].sort()) {
    lines.push(`- ${store}: ${count}`)
  }

  if (plan.warnings.length) {
    lines.push('')
    lines.push('WARNINGS')
    for (const warning of plan.warnings) {
      lines.push(`- ${warning}`)
    }
  }

  if (plan.unmappedPaths.length) {
    lines.push('')
    lines.push('UNMAPPED / PRESERVED')
    for (const item of plan.unmappedPaths.slice(0, 100)) {
      lines.push(
        `- ${item.sourceKey} ${item.path} [${item.valueType}] ${item.preview}`,
      )
    }
    if (plan.unmappedPaths.length > 100) {
      lines.push(`- ... ${plan.unmappedPaths.length - 100} additional paths`)
    }
  }

  if (verification) {
    lines.push('')
    lines.push('VERIFICATION')
    lines.push(`Verified: ${verification.verified ? 'YES' : 'NO'}`)
    for (const [store, count] of Object.entries(verification.actualCounts)) {
      lines.push(`- ${store}: ${count}`)
    }
  }

  return lines.join('\n')
}

export function downloadRawLegacyBackup(snapshot: LegacySnapshot): void {
  const blob = new Blob(
    [
      JSON.stringify(
        {
          format: 'letmefly-legacy-localstorage-backup',
          formatVersion: 1,
          ...snapshot,
        },
        null,
        2,
      ),
    ],
    { type: 'application/json' },
  )

  const url = URL.createObjectURL(blob)
  try {
    const anchor = document.createElement('a')
    anchor.href = url
    anchor.download = `letmefly-legacy-backup-${snapshot.fingerprint.slice(0, 12)}.json`
    anchor.click()
  } finally {
    setTimeout(() => URL.revokeObjectURL(url), 0)
  }
}
