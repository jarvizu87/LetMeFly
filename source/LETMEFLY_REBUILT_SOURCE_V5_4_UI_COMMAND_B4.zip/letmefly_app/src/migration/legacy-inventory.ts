import type {
  LegacyKeySnapshot,
  LegacySnapshot,
} from './migration-types'

const KEY_HINTS: Array<[RegExp, number]> = [
  [/^letMeFlyPrivateState$/i, 100],
  [/letmefly/i, 80],
  [/let-me-fly/i, 75],
  [/\blmf\b/i, 65],
  [/crownforge/i, 50],
  [/blackcrown/i, 50],
]

function confidenceForKey(key: string): number {
  let score = 0
  for (const [pattern, value] of KEY_HINTS) {
    if (pattern.test(key)) score = Math.max(score, value)
  }
  return score
}

function parseValue(rawValue: string): {
  parsed: unknown
  parseError: string | null
} {
  try {
    return { parsed: JSON.parse(rawValue), parseError: null }
  } catch (error) {
    return {
      parsed: rawValue,
      parseError: error instanceof Error ? error.message : String(error),
    }
  }
}

export async function inventoryLegacyLocalStorage(
  storage: Storage = localStorage,
): Promise<LegacySnapshot> {
  const candidates: LegacyKeySnapshot[] = []

  for (let i = 0; i < storage.length; i += 1) {
    const key = storage.key(i)
    if (!key) continue

    const confidence = confidenceForKey(key)
    if (confidence === 0) continue

    const rawValue = storage.getItem(key)
    if (rawValue == null) continue

    const { parsed, parseError } = parseValue(rawValue)
    candidates.push({
      key,
      rawValue,
      parsed,
      parseError,
      confidence,
    })
  }

  candidates.sort((a, b) => b.confidence - a.confidence || a.key.localeCompare(b.key))

  const fingerprint = await sha256Hex(
    JSON.stringify(
      candidates.map((item) => ({
        key: item.key,
        rawValue: item.rawValue,
      })),
    ),
  )

  return {
    capturedAt: new Date().toISOString(),
    origin: location.origin,
    fingerprint,
    candidates,
  }
}

export async function sha256Hex(input: string): Promise<string> {
  const encoded = new TextEncoder().encode(input)
  const digest = await crypto.subtle.digest('SHA-256', encoded)
  return [...new Uint8Array(digest)]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('')
}

export async function stableUuid(
  namespace: string,
  value: string,
): Promise<string> {
  const hex = await sha256Hex(`${namespace}|${value}`)
  const bytes = new Uint8Array(16)

  for (let i = 0; i < 16; i += 1) {
    bytes[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16)
  }

  // Mark as UUID version 5-style deterministic identifier + RFC variant.
  bytes[6] = (bytes[6] & 0x0f) | 0x50
  bytes[8] = (bytes[8] & 0x3f) | 0x80

  const h = [...bytes]
    .map((value) => value.toString(16).padStart(2, '0'))
    .join('')

  return [
    h.slice(0, 8),
    h.slice(8, 12),
    h.slice(12, 16),
    h.slice(16, 20),
    h.slice(20),
  ].join('-')
}
