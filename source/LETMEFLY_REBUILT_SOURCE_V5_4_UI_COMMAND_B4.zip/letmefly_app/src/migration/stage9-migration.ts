import {
  inventoryLegacyLocalStorage,
} from './legacy-inventory'
import {
  buildMigrationPlan,
} from './migration-planner'
import {
  executeMigrationPlan,
  hasCompletedMigrationFingerprint,
  preserveLegacySnapshot,
  verifyMigration,
} from './migration-executor'
import type {
  LegacySnapshot,
  MigrationPlan,
  MigrationVerification,
} from './migration-types'

export interface Stage9DiscoveryResult {
  snapshot: LegacySnapshot
  plan: MigrationPlan
  alreadyMigrated: boolean
}

export async function discoverLegacyMigration(
  storage: Storage = localStorage,
): Promise<Stage9DiscoveryResult> {
  const snapshot = await inventoryLegacyLocalStorage(storage)
  const plan = await buildMigrationPlan(snapshot)
  const alreadyMigrated =
    await hasCompletedMigrationFingerprint(snapshot.fingerprint)

  return {
    snapshot,
    plan,
    alreadyMigrated,
  }
}

export async function runSafeLegacyMigration(
  discovery: Stage9DiscoveryResult,
): Promise<MigrationVerification> {
  if (discovery.snapshot.candidates.length === 0) {
    throw new Error('No LetMeFly legacy localStorage candidates were found')
  }

  if (discovery.alreadyMigrated) {
    return verifyMigration(discovery.plan)
  }

  // Critical ordering: raw legacy snapshot must be preserved first.
  await preserveLegacySnapshot(discovery.snapshot, discovery.plan)

  // Canonical writes happen only after backup succeeds.
  const verification = await executeMigrationPlan(discovery.plan)

  if (!verification.verified) {
    throw new Error(
      'Legacy migration did not verify. Legacy localStorage was left untouched.',
    )
  }

  return verification
}

// There is intentionally NO function here that deletes legacy localStorage.
// Cleanup is a later explicit operation after reload/cloud/export verification.
