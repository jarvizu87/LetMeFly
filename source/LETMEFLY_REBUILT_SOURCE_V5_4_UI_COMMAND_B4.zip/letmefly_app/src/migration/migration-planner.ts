import type {
  CanonicalCandidate,
  LegacySnapshot,
  MigrationPlan,
  UnmappedValue,
} from './migration-types'
import { stableUuid } from './legacy-inventory'

type JsonObject = Record<string, unknown>

const PROFILE_ALIASES = [
  'profile',
  'athlete',
  'athleteProfile',
  'userProfile',
  'jpProfile',
]
const NAME_ALIASES = ['name', 'displayName', 'display_name', 'athleteName']
const DOB_ALIASES = ['birthDate', 'birth_date', 'dateOfBirth', 'dob']
const AGE_ALIASES = ['age']
const HEIGHT_ALIASES = ['height', 'heightInches', 'heightCm']
const WEIGHT_ALIASES = ['weight', 'bodyweight', 'bodyWeight', 'currentWeight']

const GOAL_ALIASES = ['goals', 'strengthGoals', 'trainingGoals']
const EQUIPMENT_ALIASES = ['equipment', 'availableEquipment', 'gymEquipment']
const PREFERENCE_ALIASES = ['preferences', 'settings', 'appSettings']
const TM_ALIASES = [
  'trainingMaxes',
  'training_maxes',
  'tms',
  'TMs',
  'trainingMax',
]
const PROGRAM_ALIASES = [
  'currentProgram',
  'program',
  'activeProgram',
  'programState',
  'programProgress',
]
const WORKOUT_ALIASES = [
  'workoutHistory',
  'workouts',
  'completedWorkouts',
  'sessions',
  'workoutSessions',
]
const READINESS_ALIASES = ['readiness', 'readinessHistory', 'readinessEntries']
const PR_ALIASES = ['prs', 'PRs', 'personalRecords', 'records']
const SUB_ALIASES = ['substitutions', 'exerciseSubstitutions']
const COACH_ALIASES = [
  'coachNotes',
  'coachingDecisions',
  'modifications',
  'programModifications',
]
const TM_REC_ALIASES = ['tmRecommendations', 'trainingMaxRecommendations']

function isObject(value: unknown): value is JsonObject {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value)
}

function firstAlias(
  object: JsonObject,
  aliases: string[],
): { key: string; value: unknown } | null {
  for (const alias of aliases) {
    if (Object.prototype.hasOwnProperty.call(object, alias)) {
      return { key: alias, value: object[alias] }
    }
  }
  return null
}

function stringValue(value: unknown): string | null {
  if (typeof value === 'string' && value.trim()) return value.trim()
  return null
}

function numberValue(value: unknown): number | null {
  if (typeof value === 'number' && Number.isFinite(value)) return value
  if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) {
    return Number(value)
  }
  return null
}

function asArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value
  if (value == null) return []
  return [value]
}

function preview(value: unknown): string {
  try {
    const text = JSON.stringify(value)
    return text.length > 180 ? `${text.slice(0, 177)}...` : text
  } catch {
    return String(value).slice(0, 180)
  }
}

function collectPaths(
  sourceKey: string,
  value: unknown,
  path = '$',
  into: UnmappedValue[] = [],
): UnmappedValue[] {
  if (Array.isArray(value)) {
    value.forEach((item, index) =>
      collectPaths(sourceKey, item, `${path}[${index}]`, into),
    )
    if (value.length === 0) {
      into.push({
        sourceKey,
        path,
        valueType: 'array',
        preview: '[]',
      })
    }
    return into
  }

  if (isObject(value)) {
    const entries = Object.entries(value)
    if (entries.length === 0) {
      into.push({
        sourceKey,
        path,
        valueType: 'object',
        preview: '{}',
      })
    } else {
      for (const [key, child] of entries) {
        collectPaths(sourceKey, child, `${path}.${key}`, into)
      }
    }
    return into
  }

  into.push({
    sourceKey,
    path,
    valueType: value === null ? 'null' : typeof value,
    preview: preview(value),
  })
  return into
}

function pathUnder(rootPath: string, path: string): boolean {
  return path === rootPath || path.startsWith(`${rootPath}.`) || path.startsWith(`${rootPath}[`)
}

function removeMapped(
  all: UnmappedValue[],
  mappedRoots: string[],
): UnmappedValue[] {
  return all.filter(
    (entry) => !mappedRoots.some((root) => pathUnder(root, entry.path)),
  )
}

function inferHeight(
  value: unknown,
): { height_value: number; height_unit: 'in' | 'cm' } | null {
  const numeric = numberValue(value)
  if (numeric == null || numeric <= 0) return null

  // Conservative unit inference:
  // human adult height < 100 is almost certainly inches, >= 100 likely cm.
  if (numeric < 100) return { height_value: numeric, height_unit: 'in' }
  if (numeric <= 260) return { height_value: numeric, height_unit: 'cm' }
  return null
}

function normalizeWeight(
  value: unknown,
): { value: number; unit: 'lb' | 'kg' } | null {
  if (isObject(value)) {
    const amount =
      numberValue(value.value) ??
      numberValue(value.weight) ??
      numberValue(value.amount)
    const unitRaw = stringValue(value.unit)?.toLowerCase()
    if (amount && (unitRaw === 'lb' || unitRaw === 'kg')) {
      return { value: amount, unit: unitRaw }
    }
  }

  const amount = numberValue(value)
  if (amount == null || amount <= 0) return null

  // Default is NOT guessed here; caller may add warning and leave unmapped.
  return null
}

function normalizeTmValue(
  value: unknown,
): { value: number; unit: 'lb' | 'kg' | null } | null {
  if (isObject(value)) {
    const amount =
      numberValue(value.value) ??
      numberValue(value.tm) ??
      numberValue(value.trainingMax) ??
      numberValue(value.max)
    if (amount == null || amount <= 0) return null

    const unitRaw = stringValue(value.unit)?.toLowerCase()
    const unit =
      unitRaw === 'lb' || unitRaw === 'kg'
        ? unitRaw
        : null

    return { value: amount, unit }
  }

  const amount = numberValue(value)
  return amount && amount > 0 ? { value: amount, unit: null } : null
}

export async function buildMigrationPlan(
  snapshot: LegacySnapshot,
): Promise<MigrationPlan> {
  const warnings: string[] = []
  const candidates: CanonicalCandidate[] = []
  let unmappedPaths: UnmappedValue[] = []

  for (const candidate of snapshot.candidates) {
    unmappedPaths.push(...collectPaths(candidate.key, candidate.parsed))
  }

  const primary = snapshot.candidates[0]
  if (!primary || !isObject(primary.parsed)) {
    const athleteId = await stableUuid(
      'letmefly-athlete',
      snapshot.fingerprint,
    )
    warnings.push('No structured LetMeFly state object could be identified.')
    return {
      planVersion: 1,
      snapshotFingerprint: snapshot.fingerprint,
      athleteId,
      generatedAt: new Date().toISOString(),
      candidates,
      unmappedPaths,
      warnings,
    }
  }

  const root = primary.parsed
  const profileHit = firstAlias(root, PROFILE_ALIASES)
  const profile = profileHit && isObject(profileHit.value)
    ? profileHit.value
    : root

  const sourceAthleteId =
    stringValue(profile.id) ??
    stringValue(profile.athleteId) ??
    stringValue(profile.athlete_id)

  const athleteId =
    sourceAthleteId && /^[0-9a-f-]{36}$/i.test(sourceAthleteId)
      ? sourceAthleteId
      : await stableUuid('letmefly-athlete', snapshot.fingerprint)

  const athleteRecord: Record<string, unknown> = {
    id: athleteId,
  }
  const athleteWarnings: string[] = []
  const mappedRoots: string[] = []

  const profileBasePath = profileHit ? `$.${profileHit.key}` : '$'

  const nameHit = firstAlias(profile, NAME_ALIASES)
  if (nameHit) {
    const name = stringValue(nameHit.value)
    if (name) {
      athleteRecord.display_name = name
      mappedRoots.push(`${profileBasePath}.${nameHit.key}`)
    }
  }

  const dobHit = firstAlias(profile, DOB_ALIASES)
  if (dobHit) {
    const dob = stringValue(dobHit.value)
    if (dob && /^\d{4}-\d{2}-\d{2}/.test(dob)) {
      athleteRecord.birth_date = dob.slice(0, 10)
      mappedRoots.push(`${profileBasePath}.${dobHit.key}`)
    }
  }

  const ageHit = firstAlias(profile, AGE_ALIASES)
  if (ageHit) {
    athleteWarnings.push(
      'Legacy age was preserved in raw migration data; no birth date was fabricated from age.',
    )
  }

  const heightHit = firstAlias(profile, HEIGHT_ALIASES)
  if (heightHit) {
    const h = inferHeight(heightHit.value)
    if (h) {
      athleteRecord.height_value = h.height_value
      athleteRecord.height_unit = h.height_unit
      mappedRoots.push(`${profileBasePath}.${heightHit.key}`)
    }
  }

  if (!athleteRecord.display_name) {
    athleteRecord.display_name = 'Athlete'
    athleteWarnings.push(
      'No reliable legacy athlete name found; temporary display name must be reviewed.',
    )
  }

  candidates.push({
    store: 'athletes',
    id: athleteId,
    sourceKey: primary.key,
    sourcePath: profileBasePath,
    record: athleteRecord,
    confidence: primary.confidence,
    warnings: athleteWarnings,
  })

  const weightHit = firstAlias(profile, WEIGHT_ALIASES)
  if (weightHit) {
    const normalized = normalizeWeight(weightHit.value)
    if (normalized) {
      const id = await stableUuid(
        'letmefly-bodyweight',
        `${snapshot.fingerprint}|${profileBasePath}.${weightHit.key}`,
      )
      candidates.push({
        store: 'bodyweightEntries',
        id,
        sourceKey: primary.key,
        sourcePath: `${profileBasePath}.${weightHit.key}`,
        record: {
          id,
          athlete_id: athleteId,
          measured_at: snapshot.capturedAt,
          value: normalized.value,
          unit: normalized.unit,
          source: 'legacy_profile_import',
          notes: 'Imported from legacy LetMeFly profile value.',
        },
        confidence: 90,
        warnings: [],
      })
      mappedRoots.push(`${profileBasePath}.${weightHit.key}`)
    } else if (numberValue(weightHit.value) != null) {
      warnings.push(
        `Legacy profile weight at ${profileBasePath}.${weightHit.key} has no explicit unit; it was preserved but not guessed.`,
      )
    }
  }

  const preferenceHit = firstAlias(root, PREFERENCE_ALIASES)
  if (preferenceHit && isObject(preferenceHit.value)) {
    const id = await stableUuid(
      'letmefly-preferences',
      `${snapshot.fingerprint}|$.${preferenceHit.key}`,
    )
    candidates.push({
      store: 'athletePreferences',
      id,
      sourceKey: primary.key,
      sourcePath: `$.${preferenceHit.key}`,
      record: {
        id,
        athlete_id: athleteId,
        preferences: preferenceHit.value,
      },
      confidence: 80,
      warnings: [
        'Legacy settings are retained inside preferences JSON until field-by-field UI mapping is verified.',
      ],
    })
    mappedRoots.push(`$.${preferenceHit.key}`)
  }

  const goalHit = firstAlias(root, GOAL_ALIASES)
  if (goalHit) {
    const goals = asArray(goalHit.value)
    for (let index = 0; index < goals.length; index += 1) {
      const raw = goals[index]
      const id = await stableUuid(
        'letmefly-goal',
        `${snapshot.fingerprint}|$.${goalHit.key}[${index}]`,
      )
      if (typeof raw === 'string' && raw.trim()) {
        candidates.push({
          store: 'athleteGoals',
          id,
          sourceKey: primary.key,
          sourcePath: `$.${goalHit.key}[${index}]`,
          record: {
            id,
            athlete_id: athleteId,
            goal_type: 'legacy',
            name: raw.trim(),
            status: 'active',
          },
          confidence: 75,
          warnings: [],
        })
      } else if (isObject(raw)) {
        const name =
          stringValue(raw.name) ??
          stringValue(raw.goal) ??
          stringValue(raw.title)
        if (name) {
          candidates.push({
            store: 'athleteGoals',
            id,
            sourceKey: primary.key,
            sourcePath: `$.${goalHit.key}[${index}]`,
            record: {
              id,
              athlete_id: athleteId,
              goal_type: stringValue(raw.type) ?? 'legacy',
              name,
              priority: numberValue(raw.priority),
              target_value: numberValue(raw.targetValue ?? raw.target),
              target_unit: stringValue(raw.targetUnit ?? raw.unit),
              target_date: stringValue(raw.targetDate),
              status: stringValue(raw.status) ?? 'active',
              notes: stringValue(raw.notes),
            },
            confidence: 75,
            warnings: [],
          })
        }
      }
    }
    if (candidates.some((item) => item.sourcePath.startsWith(`$.${goalHit.key}`))) {
      mappedRoots.push(`$.${goalHit.key}`)
    }
  }

  const equipmentHit = firstAlias(root, EQUIPMENT_ALIASES)
  if (equipmentHit) {
    const items = asArray(equipmentHit.value)
    for (let index = 0; index < items.length; index += 1) {
      const raw = items[index]
      const id = await stableUuid(
        'letmefly-equipment',
        `${snapshot.fingerprint}|$.${equipmentHit.key}[${index}]`,
      )
      if (typeof raw === 'string' && raw.trim()) {
        const label = raw.trim()
        candidates.push({
          store: 'athleteEquipment',
          id,
          sourceKey: primary.key,
          sourcePath: `$.${equipmentHit.key}[${index}]`,
          record: {
            id,
            athlete_id: athleteId,
            equipment_key: slug(label),
            display_name: label,
            equipment_type: 'legacy',
            quantity: 1,
            available: true,
            properties: {},
          },
          confidence: 70,
          warnings: [],
        })
      } else if (isObject(raw)) {
        const label =
          stringValue(raw.displayName) ??
          stringValue(raw.name) ??
          stringValue(raw.label)
        if (label) {
          candidates.push({
            store: 'athleteEquipment',
            id,
            sourceKey: primary.key,
            sourcePath: `$.${equipmentHit.key}[${index}]`,
            record: {
              id,
              athlete_id: athleteId,
              equipment_key:
                stringValue(raw.key) ??
                stringValue(raw.equipmentKey) ??
                slug(label),
              display_name: label,
              equipment_type: stringValue(raw.type) ?? 'legacy',
              quantity: numberValue(raw.quantity) ?? 1,
              available:
                typeof raw.available === 'boolean' ? raw.available : true,
              properties: raw,
            },
            confidence: 70,
            warnings: [],
          })
        }
      }
    }
    if (candidates.some((item) => item.sourcePath.startsWith(`$.${equipmentHit.key}`))) {
      mappedRoots.push(`$.${equipmentHit.key}`)
    }
  }

  const tmHit = firstAlias(root, TM_ALIASES)
  if (tmHit && isObject(tmHit.value)) {
    for (const [exercise, raw] of Object.entries(tmHit.value)) {
      const normalized = normalizeTmValue(raw)
      if (!normalized) continue

      if (!normalized.unit) {
        warnings.push(
          `TM ${exercise} has no explicit unit; preserved but not imported until unit is confirmed.`,
        )
        continue
      }

      const id = await stableUuid(
        'letmefly-tm',
        `${snapshot.fingerprint}|$.${tmHit.key}.${exercise}`,
      )
      candidates.push({
        store: 'trainingMaxHistory',
        id,
        sourceKey: primary.key,
        sourcePath: `$.${tmHit.key}.${exercise}`,
        record: {
          id,
          athlete_id: athleteId,
          exercise_key: slug(exercise),
          tm_value: normalized.value,
          tm_unit: normalized.unit,
          effective_at: snapshot.capturedAt,
          source: 'legacy_import',
          notes: `Imported legacy TM label: ${exercise}`,
        },
        confidence: 85,
        warnings: [
          'Effective date uses migration capture time because no explicit legacy effective date was identified.',
        ],
      })
    }
    if (candidates.some((item) => item.sourcePath.startsWith(`$.${tmHit.key}.`))) {
      mappedRoots.push(`$.${tmHit.key}`)
    }
  }

  const programHit = firstAlias(root, PROGRAM_ALIASES)
  if (programHit && isObject(programHit.value)) {
    const raw = programHit.value
    const programName =
      stringValue(raw.programName) ??
      stringValue(raw.name) ??
      stringValue(raw.program) ??
      stringValue(raw.key)

    if (programName) {
      const id = await stableUuid(
        'letmefly-program-instance',
        `${snapshot.fingerprint}|$.${programHit.key}`,
      )
      candidates.push({
        store: 'programInstances',
        id,
        sourceKey: primary.key,
        sourcePath: `$.${programHit.key}`,
        record: {
          id,
          athlete_id: athleteId,
          program_key:
            stringValue(raw.programKey) ??
            stringValue(raw.key) ??
            slug(programName),
          program_name: programName,
          program_version:
            stringValue(raw.programVersion) ??
            stringValue(raw.version) ??
            'legacy-unversioned',
          program_snapshot: {},
          status: stringValue(raw.status) ?? 'active',
          current_phase_key:
            stringValue(raw.phaseKey) ??
            stringValue(raw.phase) ??
            null,
          current_week:
            numberValue(raw.week ?? raw.currentWeek) ?? null,
          current_day_key:
            stringValue(raw.dayKey) ??
            stringValue(raw.day ?? raw.currentDay) ??
            null,
          progression_state: raw,
        },
        confidence: 85,
        warnings: [
          'Full legacy program-state object retained in progression_state for review.',
        ],
      })
      mappedRoots.push(`$.${programHit.key}`)
    }
  }

  // More complex historical collections are only imported when their structure
  // is clearly object/array-shaped; field-level workout mapping stays conservative.
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    WORKOUT_ALIASES,
    'workoutSessions',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_workout',
  )
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    READINESS_ALIASES,
    'readinessEntries',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_readiness',
  )
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    PR_ALIASES,
    'personalRecords',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_pr',
  )
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    SUB_ALIASES,
    'exerciseSubstitutions',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_substitution',
  )
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    COACH_ALIASES,
    'coachingDecisions',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_coaching',
  )
  await mapOpaqueHistoricalCollection(
    snapshot,
    primary.key,
    root,
    TM_REC_ALIASES,
    'tmRecommendations',
    athleteId,
    candidates,
    mappedRoots,
    'legacy_tm_recommendation',
  )

  unmappedPaths = removeMapped(unmappedPaths, mappedRoots)

  return {
    planVersion: 1,
    snapshotFingerprint: snapshot.fingerprint,
    athleteId,
    generatedAt: new Date().toISOString(),
    candidates,
    unmappedPaths,
    warnings,
  }
}

async function mapOpaqueHistoricalCollection(
  snapshot: LegacySnapshot,
  sourceKey: string,
  root: JsonObject,
  aliases: string[],
  store:
    | 'workoutSessions'
    | 'readinessEntries'
    | 'personalRecords'
    | 'exerciseSubstitutions'
    | 'coachingDecisions'
    | 'tmRecommendations',
  athleteId: string,
  candidates: CanonicalCandidate[],
  mappedRoots: string[],
  marker: string,
): Promise<void> {
  const hit = firstAlias(root, aliases)
  if (!hit) return

  const items = asArray(hit.value)
  let mapped = 0

  for (let index = 0; index < items.length; index += 1) {
    const raw = items[index]
    if (!isObject(raw)) continue

    const transformed = conservativeHistoricalTransform(
      store,
      raw,
      athleteId,
      snapshot.capturedAt,
    )
    if (!transformed) continue

    const id =
      stringValue(raw.id) && /^[0-9a-f-]{36}$/i.test(stringValue(raw.id)!)
        ? stringValue(raw.id)!
        : await stableUuid(
            marker,
            `${snapshot.fingerprint}|$.${hit.key}[${index}]`,
          )

    candidates.push({
      store,
      id,
      sourceKey,
      sourcePath: `$.${hit.key}[${index}]`,
      record: {
        id,
        athlete_id: athleteId,
        ...transformed,
      },
      confidence: 60,
      warnings: [
        'Historical record was conservatively normalized; raw source remains preserved in migration backup.',
      ],
    })
    mapped += 1
  }

  if (mapped > 0) mappedRoots.push(`$.${hit.key}`)
}

function conservativeHistoricalTransform(
  store:
    | 'workoutSessions'
    | 'readinessEntries'
    | 'personalRecords'
    | 'exerciseSubstitutions'
    | 'coachingDecisions'
    | 'tmRecommendations',
  raw: JsonObject,
  athleteId: string,
  fallbackTime: string,
): Record<string, unknown> | null {
  switch (store) {
    case 'workoutSessions': {
      const workoutName =
        stringValue(raw.workoutName) ??
        stringValue(raw.name) ??
        stringValue(raw.title)
      const status =
        stringValue(raw.status) ??
        (raw.completed === true ? 'completed' : null)

      if (!workoutName && !status && !raw.date && !raw.startedAt) return null

      return {
        workout_name: workoutName,
        program_key: stringValue(raw.programKey ?? raw.program),
        program_version: stringValue(raw.programVersion),
        phase_key: stringValue(raw.phaseKey ?? raw.phase),
        week_number: numberValue(raw.week ?? raw.weekNumber),
        day_key: stringValue(raw.dayKey ?? raw.day),
        scheduled_for: stringValue(raw.scheduledFor ?? raw.date)?.slice(0, 10) ?? null,
        started_at: stringValue(raw.startedAt ?? raw.started_at),
        completed_at: stringValue(raw.completedAt ?? raw.completed_at),
        status: status ?? 'completed',
        notes: stringValue(raw.notes),
      }
    }

    case 'readinessEntries': {
      const recorded =
        stringValue(raw.recordedAt ?? raw.date ?? raw.timestamp) ??
        fallbackTime
      const anyScore =
        numberValue(raw.sleepQuality ?? raw.sleep_quality) ??
        numberValue(raw.soreness) ??
        numberValue(raw.stress) ??
        numberValue(raw.energy)
      if (anyScore == null && raw.sleepHours == null && raw.notes == null) return null

      return {
        recorded_at: recorded,
        sleep_hours: numberValue(raw.sleepHours ?? raw.sleep_hours),
        sleep_quality: numberValue(raw.sleepQuality ?? raw.sleep_quality),
        soreness: numberValue(raw.soreness),
        stress: numberValue(raw.stress),
        energy: numberValue(raw.energy),
        notes: stringValue(raw.notes),
      }
    }

    case 'personalRecords': {
      const prType =
        stringValue(raw.prType ?? raw.type) ??
        'legacy'
      const performance =
        isObject(raw.performance) ? raw.performance : raw
      return {
        pr_type: prType,
        exercise_key:
          stringValue(raw.exerciseKey) ??
          (stringValue(raw.exercise) ? slug(stringValue(raw.exercise)!) : null),
        performance,
        achieved_at:
          stringValue(raw.achievedAt ?? raw.date ?? raw.timestamp) ??
          fallbackTime,
        detected_by: 'legacy_import',
        notes: stringValue(raw.notes),
      }
    }

    case 'exerciseSubstitutions': {
      const original =
        stringValue(raw.originalExerciseKey) ??
        stringValue(raw.original) ??
        stringValue(raw.from)
      const replacement =
        stringValue(raw.substituteExerciseKey) ??
        stringValue(raw.substitute) ??
        stringValue(raw.to)
      if (!original || !replacement) return null
      return {
        original_exercise_key: slug(original),
        substitute_exercise_key: slug(replacement),
        reason: stringValue(raw.reason),
        context: raw,
        effective_at:
          stringValue(raw.effectiveAt ?? raw.date) ?? fallbackTime,
      }
    }

    case 'coachingDecisions': {
      const rationale =
        stringValue(raw.rationale) ??
        stringValue(raw.reason) ??
        stringValue(raw.notes)
      if (!rationale) return null
      return {
        decision_type:
          stringValue(raw.decisionType ?? raw.type) ?? 'legacy_modification',
        before_state: isObject(raw.beforeState) ? raw.beforeState : null,
        after_state: isObject(raw.afterState) ? raw.afterState : raw,
        rationale,
        source: stringValue(raw.source) ?? 'legacy_import',
        status: stringValue(raw.status) ?? 'active',
        effective_from:
          stringValue(raw.effectiveFrom ?? raw.date) ?? fallbackTime,
      }
    }

    case 'tmRecommendations': {
      const exercise =
        stringValue(raw.exerciseKey) ??
        stringValue(raw.exercise)
      const recommended =
        numberValue(raw.recommendedTm ?? raw.recommendedTM ?? raw.recommended)
      const unit = stringValue(raw.unit)?.toLowerCase()
      const rationale =
        stringValue(raw.rationale) ??
        stringValue(raw.reason)
      if (!exercise || !recommended || !rationale) return null
      if (unit !== 'lb' && unit !== 'kg') return null
      return {
        exercise_key: slug(exercise),
        current_tm_value: numberValue(raw.currentTm ?? raw.currentTM),
        recommended_tm_value: recommended,
        unit,
        rationale,
        source: stringValue(raw.source) ?? 'legacy_import',
        status: stringValue(raw.status) ?? 'pending',
        generated_at:
          stringValue(raw.generatedAt ?? raw.date) ?? fallbackTime,
      }
    }
  }
}

function slug(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
}
