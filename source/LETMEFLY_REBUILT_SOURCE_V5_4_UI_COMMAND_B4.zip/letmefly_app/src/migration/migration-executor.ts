import {
  DOMAIN_STORES,
  type DomainStoreName,
  type InternalBackup,
  type LocalDomainRecord,
  type SyncOutboxEntry,
  getOrCreateDeviceState,
  newId,
  openLetMeFlyDb,
  requestToPromise,
  transactionDone,
} from '../db/local-db'
import type {
  LegacySnapshot,
  MigrationPlan,
  MigrationVerification,
} from './migration-types'

type MigrationBackup = Omit<InternalBackup, 'reason'> & {
  reason: 'legacy-migration'
}

export async function preserveLegacySnapshot(
  snapshot: LegacySnapshot,
  plan: MigrationPlan,
): Promise<string> {
  const db = await openLetMeFlyDb()
  try {
    const backup: MigrationBackup = {
      id: newId(),
      createdAt: new Date().toISOString(),
      reason: 'legacy-migration',
      dbVersion: 1,
      domainSchemaVersion: 1,
      stores: {
        legacyLocalStorage: snapshot.candidates.map((item) => ({
          key: item.key,
          rawValue: item.rawValue,
          parseError: item.parseError,
          confidence: item.confidence,
        })),
        migrationPlan: [plan],
      },
    }

    const tx = db.transaction('internalBackups', 'readwrite')
    tx.objectStore('internalBackups').add(backup)
    await transactionDone(tx)
    return backup.id
  } finally {
    db.close()
  }
}

export async function executeMigrationPlan(
  plan: MigrationPlan,
): Promise<MigrationVerification> {
  const device = await getOrCreateDeviceState()
  const stores = [
    ...new Set<DomainStoreName>(
      plan.candidates.map((candidate) => candidate.store),
    ),
  ]

  const db = await openLetMeFlyDb()
  const importedCounts: Record<string, number> = {}

  try {
    const tx = db.transaction(
      [...stores, 'syncOutbox', 'meta'],
      'readwrite',
    )
    const outbox = tx.objectStore('syncOutbox')
    const now = new Date().toISOString()

    for (const candidate of plan.candidates) {
      const store = tx.objectStore(candidate.store)

      const existing = await requestToPromise<LocalDomainRecord | undefined>(
        store.get(candidate.id),
      )

      if (existing) {
        // Deterministic rerun: same canonical ID means no duplicate.
        continue
      }

      const record: LocalDomainRecord = {
        ...candidate.record,
        id: candidate.id,
        created_at:
          typeof candidate.record.created_at === 'string'
            ? candidate.record.created_at
            : now,
        updated_at: now,
        deleted_at: null,
        revision: 0,
        _local: {
          localVersion: 1,
          baseRevision: 0,
          dirty: true,
          createdOffline: true,
          lastModifiedByDeviceId: device.deviceId,
        },
      }

      if (
        candidate.store !== 'athletes' &&
        record.athlete_id !== plan.athleteId
      ) {
        tx.abort()
        throw new Error(
          `Migration candidate ${candidate.store}/${candidate.id} has wrong athlete_id`,
        )
      }

      store.add(record)

      const op: SyncOutboxEntry = {
        operationId: newId(),
        athleteId: plan.athleteId,
        entityType: candidate.store,
        entityId: candidate.id,
        operation: 'upsert',
        baseRevision: 0,
        localVersion: 1,
        payload: stripLocal(record),
        deviceId: device.deviceId,
        createdAt: now,
        updatedAt: now,
        attemptCount: 0,
        nextAttemptAt: now,
        status: 'pending',
        lastError: null,
      }
      outbox.add(op)

      importedCounts[candidate.store] =
        (importedCounts[candidate.store] ?? 0) + 1
    }

    tx.objectStore('meta').put({
      key: 'legacyMigration',
      value: {
        fingerprint: plan.snapshotFingerprint,
        athleteId: plan.athleteId,
        completedAt: now,
        unmappedCount: plan.unmappedPaths.length,
        warningCount: plan.warnings.length,
      },
      updatedAt: now,
    })

    await transactionDone(tx)
  } finally {
    db.close()
  }

  return verifyMigration(plan, importedCounts)
}

export async function verifyMigration(
  plan: MigrationPlan,
  importedCounts: Record<string, number> = {},
): Promise<MigrationVerification> {
  const expectedCounts: Record<string, number> = {}
  for (const candidate of plan.candidates) {
    expectedCounts[candidate.store] =
      (expectedCounts[candidate.store] ?? 0) + 1
  }

  const actualCounts: Record<string, number> = {}
  const warnings = [...plan.warnings]
  const db = await openLetMeFlyDb()

  try {
    const stores = Object.keys(expectedCounts) as DomainStoreName[]
    const tx = db.transaction(stores, 'readonly')

    for (const storeName of stores) {
      const all = await requestToPromise<LocalDomainRecord[]>(
        tx.objectStore(storeName).getAll(),
      )
      actualCounts[storeName] = all.filter((row) => {
        if (storeName === 'athletes') return row.id === plan.athleteId
        return row.athlete_id === plan.athleteId
      }).length
    }

    await transactionDone(tx)
  } finally {
    db.close()
  }

  const verified = Object.entries(expectedCounts).every(
    ([store, expected]) => (actualCounts[store] ?? 0) >= expected,
  )

  if (!verified) {
    warnings.push('One or more canonical stores contain fewer records than expected.')
  }

  return {
    fingerprint: plan.snapshotFingerprint,
    athleteId: plan.athleteId,
    importedCounts,
    actualCounts,
    verified,
    warnings,
  }
}

function stripLocal(
  record: LocalDomainRecord,
): Record<string, unknown> {
  const { _local, ...cloud } = record
  return cloud
}

export async function hasCompletedMigrationFingerprint(
  fingerprint: string,
): Promise<boolean> {
  const db = await openLetMeFlyDb()
  try {
    const tx = db.transaction('meta', 'readonly')
    const row = await requestToPromise<
      | {
          key: string
          value?: { fingerprint?: string }
        }
      | undefined
    >(tx.objectStore('meta').get('legacyMigration'))
    await transactionDone(tx)
    return row?.value?.fingerprint === fingerprint
  } finally {
    db.close()
  }
}
