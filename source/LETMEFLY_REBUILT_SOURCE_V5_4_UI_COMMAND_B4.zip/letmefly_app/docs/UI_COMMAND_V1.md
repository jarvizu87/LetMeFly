# LetMeFly Command UI — V1

This UI checkpoint applies the selected cinematic Command visual system to the audited V5.4 application source without changing governed program prescriptions, private-data storage, sync rules, workout write semantics, or exercise-intelligence approvals.

## Design system

- Near-black / graphite app shell with crimson primary action and restrained purple secondary accents.
- Cinematic Crownforge / Black Crown presentation using CSS-built crown, mountain, steel, and atmospheric layers rather than athlete/private imagery.
- Large condensed-style display hierarchy with high-readability workout text.
- Mobile-first five-item navigation: Home, Train, Program, Progress, More. Desktop exposes Exercises, Coach, and Profile directly.
- Home is an athlete command center with program context, training focus, current performance, readiness context, and milestone cards.
- Train keeps horizontally swiped workout sections, readiness first, session review last, set-level logging, plate guidance, Watch Exercise, Exercise Info, Substitute, and Ask Coach.
- Program renders every currently embedded governed Crownforge week (Weeks 1–6) and presents Black Crown as a four-phase long-term roadmap.
- Progress emphasizes training-max trends, session history, and meaningful performance summaries.
- Exercises uses the V5.4 exercise-intelligence source across all programmed Weeks 1–6 movements with search, direct/watch status, info, and source-approved substitutions.
- Coach, Profile, and More use the same visual language instead of generic utility-page styling.

## V5.4 intelligence retained

- 202 active-plan exercise source records referenced by the exercise intelligence system.
- 82 canonical records embedded in the current source slice.
- 81 / 81 unique programmed Crownforge Weeks 1–6 exercise display names resolve to the embedded source layer.
- 68 source-approved substitution pairs are represented by the master QA reference; the current embedded verified Crownforge slice remains source-governed.
- Front Rack Carry resolves to Kettlebell Front Rack Carry.
- Watch / Info / Substitute actions never silently rewrite the public program.

## Boundaries preserved

- No athlete identity, bodyweight, training max, history, readiness, credential, or token is hard-coded into public source.
- No Crownforge or Black Crown prescription is changed by this UI pass.
- IndexedDB remains the active private workout database.
- Supabase remains optional and cannot gate local workout access.
- Workout set logging, backup/restore, migration, sync behavior, program history snapshots, and exercise-intelligence governance remain owned by their existing services.

## Batch 2 interaction pass

- Home readiness now hydrates from the athlete's latest private readiness entry instead of displaying permanent placeholders.
- Home readiness status reflects the same governed green / yellow / red calculation used by Workout Mode; it remains informational and cannot rewrite programming.
- Workout Mode section tracking now follows horizontal swipes and exposes tap targets plus previous / next controls for faster one-handed navigation.
- The active workout section, section label, and position counter update together while swiping.
- Exercise Library filter chips are now functional for Barbell, KB, Sled, Carry, and Core views while remaining combinable with text search.
- Exercise Library shows the live number of visible programmed movements and an explicit no-results state.
- Filters are derived from existing programmed names, roles, and equipment metadata; they do not add or substitute exercises.

## Batch 3 whole-app polish

- Program adds a sticky embedded-week jump navigator so Weeks 1–6 can be reviewed quickly without changing any program prescription.
- Program day cards remain the only actions that intentionally move the active Train context to a selected governed day.
- Coach context now shows live workout completion state when a session exists.
- Coach adds a private-history "What did I do last time?" prompt using the athlete's local workout history window.
- Previous-history coaching remains descriptive only and explicitly defers today's prescription to the governed program.
- Coach composer supports Ctrl/Cmd + Enter for faster desktop use while preserving the same athlete-aware rule priority.

## Batch 4 UI regression gate

The source now includes `npm run audit:ui`, which verifies the Command experience remains present across future source imports. It checks the major routes, mobile navigation, Home readiness hydration, swipe/tap Workout Mode navigation, generic governed Program weeks, Exercise search/filters/intelligence actions, Coach history context, Profile Private Vault, More route, and responsive styling.

This audit is intentionally structural. It does not authorize program changes and it does not replace browser visual QA.
