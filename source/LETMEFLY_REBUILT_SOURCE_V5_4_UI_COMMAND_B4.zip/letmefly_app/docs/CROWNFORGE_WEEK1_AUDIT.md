# Crownforge Week 1 Source Audit

Audit date: 2026-09-05
Verdict: **PASS**

## Governing source hierarchy

1. Crownforge Revised — Integrated v2.1 (August 29, 2026)
2. Retained exact source engine v1.7.20 / corrected Crown System master source where the integrated release states exact loads/reps/distances are retained

The integrated v2.1 release changes execution priority, readiness, support completion, Day 5 FLEX, and Day 6 anti-duplication. It does not authorize inventing alternate loads.

## Corrections made during this audit

### Day 2 — Olympic Skill + Upper Push / Delts / Arms

The first reconstruction understated several loads and omitted support stations. Corrected to the retained source:

- Hang Power Clean: 90x3, 95x3, 100x3 x4
- Cable External Rotation: 5 lb/side x10/side x4
- Hip Flexor Rockback: 4x6/side
- Ankle Rock: 3x6/side
- Clean Pull: 135x3, 145x3, 150x2 x2
- Serratus Wall Slide: 3x8
- T-Spine Rotation: 3x5/side
- Wrist Flexor/Extensor Pulses: 3x10 each
- Push Press: 65x5, 70x5, 75x3
- Band Pull-Apart: 3x15-20
- Cable Press-Around: 15 lb/side x12
- Rear Delt Fly: 10 lb DBs x15-20
- Rope Pushdown: 35 lb x12
- Scap Push-Up: 10-15
- Lateral Raise: 10 lb DBs x15
- DB Curl: 20 lb DBs x10-12

Three source rounds are represented directly. A fourth circuit round is marked optional only when Green, matching the governed 3-4 round section.

### Day 3 — Recovery + Knees + Hip Flexors

Step-Up now represents the governed 2-3-set range. The third set is explicitly marked optional/restorative rather than silently omitted.

### Day 4 — Pull + Hinge Strength

Corrected support loads to source:

- Pull-Up / Lat Pulldown: BW x4-6 x4 OR 90 lb x10 x4
- Chest-Supported Row: 40 lb DBs x10 x4
- Hamstring Curl: 50 lb x10 x3
- Pallof Press: 20 lb/side x10/side x3
- Backward Sled Drag: sled +25 lb x20-30m x4
- Cable Pullover: 40 lb x12 x3
- Face Pull: 35 lb x15 x3
- Chest-Supported Shrug: 50 lb DBs x10-12 x1 in the v2.1 integrated release
- Reverse Crunch or Dead Bug: 3x10-12

The one-set shrug is intentionally retained because the v2.1 integrated release explicitly lists one set for Week 1, even though older source-engine documents carried a larger support dose. v2.1 support-completion governance is the later authority.

### Day 5 — KB / Sled / GPP Control

The full Green source remains three KB-flow rounds. Sled Push and Backward Sled Drag now model the full 3-4 trip source range; the fourth trip is explicitly optional. Yellow/Red governance remains unchanged.

### Day 6 — Full Body Volume + Bench/Chest Bias + Frontal Plane KB

Corrected to source:

- Wide/Neutral Pulldown: 90 lb x10 x4
- KB Swing: 16 kg x15-20 x3-4
- main-circuit Sled Push: sled +35 lb x20-30m x4
- RDL: 95 lb x10 x3, crisp/not heavy
- Step-Up: 20 lb DBs x10/leg x2-3
- Straight-Arm Pulldown: 35 lb x12 x3
- Lateral Raise: 10 lb DBs x15 x2-3
- Cable Press-Around: 15 lb/side x12-15 x2-3
- JM Press: 45 lb x6-10 x2-3
- Rear Delt Fly: 10 lb DBs x15-20 x2-3
- Rope Pushdown: 35 lb x10-12 x2-3
- Offset Rack March: 16 kg x20 steps/side x2
- separate Sled Finish: Push +35 lb and Backward Drag +25 lb, 2-4 trips each

The main-circuit sled dose is no longer incorrectly labeled as the Day-5 anti-duplication target. The **separate sled finisher** is the section omitted by default after a full Day 5. If Day 5 was abbreviated/skipped and readiness is Green, the governed source dose may remain.

## Automated audit

Run:

```bash
npm run audit:crownforge
```

The audit fails if the corrected Week 1 key loads regress to the earlier reconstructed values.
