# Crownforge Week 2 Source Audit

Audit status: **PASS**

Source authority:
- `CROWNFORGE_REVISED_INTEGRATED_v2_1.docx`
- v2.1 source engine: `v1.7.20`
- Build: August 29, 2026

Week 2 calendar:
- Monday, 2026-09-14 through Sunday, 2026-09-20
- Intent: **Accumulate the highest clean volume of the opening wave.**

## Source-control rule

v2.1 governs execution priority, readiness, Day 5 FLEX, and Day 6 anti-duplication. The retained exact-load engine governs the written loads/reps/distances. RPE is not used to recalculate main-lift loads.

## Day-by-day audit

### Day 1 — Lower + Push Strength / Glutes
PASS
- Front Squat: 100x5, 115x4, 130x3x2, 140x3x2, 125x4
- Bench: 125x5, 135x4, 145x3, 155x2
- Chest-Supported Row: 45-lb DBs x10x4
- Backward Sled Drag: sled +35 lb x20–30m x4
- Belt Squat: 100x12, 120x10, 140x8
- Incline DB Press: 35x10, 35x8, 40x8
- Hamstring Curl: 45x12, 55x10, 65x10
- Hip Thrust: 105x10, 125x10, 145x10

### Day 2 — Olympic Skill + Upper Push / Delts / Arms
PASS
- Hang Power Clean: 95x3, 100x3, 105x3x4
- Clean Pull: 140x3, 150x2, 155x2x2
- Push Press: 70x5, 75x5, 80x3
- Support drill drop-off / finish-alone logic retained
- Upper support exact source loads retained
- No row, hard-carry, HIIT, or heavy-hinge additions

### Day 3 — Recovery + Knees + Hip Flexors
PASS
- 30–45 minute recovery cap retained
- 8-kg TGU/halo/windmill/arm-bar flow retained
- Hip-flexor/core minimum retained
- Backward sled +25 lb / forward sled +25 lb retained
- Step-Up remains 2–3 sets; third set is conditional/restorative
- Zone 2 remains optional/restorative only

### Day 4 — Pull + Hinge Strength
PASS
- Deadlift: 160x5, 175x4, 185x3, 195x2
- Pull-Up or 95-lb Lat Pulldown alternative retained
- Chest-Supported Row: 45-lb DBs x10x4
- Hamstring Curl: 55x10x3
- Pallof Press: 20 lb/side x10/side x3
- Backward Sled Drag: sled +35 lb x20–30m x4
- Cable Pullover: 45x12x3
- Face Pull: 40x15x3
- Chest-Supported Shrug: 55-lb DBs x10–12x3
- Reverse Crunch / Dead Bug: 3x10–12
- Week 1's one-set shrug exception does not leak into Week 2

### Day 5 — KB / Sled / GPP Control Day
PASS
- Green/Yellow/Red FLEX rule retained
- KB flow: 3 source rounds
- Suitcase March progresses to 20 kg / 45 lb
- Sled push/drag progresses to sled +35 lb
- Engine: 4x60–90 sec easy/moderate
- No skipped GPP is moved into Day 6

### Day 6 — Full Body Volume + Bench/Chest Bias + Frontal Plane KB
PASS
- Bench: 95x5, 120x4, 135x3x2, 145x3x4, 135x4x2
- Belt Squat: 100x12, 120x10, 140x8
- Pulldown: 95x10x4
- Main source Sled Push: sled +45 lb x20–30m x4
- RDL: 105x10x3, crisp/not heavy
- Straight-Arm Pulldown: 40x12x3
- Cable Press-Around: 20 lb/side
- JM Press: 50 lb
- Rope Pushdown: 40 lb
- Frontal-plane/core block retained
- Separate sled finisher remains conditional and is default-omitted after a full Day 5
- Conditional source finisher: Sled Push +45 / Backward Drag +35

### Day 7 — Rest
PASS
- Rest remains programmed
- No make-up punishment
- Easy walk/mobility only when restorative

## Code validation

PASS:
- `CROWNFORGE_WEEK_2` contains exactly 7 calendar days
- all seven dates match 2026-09-14 through 2026-09-20
- `CROWNFORGE.weekData` now registers Weeks 1 and 2
- dedicated Week 2 source audit script passes
- Week 1 regression audit still passes after Week 2 was added
- strict TypeScript compilation of `src/data/programs.ts` passes
- source/static rebuild audit passes

## Open items

- Weeks 3–14 remain intentionally unimported until each week is sourced and audited.
- Crown Maintenance Weeks 1–3 remain intentionally unimported.
- Black Crown detailed sessions remain catalog-only until its governing source is imported.
- Full Vite production build still requires the networked dependency/build environment.
