# Program Source Coverage — Rebuilt App

## Governing hierarchy

### Crownforge
- Current user-facing release: `CROWNFORGE_REVISED_INTEGRATED_v2_1.docx`
- Source engine retained by v2.1: v1.7.20
- Program identity: 14-week Crownforge + 3-week Crown Maintenance entry bridge
- Opening date: Monday, September 7, 2026
- Governing rule: v2.1 controls readiness/priority/FLEX/anti-duplication; retained source controls exact prescriptions where v2.1 says they are unchanged

### Black Crown
- Current user-facing release: `BLACK_CROWN_REVISED_54_WEEK_PROGRAM_v2_0.docx`
- Program identity: 54 weeks / nine 6-week blocks / five sessions per week

## Crownforge structured-program coverage

| Area | Rebuild status | Confidence |
|---|---|---|
| Week 1 | embedded + dedicated source audit PASS | High |
| Week 2 | embedded + dedicated source audit PASS | High |
| Week 3 | embedded + dedicated source audit PASS | High |
| Week 4 | embedded + dedicated source audit PASS | High |
| Week 5 | embedded + dedicated source audit PASS | High |
| Week 6 | embedded + dedicated source audit PASS | High |
| Weeks 1–6 calendar/program registry | regression audit PASS; 42 consecutive days | High |
| v2.1 readiness/day-priority governance | embedded across current weeks | High |
| v2.1 Day 5 FLEX + Day 6 anti-duplication | embedded across current weeks | High |
| Week 6 true deload | embedded from source; no extrapolated loading | High |

## Current structured date coverage

- Week 1: Sep 7–13, 2026
- Week 2: Sep 14–20, 2026
- Week 3: Sep 21–27, 2026
- Week 4: Sep 28–Oct 4, 2026
- Week 5: Oct 5–11, 2026
- Week 6: Oct 12–18, 2026

## What is intentionally not reconstructed from memory

- Crownforge Weeks 7–14
- Crown Maintenance Weeks 1–3
- Black Crown Weeks 1–54 detailed sessions

The public program engine supports those data, but each remaining block must be imported from its governing source and audited before activation.

## Immediate-use note

Crownforge Weeks 1–6 are represented as governed structured workouts. The app must never extrapolate a future week simply because a preceding week is present.

## Exercise intelligence

V5.4 integrates the source Exercise Demo Library / Alternative Exercises layer. The workbook QA identifies **202 active-plan exercises** and **68 source-approved substitution pairs**.

The current embedded source-backed slice contains **82 canonical exercise records** and resolves **81 / 81 unique exercise display names used throughout Crownforge Weeks 1–6**. Seven verified Crownforge substitution rows are embedded. Direct source videos, plan-linked searches, and search fallbacks retain distinct statuses; search fallbacks are never labeled as vetted direct videos.

`Front Rack Carry` is normalized to `Kettlebell Front Rack Carry`, preserving the intended movement rather than creating a generic duplicate. Exercise intelligence can explain/show alternatives but may not rewrite the public program.

The remaining source catalog/substitution rows are intentionally not claimed as imported until they are structured and audited. See `docs/EXERCISE_INTELLIGENCE_AUDIT.md`.
